/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

import * as i0 from "@angular/core";
import { Directive, ElementRef, Injectable, Injector, Input, NgModule, Renderer2, inject, input } from "@angular/core";
import { NG_VALIDATORS, NgControl } from "@angular/forms";
import { __decorate } from "tslib";
import Ajv from "ajv";
import addFormats from "ajv-formats";
import { WINDOW } from "@oblique/oblique";
function draft07Convert(target, propertyKey, descriptor) {
	const oldValue = descriptor.value;
	descriptor.value = function(originalSchema) {
		const schema = JSON.parse(JSON.stringify(originalSchema));
		convert(schema);
		return oldValue.call(this, schema);
	};
	return descriptor;
	function convert(schema) {
		convertId(schema);
		schema.required ||= [];
		if (schema.properties) Object.keys(schema.properties).forEach((propertyName) => {
			const property = schema.properties[propertyName];
			arrayifyRequired(property, propertyName, schema);
			convertAnyIntoObject(property);
			if (property.items || property.properties) convert(property.items || property);
		});
	}
	function convertId(schema) {
		if (schema.id) {
			schema.$id = schema.id;
			delete schema.id;
		}
	}
	function arrayifyRequired(property, propertyName, schema) {
		if (property.required && !Array.isArray(property.required)) {
			schema.required.push(propertyName);
			delete property.required;
		}
	}
	function convertAnyIntoObject(property) {
		if (property.type === "any") property.type = "object";
	}
}
var ObSchemaValidatorInstance = class {
	constructor(schema) {
		this.ajv = new Ajv({
			allErrors: true,
			allowUnionTypes: true
		});
		addFormats(this.ajv);
		this.addSchema(schema);
		this.schema = schema;
	}
	validate(propertyPath = "", value) {
		if (this.hasRequiredError(propertyPath.split("."), value)) return { "ajv.required": true };
		if (this.ajv.getSchema(propertyPath)) {
			this.ajv.validate(propertyPath, value);
			if (this.ajv.errors && ![
				null,
				void 0,
				""
			].includes(value)) {
				const key = this.ajv.errors[0].keyword === "format" && this.ajv.errors[0].params.format === "date-time" ? ".date" : "";
				return { [`ajv.${this.ajv.errors[0].keyword}${key}`]: this.ajv.errors[0].params };
			}
		}
		return null;
	}
	getValidator(propertyPath) {
		return (control) => this.validate(propertyPath, control.value);
	}
	isRequired(property, path) {
		let schema = JSON.parse(JSON.stringify(this.schema));
		path.forEach((name) => {
			if (schema?.properties[name]) schema = schema.properties[name];
		});
		return (schema.required || []).indexOf(property) > -1;
	}
	hasRequiredError(path, value) {
		const propertyName = path.pop();
		return !value && this.isRequired(propertyName, path);
	}
	addSchema(schema, parentPropertyName) {
		Object.keys(schema.properties || {}).forEach((propertyName) => {
			const propertyPath = parentPropertyName ? `${parentPropertyName}.${propertyName}` : propertyName;
			if (schema.properties[propertyName].properties) this.addSchema(schema.properties[propertyName], propertyPath);
			else this.ajv.addSchema(schema.properties[propertyName], propertyPath);
		});
	}
};
var ObSchemaValidationService = class ObSchemaValidationService {
	compileSchema(schema) {
		return new ObSchemaValidatorInstance(schema);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationService,
			providedIn: "root"
		});
	}
};
__decorate([draft07Convert], ObSchemaValidationService.prototype, "compileSchema", null);
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObSchemaValidationService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	propDecorators: { compileSchema: [] }
});
var ObSchemaValidationDirective = class ObSchemaValidationDirective {
	constructor() {
		this.schema = input(void 0, {
			...ngDevMode ? { debugName: "schema" } : /* istanbul ignore next */ {},
			alias: "obSchemaValidation"
		});
		this.schemaValidationService = inject(ObSchemaValidationService);
	}
	ngOnInit() {
		this.validator = this.schemaValidationService.compileSchema(this.schema());
	}
	isRequired(propertyName, path) {
		return this.validator.isRequired(propertyName, path);
	}
	validate(propertyPath, value) {
		return this.validator.validate(propertyPath, value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "17.1.0",
			version: "22.2.6",
			type: ObSchemaValidationDirective,
			isStandalone: true,
			selector: "[obSchemaValidation]",
			inputs: { schema: {
				classPropertyName: "schema",
				publicName: "obSchemaValidation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			} },
			host: { classAttribute: "ob-schema-validation" },
			providers: [ObSchemaValidationService],
			exportAs: ["obSchemaValidation"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObSchemaValidationDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[obSchemaValidation]",
			providers: [ObSchemaValidationService],
			host: { class: "ob-schema-validation" },
			exportAs: "obSchemaValidation"
		}]
	}],
	propDecorators: { schema: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "obSchemaValidation",
			required: false
		}]
	}] }
});
var ObSchemaRequiredDirective = class ObSchemaRequiredDirective {
	constructor() {
		this.host = inject(ElementRef);
		this.renderer = inject(Renderer2);
		this.control = inject(NgControl, { self: true });
		this.schemaValidation = inject(ObSchemaValidationDirective);
	}
	ngOnInit() {
		const path = this.control.path.slice(0, -1);
		this.required = typeof this.control.name === "string" ? this.schemaValidation.isRequired(this.control.name, path) : false;
	}
	ngAfterViewInit() {
		if (this.required) this.insertRequiredMarkerInLabel();
	}
	insertRequiredMarkerInLabel() {
		const matFormField = this.host.nativeElement.closest(".mat-mdc-form-field");
		if (matFormField) {
			const label = matFormField.querySelector("label");
			if (label) {
				const span = this.renderer.createElement("span");
				span.setAttribute("class", "mat-mdc-form-field-required-marker mdc-floating-label--required");
				span.setAttribute("aria-hidden", "true");
				this.renderer.appendChild(label, span);
			}
		}
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaRequiredDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.6",
			type: ObSchemaRequiredDirective,
			isStandalone: true,
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			host: {
				properties: { "attr.aria-required": "required" },
				classAttribute: "ob-schema-required-validation"
			},
			exportAs: ["obSchemaRequiredValidation"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObSchemaRequiredDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			host: {
				"[attr.aria-required]": "required",
				class: "ob-schema-required-validation"
			},
			exportAs: "obSchemaRequiredValidation"
		}]
	}]
});
var ObSchemaValidateDirective = class ObSchemaValidateDirective {
	constructor() {
		this.window = inject(WINDOW);
		this.schemaDirective = inject(ObSchemaValidationDirective);
		this.injector = inject(Injector);
	}
	ngAfterViewInit() {
		const ngControl = this.injector.get(NgControl);
		this.propertyName = ngControl.path.join(".");
		this.window.setTimeout(() => ngControl.control.updateValueAndValidity());
	}
	validate(formControl) {
		return this.schemaDirective.validate(this.propertyName, formControl.value);
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidateDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.6",
			type: ObSchemaValidateDirective,
			isStandalone: true,
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: ObSchemaValidateDirective,
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObSchemaValidateDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: ObSchemaValidateDirective,
				multi: true
			}]
		}]
	}]
});
var ObSchemaValidationModule = class ObSchemaValidationModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationModule,
			imports: [
				ObSchemaRequiredDirective,
				ObSchemaValidateDirective,
				ObSchemaValidationDirective
			],
			exports: [
				ObSchemaRequiredDirective,
				ObSchemaValidateDirective,
				ObSchemaValidationDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObSchemaValidationModule
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObSchemaValidationModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				ObSchemaRequiredDirective,
				ObSchemaValidateDirective,
				ObSchemaValidationDirective
			],
			exports: [
				ObSchemaRequiredDirective,
				ObSchemaValidateDirective,
				ObSchemaValidationDirective
			]
		}]
	}]
});
var ObMockSchemaRequiredDirective = class ObMockSchemaRequiredDirective {
	constructor() {
		this.required = true;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaRequiredDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.6",
			type: ObMockSchemaRequiredDirective,
			isStandalone: true,
			selector: "[ngModel]",
			inputs: { name: "name" },
			exportAs: ["ngModel"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObMockSchemaRequiredDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[ngModel]",
			exportAs: "ngModel"
		}]
	}],
	propDecorators: { name: [{ type: Input }] }
});
var ObMockSchemaValidateDirective = class ObMockSchemaValidateDirective {
	validate(formControl) {
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidateDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "14.0.0",
			version: "22.2.6",
			type: ObMockSchemaValidateDirective,
			isStandalone: true,
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: ObMockSchemaValidateDirective,
				multi: true
			}],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObMockSchemaValidateDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: ObMockSchemaValidateDirective,
				multi: true
			}]
		}]
	}]
});
var ObMockSchemaValidationDirective = class ObMockSchemaValidationDirective {
	constructor() {
		this.schema = input(void 0, {
			...ngDevMode ? { debugName: "schema" } : /* istanbul ignore next */ {},
			alias: "obSchemaValidation"
		});
	}
	isRequired(propertyName, path) {
		return true;
	}
	validate(propertyPath, value) {
		return null;
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationDirective,
			deps: [],
			target: i0.ɵɵFactoryTarget.Directive
		});
	}
	static {
		this.ɵdir = i0.ɵɵngDeclareDirective({
			minVersion: "17.1.0",
			version: "22.2.6",
			type: ObMockSchemaValidationDirective,
			isStandalone: true,
			selector: "[obSchemaValidation]",
			inputs: { schema: {
				classPropertyName: "schema",
				publicName: "obSchemaValidation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			} },
			exportAs: ["obSchemaValidation"],
			ngImport: i0
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObMockSchemaValidationDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[obSchemaValidation]",
			exportAs: "obSchemaValidation"
		}]
	}],
	propDecorators: { schema: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "obSchemaValidation",
			required: false
		}]
	}] }
});
var ObMockSchemaValidationService = class ObMockSchemaValidationService {
	compileSchema(schema) {
		return {};
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationService,
			deps: [],
			target: i0.ɵɵFactoryTarget.Injectable
		});
	}
	static {
		this.ɵprov = i0.ɵɵngDeclareInjectable({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationService
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObMockSchemaValidationService,
	decorators: [{ type: Injectable }]
});
var ObMockSchemaValidationModule = class ObMockSchemaValidationModule {
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationModule,
			deps: [],
			target: i0.ɵɵFactoryTarget.NgModule
		});
	}
	static {
		this.ɵmod = i0.ɵɵngDeclareNgModule({
			minVersion: "14.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationModule,
			imports: [
				ObMockSchemaRequiredDirective,
				ObMockSchemaValidateDirective,
				ObMockSchemaValidationDirective
			],
			exports: [
				ObMockSchemaRequiredDirective,
				ObMockSchemaValidateDirective,
				ObMockSchemaValidationDirective
			]
		});
	}
	static {
		this.ɵinj = i0.ɵɵngDeclareInjector({
			minVersion: "12.0.0",
			version: "22.2.6",
			ngImport: i0,
			type: ObMockSchemaValidationModule,
			providers: [{
				provide: ObSchemaValidationService,
				useClass: ObMockSchemaValidationService
			}]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.6",
	ngImport: i0,
	type: ObMockSchemaValidationModule,
	decorators: [{
		type: NgModule,
		args: [{
			imports: [
				ObMockSchemaRequiredDirective,
				ObMockSchemaValidateDirective,
				ObMockSchemaValidationDirective
			],
			providers: [{
				provide: ObSchemaValidationService,
				useClass: ObMockSchemaValidationService
			}],
			exports: [
				ObMockSchemaRequiredDirective,
				ObMockSchemaValidateDirective,
				ObMockSchemaValidationDirective
			]
		}]
	}]
});
export { ObMockSchemaRequiredDirective, ObMockSchemaValidateDirective, ObMockSchemaValidationDirective, ObMockSchemaValidationModule, ObMockSchemaValidationService, ObSchemaRequiredDirective, ObSchemaValidateDirective, ObSchemaValidationDirective, ObSchemaValidationModule, ObSchemaValidationService, ObSchemaValidatorInstance, draft07Convert };

//# sourceMappingURL=oblique-src-lib-schema-validation.mjs.map