import * as i0 from "@angular/core";
import { AfterViewInit, OnInit } from "@angular/core";
import { UntypedFormControl, ValidationErrors, Validator } from "@angular/forms";
export declare class ObSchemaRequiredDirective implements AfterViewInit, OnInit {
  required: boolean;
  private readonly host;
  private readonly renderer;
  private readonly control;
  private readonly schemaValidation;
  ngOnInit(): void;
  ngAfterViewInit(): void;
  private insertRequiredMarkerInLabel;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSchemaRequiredDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObSchemaRequiredDirective, "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]", ["obSchemaRequiredValidation"], {}, {}, never, never, true, never>;
}
export declare class ObSchemaValidateDirective implements AfterViewInit, Validator {
  private propertyName;
  private readonly window;
  private readonly schemaDirective;
  private readonly injector;
  ngAfterViewInit(): void;
  validate(formControl: UntypedFormControl): ValidationErrors;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSchemaValidateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObSchemaValidateDirective, "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]", never, {}, {}, never, never, true, never>;
}
export declare class ObSchemaValidationDirective implements OnInit {
  readonly schema: import("@angular/core").InputSignal<any>;
  private validator;
  private readonly schemaValidationService;
  ngOnInit(): void;
  isRequired(propertyName: string, path: string[]): boolean;
  validate(propertyPath: string, value: any): ValidationErrors;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSchemaValidationDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObSchemaValidationDirective, "[obSchemaValidation]", ["obSchemaValidation"], {
    "schema": {
      "alias": "obSchemaValidation";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObSchemaValidationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSchemaValidationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObSchemaValidationModule, never, [typeof ObSchemaRequiredDirective, typeof ObSchemaValidateDirective, typeof ObSchemaValidationDirective], [typeof ObSchemaRequiredDirective, typeof ObSchemaValidateDirective, typeof ObSchemaValidationDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObSchemaValidationModule>;
}
export declare class ObSchemaValidatorInstance {
  private readonly ajv;
  private readonly schema;
  constructor(schema: any);
  validate(propertyPath: string, value: any): ValidationErrors;
  getValidator(propertyPath: string): (AbstractControl: any) => ValidationErrors;
  isRequired(property: string, path: string[]): boolean;
  private hasRequiredError;
  private addSchema;
}
export declare class ObSchemaValidationService {
  compileSchema(schema: any): ObSchemaValidatorInstance;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSchemaValidationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function draft07Convert(target: any, propertyKey: string, descriptor: PropertyDescriptor): any;
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSchemaRequiredDirective {
  name: string;
  required: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSchemaRequiredDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockSchemaRequiredDirective, "[ngModel]", ["ngModel"], {
    "name": {
      "alias": "name";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSchemaValidateDirective implements Validator {
  validate(formControl: UntypedFormControl): ValidationErrors;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSchemaValidateDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockSchemaValidateDirective, "[obSchemaValidate][ngModel],[obSchemaValidate][formControlName]", never, {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSchemaValidationDirective {
  readonly schema: import("@angular/core").InputSignal<any>;
  isRequired(propertyName: string, path: string[]): boolean;
  validate(propertyPath: string, value: any): ValidationErrors;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSchemaValidationDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockSchemaValidationDirective, "[obSchemaValidation]", ["obSchemaValidation"], {
    "schema": {
      "alias": "obSchemaValidation";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSchemaValidationService {
  compileSchema(schema: any): ObSchemaValidatorInstance;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSchemaValidationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSchemaValidationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSchemaValidationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockSchemaValidationModule, never, [typeof ObMockSchemaRequiredDirective, typeof ObMockSchemaValidateDirective, typeof ObMockSchemaValidationDirective], [typeof ObMockSchemaRequiredDirective, typeof ObMockSchemaValidateDirective, typeof ObMockSchemaValidationDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockSchemaValidationModule>;
}
//# sourceMappingURL=oblique-src-lib-schema-validation.d.ts.map