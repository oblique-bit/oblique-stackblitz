import * as i0 from "@angular/core";
import { AfterContentInit, AfterViewInit, DestroyRef, DoCheck, ElementRef, EnvironmentProviders, EventEmitter, InjectionToken, ModelSignal, ModuleWithProviders, OnChanges, OnDestroy, OnInit, PipeTransform, Signal, SimpleChanges, TemplateRef, WritableSignal } from "@angular/core";
import { MatFormFieldDefaultOptions } from "@angular/material/form-field";
import * as i3 from "@angular/material/checkbox";
import { MatCheckboxDefaultOptions } from "@angular/material/checkbox";
import { MatRadioDefaultOptions } from "@angular/material/radio";
import { MatSlideToggleDefaultOptions } from "@angular/material/slide-toggle";
import { MatTabsConfig } from "@angular/material/tabs";
import { StepperOptions } from "@angular/cdk/stepper";
import * as i2$1 from "@ngx-translate/core";
import { FallbackLangChangeEvent, LangChangeEvent, RootTranslateServiceConfig, TranslateService, TranslationChangeEvent } from "@ngx-translate/core";
import * as i2$2 from "angular-oauth2-oidc";
import { AuthConfig, NullValidationHandler, OAuthModuleConfig, OAuthService, ValidationHandler } from "angular-oauth2-oidc";
import * as i1$1 from "@angular/common";
import { Observable, Subject, Subscription } from "rxjs";
import * as i24 from "@angular/router";
import { ActivatedRoute, CanDeactivate, IsActiveMatchOptions, Params, RouterLinkActive } from "@angular/router";
import { MatInput } from "@angular/material/input";
import { AbstractControl, ControlContainer, ControlValueAccessor, FormControl, NgControl, NgModel, UntypedFormGroup, ValidationErrors, Validator } from "@angular/forms";
import * as i16 from "@angular/material/select";
import { MatSelect } from "@angular/material/select";
import * as i2 from "@angular/material/button";
import * as i4 from "@angular/material/icon";
import * as i5 from "@angular/material/progress-bar";
import * as i6 from "@angular/material/sort";
import { MatSort } from "@angular/material/sort";
import * as i7 from "@angular/material/table";
import { MatTableDataSource } from "@angular/material/table";
import * as i8 from "@angular/material/tooltip";
import { HttpErrorResponse, HttpEvent, HttpEventType, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { SelectionModel } from "@angular/cdk/collections";
import { MatPaginator, MatPaginatorIntl } from "@angular/material/paginator";
import * as i13 from "@angular/material/badge";
import * as i18 from "@angular/cdk/a11y";
import { Options, Placement } from "@popperjs/core";
import * as i25 from "@angular/cdk/scrolling";
import * as i1 from "@angular/material/datepicker";
import { MatDatepicker } from "@angular/material/datepicker";
import { MatStepperIntl } from "@angular/material/stepper";
import { MatOptionSelectionChange } from "@angular/material/core";
export interface ObIconConfig {
  registerObliqueIcons?: boolean;
  additionalIcons?: string[];
  fontClass?: string;
}
export declare enum ObEIcon {
  ACCESSIBILITY = "accessibility",
  ACCOMMODATION = "accommodation",
  ADDRESS_BOOK = "address-book",
  AIRPLANE_LANDING = "airplane_landing",
  AIRPLANE_TAKEOFF = "airplane_takeoff",
  AIRPLANE = "airplane",
  ANCHOR = "anchor",
  ANTENNA = "antenna",
  ANTIQUE_BUILDING = "antique-building",
  APPS = "apps",
  ARCHIVE_BOX = "archive-box",
  ARROW_CLOCKWISE = "arrow_clockwise",
  ARROW_COUNTERCLOCKWISE = "arrow_counterclockwise",
  ARROW_DOWN_LEFT = "arrow_down_left",
  ARROW_DOWN_RIGHT = "arrow_down_right",
  ARROW_DOWN = "arrow_down",
  ARROW_LEFT = "arrow_left",
  ARROW_RIGHT = "arrow_right",
  ARROW_UP_LEFT = "arrow_up_left",
  ARROW_UP_RIGHT = "arrow_up_right",
  ARROW_UP = "arrow_up",
  ARTIFICIAL_INTELLIGENCE = "artificial-intelligence",
  ATTACHMENT = "attachment",
  AUDIO_DESCRIPTION = "audio-description",
  BADGE = "badge",
  BARCODE = "barcode",
  BOOK = "book",
  BOOKMARK_FILLED = "bookmark_filled",
  BOOKMARK = "bookmark",
  BOT = "bot",
  BRAILLE = "braille",
  BRANCH = "branch",
  BRIEFCASE = "briefcase",
  BRUSH = "brush",
  BUG = "bug",
  BUILDING = "building",
  BUNDESHAUS = "bundeshaus",
  CALCULATOR = "calculator",
  CALENDAR = "calendar",
  CAMERA = "camera",
  CAR = "car",
  CERTIFICATE = "certificate",
  CHART_BAR_HORIZONTAL = "chart_bar_horizontal",
  CHART_BAR_VERTICAL = "chart_bar_vertical",
  CHART_LINE_DECLINE = "chart_line_decline",
  CHART_LINE_GROWTH = "chart_line_growth",
  CHART_LINE = "chart_line",
  CHART_PIE = "chart_pie",
  CHECKMARK_BOLD = "checkmark_bold",
  CHECKMARK_CIRCLE = "checkmark_circle",
  CHECKMARK_STAR = "checkmark_star",
  CHECKMARK = "checkmark",
  CHEVRON_DOWN_SMALL = "chevron_down_small",
  CHEVRON_DOWN = "chevron_down",
  CHEVRON_LEFT_DOUBLE = "chevron_left_double",
  CHEVRON_LEFT_SMALL = "chevron_left_small",
  CHEVRON_LEFT_TO_LINE = "chevron_left-to-line",
  CHEVRON_LEFT = "chevron_left",
  CHEVRON_RIGHT_DOUBLE = "chevron_right_double",
  CHEVRON_RIGHT_SMALL = "chevron_right_small",
  CHEVRON_RIGHT_TO_LINE = "chevron_right-to-line",
  CHEVRON_RIGHT = "chevron_right",
  CHEVRON_UP_SMALL = "chevron_up_small",
  CHEVRON_UP = "chevron_up",
  CLIPBOARD = "clipboard",
  CLOCK = "clock",
  CLOSED_CAPTIONS = "closed-captions",
  CLOUD_UPLOAD = "cloud_upload",
  CLOUD = "cloud",
  COFFEE = "coffee",
  COINS = "coins",
  COLLAPSE = "collapse",
  COLOR_PICKER = "color-picker",
  COMPARE = "compare",
  COMPASS = "compass",
  COPY = "copy",
  CREDIT_CARD = "credit-card",
  CROP = "crop",
  DATABASE = "database",
  DECLINE = "decline",
  DELETE = "delete",
  DESKTOP = "desktop",
  DOG = "dog",
  DOWNLOAD = "download",
  DRAG_INDICATOR = "drag-indicator",
  DUMBBELL = "dumbbell",
  EASY_LANGUAGE = "easy-language",
  ERASER = "eraser",
  EXCLAMATION_BOLD = "exclamation_bold",
  EXCLAMATION_CIRCLE = "exclamation_circle",
  EXCLAMATION_DIAMOND = "exclamation_diamond",
  EXCLAMATION_TRIANGLE = "exclamation_triangle",
  EXCLAMATION = "exclamation",
  EXPAND = "expand",
  EYE_OFF = "eye_off",
  EYE = "eye",
  FACEBOOK = "facebook",
  FACTORY = "factory",
  FAST_FORWARD = "fast-forward",
  FAX = "fax",
  FILE_ADD = "file_add",
  FILE_AUDIO = "file_audio",
  FILE_CHECKMARK = "file_checkmark",
  FILE_CODE = "file_code",
  FILE_CSV = "file_csv",
  FILE_EPUB = "file_epub",
  FILE_EXCEL = "file_excel",
  FILE_FORWARD = "file_forward",
  FILE_IMAGE = "file_image",
  FILE_JSON = "file_json",
  FILE_LIST = "file_list",
  FILE_PDF = "file_pdf",
  FILE_PERSON = "file_person",
  FILE_POWERPOINT = "file_powerpoint",
  FILE_REFRESH = "file_refresh",
  FILE_SERVER = "file_server",
  FILE_TEXT = "file_text",
  FILE_VIDEO = "file_video",
  FILE_WORD = "file_word",
  FILE_XML = "file_xml",
  FILE_ZIP = "file_zip",
  FILE = "file",
  FILTER = "filter",
  FLAG_FILLED = "flag_filled",
  FLAG = "flag",
  FLASK = "flask",
  FOLDER_OPEN = "folder_open",
  FOLDER = "folder",
  FORWARD = "forward",
  FULLSCREEN_EXIT = "fullscreen_exit",
  FULLSCREEN = "fullscreen",
  GENDER_AGENDER = "gender_agender",
  GENDER_BIGENDER = "gender_bigender",
  GENDER_FEMALE = "gender_female",
  GENDER_MALE = "gender_male",
  GENDER_NEUTROIS = "gender_neutrois",
  GENDER_NON_BINARY = "gender_non-binary",
  GENDER_TRANSGENDER = "gender_transgender",
  GITHUB = "github",
  GLOBE = "globe",
  GRADUATION_CAP = "graduation-cap",
  GRID = "grid",
  GROWTH = "growth",
  HAPPY = "happy",
  HARD_OF_HEARING = "hard-of-hearing",
  HD = "hd",
  HEADPHONES = "headphones",
  HEADSET = "headset",
  HEART_FILLED = "heart_filled",
  HEART = "heart",
  HISTORY = "history",
  HOME = "home",
  HORSE = "horse",
  HOSPITAL = "hospital",
  ID_CARD = "id-card",
  IMAGE = "image",
  INBOX = "inbox",
  INFO_BOLD = "info_bold",
  INFO_CIRCLE = "info_circle",
  INFO = "info",
  INSTAGRAM = "instagram",
  JUSTICE_SCALES_OFF = "justice-scales_off",
  JUSTICE_SCALES = "justice-scales",
  KEY = "key",
  KEYBOARD = "keyboard",
  LIGHTNING = "lightning",
  LINK_DISCONNECT = "link_disconnect",
  LINK_EXTERNAL = "link_external",
  LINK = "link",
  LINKEDIN = "linkedin",
  LIST_PARAGRAPH = "list_paragraph",
  LIST = "list",
  LOCATION = "location",
  LOCK_OPEN = "lock_open",
  LOCK = "lock",
  LOGIN = "login",
  LOGOUT = "logout",
  LOW_VISION = "low-vision",
  MAGIC_WAND = "magic-wand",
  MAGNET = "magnet",
  MAIL_ATTACHMENT = "mail_attachment",
  MAIL_OPEN = "mail_open",
  MAIL = "mail",
  MANUSCRIPT = "manuscript",
  MAP = "map",
  MEGAPHONE = "megaphone",
  MENU = "menu",
  MESSAGE = "message",
  MICROPHONE_MUTED = "microphone_muted",
  MICROPHONE = "microphone",
  MINUS_CIRCLE = "minus_circle",
  MINUS = "minus",
  MOBILE = "mobile",
  NOTIFICATION_OFF = "notification_off",
  NOTIFICATION = "notification",
  PALETTE = "palette",
  PAUSE = "pause",
  PENCIL = "pencil",
  PERSON_BRUSH = "person_brush",
  PERSON_CHECKMARK = "person_checkmark",
  PERSON_CODE = "person_code",
  PERSON_GROUP = "person_group",
  PERSON_MEDIC = "person_medic",
  PERSON_PENCIL = "person_pencil",
  PERSON_SETTINGS = "person_settings",
  PERSON = "person",
  PHONE = "phone",
  PIN = "pin",
  PLAY = "play",
  PLUS_CIRCLE = "plus_circle",
  PLUS = "plus",
  PRINT = "print",
  PROHIBITION = "prohibition",
  QR_CODE = "qr-code",
  QUESTION_CIRCLE = "question_circle",
  QUESTION = "question",
  REDO = "redo",
  REFRESH = "refresh",
  REPLY = "reply",
  REWIND = "rewind",
  RSS = "rss",
  SAD = "sad",
  SAVE = "save",
  SCREENSHOT = "screenshot",
  SCROLL_HORIZONTAL = "scroll_horizontal",
  SCROLL_VERTICAL = "scroll_vertical",
  SEARCH_INSIGHTS = "search_insights",
  SEARCH = "search",
  SEND = "send",
  SERVER = "server",
  SETTINGS = "settings",
  SHARE = "share",
  SHIELD_CHECKMARK = "shield_checkmark",
  SHIELD_LOCK = "shield_lock",
  SHOPPING_CART = "shopping-cart",
  SHOW_MORE_HORIZONTAL = "show-more_horizontal",
  SHOW_MORE_VERTICAL = "show-more_vertical",
  SHUFFLE = "shuffle",
  SIGN_LANGUAGE = "sign-language",
  SIGNAL_OFF = "signal_off",
  SIGNAL = "signal",
  SKIP_BACK = "skip_back",
  SKIP_NEXT = "skip_next",
  SORT_LIST_ASCENDING = "sort_list_ascending",
  SORT_LIST_DESCENDING = "sort_list_descending",
  STACK = "stack",
  STAR_FILLED = "star_filled",
  STAR = "star",
  STATUS_ARROW_RIGHT = "status_arrow_right",
  STOP_GESTURE = "stop-gesture",
  STOP = "stop",
  SUPPORT = "support",
  SWAP_HORIZONTAL = "swap_horizontal",
  SWAP_VERTICAL = "swap_vertical",
  TABLET = "tablet",
  TACHOMETER = "tachometer",
  TAG = "tag",
  TARGET = "target",
  TEXTAREA_LEFT = "textarea_left",
  TEXTAREA_RIGHT = "textarea_right",
  THUMBS_DOWN = "thumbs_down",
  THUMBS_UP = "thumbs_up",
  TICKET = "ticket",
  TRANSLATE = "translate",
  TRUCK = "truck",
  UNDO = "undo",
  UPLOAD = "upload",
  VIDEO = "video",
  VISUAL_IMPAIRMENT = "visual-impairment",
  VOLUME_HIGH = "volume_high",
  VOLUME_LOW = "volume_low",
  VOLUME_MUTED = "volume_muted",
  WEIGHT = "weight",
  WHEELCHAIR = "wheelchair",
  WIFI = "wifi",
  WRENCH = "wrench",
  X_TWITTER = "x-twitter",
  XING = "xing",
  XMARK_BOLD = "xmark_bold",
  XMARK_CIRCLE = "xmark_circle",
  XMARK = "xmark",
  YOUTUBE = "youtube",
  ZOOM_IN = "zoom_in",
  ZOOM_OUT = "zoom_out"
}
export declare enum ObEPamsEnvironment {
  DEV = "-d",
  REF = "-r",
  TEST = "-t",
  ABN = "-a",
  PROD = ""
}
export interface ObIServiceNavigationLink {
  url: string;
  label: string;
}
interface ObIServiceNavigationContactBase {
  email?: string;
  emailText?: string;
  phone?: string;
  phoneText?: string;
  formUrl?: string;
  formUrlText?: string;
}
export type ObIServiceNavigationContact = ObIServiceNavigationContactBase & ({
  emailText?: never;
} | {
  emailText: string;
  email: string;
}) & ({
  phoneText?: never;
} | {
  phoneText: string;
  phone: string;
}) & ({
  formUrlText?: never;
} | {
  formUrlText: string;
  formUrl: string;
});
interface ObISectionLink {
  url: string;
  label: string;
  icon?: string;
  isInternalLink?: boolean;
  ariaLabel?: string | {
    text: string;
    parameters: Record<string, unknown>;
  };
  extraText?: string;
}
/**
 * @deprecated since version 16.1. It will be removed with Oblique 17. Use ObEQualityOfAuthentication instead
 */
export type ObLoginState = 'SA' | 'S1' | 'S2OK' | 'S2+OK' | 'S3OK' | 'S3+OK';
export declare enum ObEQualityOfAuthentication {
  ANONYMOUS = 0,
  WEAK = 20,
  NORMAL = 30,
  VERIFIED = 40,
  STRONG = 50,
  VERY_STRONG = 60
}
interface ObIServiceNavigationApplication {
  image: string;
  name: string;
  status: ObServiceNavigationApplicationStatus;
  url: string;
}
type ObServiceNavigationApplicationStatus = 'online' | 'offline' | 'inaccessible';
interface ObILanguage {
  code: string;
  label: string;
}
interface ObIPamsConfiguration {
  environment: ObEPamsEnvironment;
  rootUrl?: string;
}
export interface ObIMaterialConfig {
  OB_MAT_ERROR_PREFIX?: string | null;
  MAT_FORM_FIELD_DEFAULT_OPTIONS?: MatFormFieldDefaultOptions;
  STEPPER_GLOBAL_OPTIONS?: StepperOptions;
  MAT_CHECKBOX_OPTIONS?: MatCheckboxDefaultOptions;
  MAT_RADIO_OPTIONS?: MatRadioDefaultOptions;
  MAT_SLIDE_TOGGLE_OPTIONS?: MatSlideToggleDefaultOptions;
  MAT_TABS_CONFIG?: MatTabsConfig;
}
export interface ObLanguageConfig {
  hasLanguageInUrl?: boolean;
}
interface ObILocale {
  locales: (string | ObILocaleObject)[];
  defaultLanguage: string;
  disabled: boolean;
}
interface ObILocaleObject {
  locale: string;
  id?: string;
  label?: string;
}
interface ObITranslateConfig {
  flatten?: boolean;
  config?: RootTranslateServiceConfig;
  additionalFiles?: ObITranslationFile[];
  locales?: Partial<ObILocale>;
}
export interface ObITranslationFile {
  prefix: string;
  suffix: string;
}
interface ObConsoleConfiguration {
  silencedLabels?: ReadonlySet<string>;
}
export interface ObIBanner {
  text?: string;
  color?: string;
  bgColor?: string;
}
export type ObBannerConfig = ObTBanner | Signal<ObTBanner>;
export type ObTBanner = string | ObIBanner | undefined;
export interface ObIObliqueConfiguration {
  accessibilityStatement: ObIAccessibilityStatementConfiguration;
  historyState?: ObIHistoryState;
  banner?: ObBannerConfig;
  material?: ObIMaterialConfig;
  icon?: ObIconConfig;
  translate?: ObITranslateConfig;
  language?: ObLanguageConfig;
  consoleConfiguration?: ObConsoleConfiguration;
  pams?: ObIPamsConfiguration;
}
interface ObIHistoryState {
  initialLength: number;
}
type ObIObliqueTestingConfiguration = Omit<ObIObliqueConfiguration, 'accessibilityStatement'> & {
  accessibilityStatement?: ObIAccessibilityStatementConfiguration;
};
type NonEmptyArray<Type> = [Type, ...Type[]];
export type ObIAccessibilityStatementConfiguration = ObIAccessibilityStatementConfigurationPartial | ObIAccessibilityStatementConfigurationNonPartial;
interface ObIAccessibilityStatementConfigurationPartial extends ObIAccessibilityStatementConfigurationBase {
  exceptions: NonEmptyArray<string>;
  conformity: ObConformityPartial;
}
interface ObIAccessibilityStatementConfigurationNonPartial extends ObIAccessibilityStatementConfigurationBase {
  conformity: ObConformityNonPartial;
}
type ObConformityPartial = 'partial';
type ObConformityNonPartial = 'none' | 'full';
interface ObIAccessibilityStatementConfigurationBase {
  applicationName: string;
  createdOn: Date;
  reviewedOn?: Date;
  applicationOperator: string;
  contact: NonEmptyArray<ObContactData>;
}
type ObContactData = ObContactPhone | ObContactEmail | ObContactUrl;
interface ObContactEmail extends ObContactInfoBase {
  email: string;
  phone?: never;
  url?: never;
}
interface ObContactPhone extends ObContactInfoBase {
  email?: never;
  phone: string;
  url?: never;
}
interface ObContactUrl extends ObContactInfoBase {
  email?: never;
  phone?: never;
  url: string;
}
interface ObContactInfoBase {
  context?: string;
}
export declare class ObAuthenticationConfigService {
  useDiscoveryDocument: boolean;
  setupAutomaticSilentRefresh: boolean;
  private readonly oAuthService;
  configureFlow(authFlowConfig: AuthConfig, tokenValidationHandler?: ValidationHandler): Observable<boolean>;
  private setupAutomaticSilentRefreshIfConfigured;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAuthenticationConfigService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObAuthenticationService {
  readonly oAuthService: OAuthService;
  performLogin(additionalState?: string, params?: object): void;
  performLogout(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAuthenticationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export interface ObIResourceAccessRoles {
  name: string;
  roles: string[];
}
export declare class ObAuthenticationModule {
  constructor();
  /**
   * @remarks
   * The default validationHandlerClass "NullValidationHandler" does nothing. Another ValidationHandler should be provided by the user.
   *
   * @param config the OAuthModuleConfig given by the user. Default is null.
   * @param validationHandlerClass the ValidationHandler given by the user. Default is NullValidationHandler wich does nothing.
   */
  static forRoot(config?: OAuthModuleConfig, validationHandlerClass?: typeof NullValidationHandler): ModuleWithProviders<ObAuthenticationModule>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAuthenticationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObAuthenticationModule, never, [typeof i1$1.CommonModule, typeof i2$2.OAuthModule], never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObAuthenticationModule>;
}
interface ObIBreadcrumb {
  label: string;
  url: string;
}
export declare const ObTBreadcrumbConfig: InjectionToken<ObBreadcrumbConfig>;
export interface ObBreadcrumbConfig {
  maxWidth?: string;
  parameterSeparator?: string;
  beautifyUrls?: boolean;
}
export declare class ObBreadcrumbComponent implements OnInit {
  readonly maxWidthInput: import("@angular/core").InputSignal<string>;
  readonly separatorInput: import("@angular/core").InputSignal<string>;
  readonly beautifyUrlsInput: import("@angular/core").InputSignal<boolean>;
  breadcrumbs$: Observable<ObIBreadcrumb[]>;
  get maxWidth(): string | undefined;
  private get separator();
  private get beautifyUrls();
  private readonly router;
  private readonly route;
  private readonly translateService;
  private readonly config;
  ngOnInit(): void;
  getCrumbs(route: ActivatedRoute, crumbs?: ObIBreadcrumb[], currentUrl?: string): Observable<ObIBreadcrumb[]>;
  private createNextBreadcrumb;
  private replaceSyntax;
  private applyParams;
  private beautify;
  private getBreadcrumbData;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObBreadcrumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObBreadcrumbComponent, "ob-breadcrumb", ["obBreadcrumb"], {
    "maxWidthInput": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "separatorInput": {
      "alias": "parameterSeparator";
      "required": false;
      "isSignal": true;
    };
    "beautifyUrlsInput": {
      "alias": "beautifyUrls";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObBreadcrumbModule {
  static forRoot(config?: ObBreadcrumbConfig): ModuleWithProviders<ObBreadcrumbModule>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObBreadcrumbModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObBreadcrumbModule, never, [typeof ObBreadcrumbComponent], [typeof ObBreadcrumbComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObBreadcrumbModule>;
}
export declare class ObIconButtonDirective {
  private readonly isIconButton;
  private readonly hasTooltip;
  private readonly renderer;
  private readonly element;
  private readonly obConsole;
  constructor();
  private ensureVisibleText;
  private observeAriaDescribedbyChange;
  private adaptAriaAttributes;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObIconButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObIconButtonDirective, never, never, {}, {}, never, never, true, never>;
}
type ButtonVariant = 'primary' | 'secondary' | 'tertiary';
export declare class ObButtonDirective implements OnInit {
  readonly obButton: import("@angular/core").InputSignalWithTransform<ButtonVariant, unknown>;
  readonly primaryClass: import("@angular/core").Signal<boolean>;
  readonly secondaryClass: import("@angular/core").Signal<boolean>;
  readonly tertiaryClass: import("@angular/core").Signal<boolean>;
  private static readonly forbidden;
  private readonly element;
  private readonly obConsole;
  ngOnInit(): void;
  private validateButtonVariant;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObButtonDirective, "[obButton]", ["obButton"], {
    "obButton": {
      "alias": "obButton";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, [{
    directive: typeof ObIconButtonDirective;
    inputs: {};
    outputs: {};
  }]>;
}
export declare class ObButtonModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObButtonModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObButtonModule, never, [typeof ObButtonDirective, typeof ObIconButtonDirective], [typeof ObButtonDirective, typeof ObIconButtonDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObButtonModule>;
}
export declare const OBLIQUE_COLLAPSE_ACTIVE: InjectionToken<boolean>;
export declare const OBLIQUE_COLLAPSE_ICON_POSITION: InjectionToken<"none" | "left" | "right" | "justified">;
export declare const OBLIQUE_COLLAPSE_DURATION: InjectionToken<number | "slow" | "fast">;
export declare class ObCollapseComponent {
  static index: number;
  readonly contentHeight: import("@angular/core").WritableSignal<number>;
  /**
   *  @deprecated since Oblique 16.1.0. To be removed in Oblique 17.0.0.
   */
  readonly collapseToggle: import("@angular/core").Signal<ElementRef<HTMLDivElement>>;
  readonly collapseContent: import("@angular/core").Signal<ElementRef<HTMLDivElement>>;
  readonly id: import("@angular/core").InputSignal<string>;
  readonly iconPosition: import("@angular/core").InputSignal<"none" | "left" | "right" | "justified">;
  readonly active: import("@angular/core").ModelSignal<boolean>;
  readonly duration: import("@angular/core").InputSignal<number | "slow" | "fast">;
  readonly time: import("@angular/core").Signal<number>;
  constructor();
  onSpaceKeydown(event: Event): void;
  toggleActive(): void;
  private static getDuration;
  private updateContentHeight;
  private getContentHeight;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObCollapseComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObCollapseComponent, "ob-collapse", ["obCollapse"], {
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
  }, {
    "active": "activeChange";
  }, never, ["[obCollapseHeader]", "[obCollapseMain]"], true, never>;
}
export declare class ObCollapseModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObCollapseModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObCollapseModule, never, [typeof ObCollapseComponent], [typeof ObCollapseComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObCollapseModule>;
}
export type ObTColumnState = 'OPENED' | 'CLOSED' | 'NONE';
export declare class ObColumnLayoutComponent implements AfterViewInit, DoCheck, OnDestroy {
  readonly left: import("@angular/core").InputSignal<ObTColumnState>;
  readonly leftCollapsed: import("@angular/core").WritableSignal<boolean>;
  readonly right: import("@angular/core").InputSignal<ObTColumnState>;
  readonly rightCollapsed: import("@angular/core").WritableSignal<boolean>;
  readonly wider: import("@angular/core").InputSignal<boolean>;
  readonly noLayout: import("@angular/core").InputSignal<boolean>;
  private readonly toggles;
  private readonly el;
  private readonly renderer;
  private readonly unsubscribe;
  private readonly dimensionChange;
  private readonly window;
  private headerObserver;
  private hostObserver;
  ngDoCheck(): void;
  ngAfterViewInit(): void;
  ngOnDestroy(): void;
  toggleLeft(): void;
  toggleRight(): void;
  private measure;
  private getDimensionChangeObservable;
  private getHeaderHeightObservable;
  private getMasterLayout;
  private center;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObColumnLayoutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObColumnLayoutComponent, "ob-column-layout", ["obColumnLayout"], {
    "left": {
      "alias": "left";
      "required": false;
      "isSignal": true;
    };
    "right": {
      "alias": "right";
      "required": false;
      "isSignal": true;
    };
    "wider": {
      "alias": "wider";
      "required": false;
      "isSignal": true;
    };
    "noLayout": {
      "alias": "noLayout";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[column-left-content]", "[column-main-content]", "[column-right-content]"], true, never>;
}
export declare class ObColumnPanelDirective implements OnInit {
  readonly initialState: import("@angular/core").InputSignal<ObTColumnState>;
  readonly collapsed: import("@angular/core").ModelSignal<boolean>;
  ngOnInit(): void;
  toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObColumnPanelDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObColumnPanelDirective, "[obColumnPanel]", ["obColumnPanel"], {
    "initialState": {
      "alias": "initialState";
      "required": false;
      "isSignal": true;
    };
    "collapsed": {
      "alias": "collapsed";
      "required": false;
      "isSignal": true;
    };
  }, {
    "collapsed": "collapsedChange";
  }, never, never, true, never>;
}
export declare class ObColumnToggleDirective {
  private readonly parent;
  onclick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObColumnToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObColumnToggleDirective, "[obColumnToggle]", ["obColumnToggle"], {}, {}, never, never, true, never>;
}
export declare class ObColumnLayoutModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObColumnLayoutModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObColumnLayoutModule, never, [typeof ObColumnLayoutComponent, typeof ObColumnPanelDirective, typeof ObColumnToggleDirective], [typeof ObColumnLayoutComponent, typeof ObColumnPanelDirective, typeof ObColumnToggleDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObColumnLayoutModule>;
}
/**
 * DocumentMetaService - Service for updating document metadata
 *
 * Inspired & adapted from: https://gist.github.com/LA1CH3/718588765d56a8932de52c64c3561dcf
 */
export declare class ObDocumentMetaService implements OnDestroy {
  titleSeparator: string;
  titleSuffix: string;
  description: string;
  private readonly headElement;
  private readonly metaDescription;
  private readonly currentMetaInformation;
  private readonly unsubscribe;
  private readonly activatedRoute;
  private readonly titleService;
  private readonly translate;
  private readonly document;
  constructor();
  ngOnDestroy(): void;
  setTitle(title: string, separator?: string, suffix?: string): void;
  getMetaDescription(): string;
  setDescription(description: string): void;
  private getOrCreateMetaElement;
  private updateMetaInformation;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDocumentMetaService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObDocumentMetaModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDocumentMetaModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObDocumentMetaModule, never, [typeof i1$1.CommonModule, typeof i2$1.TranslatePipe], never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObDocumentMetaModule>;
}
export declare class ObErrorMessagesDirective implements AfterViewInit {
  readonly matInput: import("@angular/core").Signal<MatInput>;
  readonly matSelect: import("@angular/core").Signal<MatSelect>;
  readonly prefix: import("@angular/core").InputSignal<string>;
  readonly errors$: Observable<ValidationErrors>;
  private readonly errors;
  private readonly form;
  private readonly destroyRef;
  constructor();
  ngAfterViewInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObErrorMessagesDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObErrorMessagesDirective, "[obErrorMessages]", ["obErrorMessages"], {
    "prefix": {
      "alias": "prefix";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["matInput", "matSelect"], never, true, never>;
}
export declare class ObMatErrorDirective implements OnInit, OnDestroy {
  private readonly control;
  private readonly el;
  private readonly pipe;
  private errors;
  private readonly unsubscribe;
  private readonly obMatErrorPrefix;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  private showErrors;
  private getErrorTranslation;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMatErrorDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMatErrorDirective, "mat-error", never, {}, {}, never, never, true, never>;
}
export declare class ObTranslateParamsPipe implements PipeTransform {
  private readonly translate;
  transform(value: string, params?: any): string;
  private translateParams;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObTranslateParamsPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObTranslateParamsPipe, "obTranslateParams", true>;
}
export declare class ObErrorMessagesModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObErrorMessagesModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObErrorMessagesModule, never, [typeof ObErrorMessagesDirective, typeof ObMatErrorDirective, typeof ObTranslateParamsPipe], [typeof ObErrorMessagesDirective, typeof ObMatErrorDirective, typeof ObTranslateParamsPipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObErrorMessagesModule>;
}
export type ObEExternalLinkIcon = 'left' | 'right' | 'none';
export interface ObIExternalLink {
  rel: string;
  target: '_blank' | '_self' | '_parent' | '_top' | string;
  icon: ObEExternalLinkIcon;
  isExternalLink: boolean | 'auto';
}
export declare const EXTERNAL_LINK: InjectionToken<ObIExternalLink>;
export declare class ObExternalLinkDirective implements OnInit, OnChanges {
  readonly href: import("@angular/core").InputSignal<string>;
  readonly rel: import("@angular/core").InputSignal<string>;
  readonly target: import("@angular/core").InputSignal<string>;
  readonly config: import("@oblique/oblique").ObIExternalLink;
  readonly isExternalLink: import("@angular/core").InputSignal<boolean | "auto">;
  isLinkExternal: boolean;
  readonly icon: import("@angular/core").InputSignal<ObEExternalLinkIcon>;
  readonly internalRel: import("@angular/core").WritableSignal<string>;
  readonly internalTarget: import("@angular/core").WritableSignal<string>;
  private readonly destroyRef;
  private iconElement;
  private readonly host;
  private hasIcon;
  private readonly screenReaderOnlyTextElement;
  private readonly isLinkExternal$;
  private defaultRel;
  private defaultTarget;
  private readonly window;
  private readonly renderer;
  private readonly translate;
  private readonly iconRegistry;
  constructor();
  ngOnInit(): void;
  ngOnChanges(): void;
  private isLinkOriginExternal;
  private manageLink;
  private static initializeAttribute;
  private addScreenReaderOnlyTextElement;
  private removeScreenReaderOnlyTextElement;
  private translateScreenReaderOnlyText;
  private addIcon;
  private removeIcon;
  private createIconElement;
  private createScreenReaderOnlyTextElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObExternalLinkDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObExternalLinkDirective, "a", never, {
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
    "rel": {
      "alias": "rel";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "isExternalLink": {
      "alias": "isExternalLink";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObExternalLinkModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObExternalLinkModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObExternalLinkModule, never, [typeof ObExternalLinkDirective], [typeof ObExternalLinkDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObExternalLinkModule>;
}
declare class ObAcceptAllPipe implements PipeTransform {
  transform(allowedTypes: string[]): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAcceptAllPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObAcceptAllPipe, "obAcceptAll", true>;
}
export type ObIAlertType = 'info' | 'success' | 'warning' | 'error';
export declare const OBLIQUE_HAS_ROLE_ALERT: InjectionToken<boolean>;
export declare class ObAlertComponent implements OnInit {
  readonly info: Signal<boolean>;
  readonly success: Signal<boolean>;
  readonly warning: Signal<boolean>;
  readonly error: Signal<boolean>;
  readonly role: Signal<'alert' | undefined>;
  readonly icon: Signal<string>;
  readonly type: import("@angular/core").InputSignal<ObIAlertType>;
  readonly hasRoleAlert: import("@angular/core").InputSignal<boolean>;
  private readonly hasGlobalAlertRole;
  private readonly initialRole;
  private readonly matIconRegistry;
  private readonly domSanitizer;
  constructor();
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAlertComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObAlertComponent, "ob-alert", never, {
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "hasRoleAlert": {
      "alias": "hasRoleAlert";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class ObAlertModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAlertModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObAlertModule, never, [typeof ObAlertComponent], [typeof ObAlertComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObAlertModule>;
}
declare class ObDragDropDirective {
  readonly fileDropped: import("@angular/core").OutputEmitterRef<FileList>;
  protected readonly isDragging: import("@angular/core").WritableSignal<boolean>;
  onDragOver(event: DragEvent): void;
  onDragLeave(event: DragEvent): void;
  ondrop(event: DragEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDragDropDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObDragDropDirective, "[obDragDrop]", never, {}, {
    "fileDropped": "fileDropped";
  }, never, never, true, never>;
}
interface ObIFileList {
  fileCount: number;
  files: ObIFile[];
}
interface ObIFile {
  index: number;
  name?: string;
  completed: boolean;
  progress: number;
  hasError: boolean;
  binary: File | File[];
  subscription: Subscription;
}
export interface ObIFileDescription {
  name: string;
  [key: string]: unknown;
}
export interface ObIUploadEvent {
  type: ObEUploadEventType;
  files: File[] | string[];
  error?: HttpErrorResponse;
}
export declare enum ObEUploadEventType {
  CHOSEN = "chosen",
  UPLOADED = "uploaded",
  SELECTED = "selected",
  DELETED = "deleted",
  CANCELED = "canceled",
  ERRORED = "errored"
}
type ObTEventType = HttpEventType.UploadProgress | HttpEventType.Response | HttpEventType.User;
type ObTSelectionStatus = 'none' | 'some' | 'all';
export declare class ObDropZoneComponent {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly accept: import("@angular/core").InputSignal<string[]>;
  readonly maxFileSize: import("@angular/core").InputSignal<number>;
  readonly maxFileAmount: import("@angular/core").InputSignal<number>;
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  private readonly fileInput;
  private readonly validationService;
  addFiles(fileList: FileList): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDropZoneComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObDropZoneComponent, "ob-drop-zone", ["obDropZone"], {
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "maxFileAmount": {
      "alias": "maxFileAmount";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
export declare class ObFileInfoComponent implements OnInit, OnDestroy {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly deleteUrl: import("@angular/core").InputSignal<string>;
  readonly getUploadedFilesUrl: import("@angular/core").InputSignal<string>;
  readonly sorting: import("@angular/core").Signal<MatSort>;
  readonly mapFunction: import("@angular/core").InputSignal<(files: ObIFileDescription[]) => ObIFileDescription[]>;
  readonly mapFilesToDeleteUrlFunction: import("@angular/core").InputSignal<(files: ObIFileDescription[]) => string>;
  dataSource: MatTableDataSource<ObIFileDescription, MatPaginator>;
  readonly displayedColumns: import("@angular/core").WritableSignal<string[]>;
  fields: string[];
  selectionStatus: ObTSelectionStatus;
  readonly selection: SelectionModel<ObIFileDescription>;
  readonly COLUMN_SELECT = "select";
  readonly COLUMN_ACTION = "action";
  private readonly fileUploadService;
  private readonly translate;
  private readonly unsubscribe;
  private readonly dataChange;
  private readonly window;
  constructor();
  ngOnInit(): void;
  ngOnDestroy(): void;
  selectOrUnselectAllItems(): void;
  toggle(row: ObIFileDescription): void;
  delete(files: ObIFileDescription[]): void;
  private loadData;
  private reselectFiles;
  private initializeSort;
  private setTableHeaders;
  private computeSelectionStatus;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFileInfoComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObFileInfoComponent, "ob-file-info", ["obFileInfo"], {
    "deleteUrl": {
      "alias": "deleteUrl";
      "required": false;
      "isSignal": true;
    };
    "getUploadedFilesUrl": {
      "alias": "getUploadedFilesUrl";
      "required": false;
      "isSignal": true;
    };
    "mapFunction": {
      "alias": "mapFunction";
      "required": false;
      "isSignal": true;
    };
    "mapFilesToDeleteUrlFunction": {
      "alias": "mapFilesToDeleteUrlFunction";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
export declare class ObFileUploadComponent {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly accept: import("@angular/core").InputSignal<string[]>;
  readonly singleRequest: import("@angular/core").InputSignal<boolean>;
  readonly maxFileSize: import("@angular/core").InputSignal<number>;
  readonly maxFileAmount: import("@angular/core").InputSignal<number>;
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  readonly uploadUrl: import("@angular/core").InputSignal<string>;
  readonly cancelConfirmation: import("@angular/core").InputSignal<boolean>;
  readonly showLoadingBox: import("@angular/core").WritableSignal<boolean>;
  readonly files: import("@angular/core").WritableSignal<File[]>;
  processEvent(event: ObIUploadEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFileUploadComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObFileUploadComponent, "ob-file-upload", ["obFileUpload"], {
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "singleRequest": {
      "alias": "singleRequest";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "maxFileAmount": {
      "alias": "maxFileAmount";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "uploadUrl": {
      "alias": "uploadUrl";
      "required": false;
      "isSignal": true;
    };
    "cancelConfirmation": {
      "alias": "cancelConfirmation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
export interface ObINotification {
  idPrefix?: string;
  type?: ObENotificationType;
  message?: string;
  messageParams?: Record<string, any>;
  title?: string;
  titleParams?: Record<string, any>;
  channel?: string;
  sticky?: boolean;
  timeout?: number;
  groupSimilar?: boolean;
}
interface ObINotificationPrivate extends ObINotification {
  $state: WritableSignal<string>;
  occurrences: WritableSignal<number>;
  timer?: number;
}
export interface ObINotificationConfig {
  channel?: string;
  sticky?: boolean;
  timeout?: number;
  title?: string;
  groupSimilar?: boolean;
}
export declare enum ObENotificationType {
  INFO = "info",
  SUCCESS = "success",
  WARNING = "warning",
  ERROR = "error"
}
export declare enum ObENotificationPlacement {
  BOTTOM_LEFT = "ob-bottom-left",
  BOTTOM_RIGHT = "ob-bottom-right",
  TOP_LEFT = "ob-top-left",
  TOP_RIGHT = "ob-top-right"
}
export declare class ObNotificationComponent {
  static REMOVE_DELAY: number;
  readonly channel: import("@angular/core").InputSignal<string>;
  readonly currentChannel: import("@angular/core").Signal<string>;
  readonly customChannel: import("@angular/core").Signal<boolean>;
  readonly notifications: import("@angular/core").WritableSignal<ObINotificationPrivate[]>;
  get getPlacement(): ObENotificationPlacement;
  variant: Record<string, string>;
  private readonly window;
  private readonly notificationService;
  constructor();
  /**
   * Adds & opens the specified notification.
   */
  open(notification: ObINotification): void;
  /**
   * Closes & removes the specified notification.
   *
   * @see remove
   */
  close(notification: ObINotificationPrivate): void;
  /**
   * Removes the specified notification without triggering a _close_ animation.
   */
  remove(notification: ObINotificationPrivate): void;
  /**
   * Closes all notifications in the current subscribed channel.
   */
  clear(): void;
  private extendNotification;
  private getOpenState;
  private isPlacementOnLeft;
  private selfClose;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNotificationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObNotificationComponent, "ob-notification", ["obNotification"], {
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare const CLEAR_NOTIFICATIONS_ON_ROUTE_CHANGE: InjectionToken<boolean>;
export declare const GROUP_SIMILAR_NOTIFICATIONS: InjectionToken<boolean>;
export declare class ObNotificationConfig {
  sticky: boolean;
  timeout: number;
  channel: string;
  clearAllOnNavigate: boolean;
  groupSimilar: boolean;
  placement: ObENotificationPlacement;
  info: ObINotificationConfig;
  success: ObINotificationConfig;
  warning: ObINotificationConfig;
  error: ObINotificationConfig;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNotificationConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Service for the `NotificationComponent`. Can be configured using `NotificationConfig`.
 *
 * @see NotificationComponent
 * @see NotificationConfig
 */
export declare class ObNotificationService {
  config: ObNotificationConfig;
  clearAllOnNavigate: boolean;
  placement: ObENotificationPlacement;
  private readonly eventSubject;
  private readonly events$;
  constructor();
  get events(): Observable<ObINotification>;
  /**
   * Sends an _info_ notification.
   */
  info(config: ObINotification | string): ObINotification;
  /**
   * Sends a _success_ notification.
   */
  success(config: ObINotification | string): ObINotification;
  /**
   * Sends a _warning_ notification.
   */
  warning(config: ObINotification | string): ObINotification;
  /**
   * Sends an _error_ notification.
   */
  error(config: ObINotification | string): ObINotification;
  send(config: ObINotification | string, type?: ObENotificationType): ObINotification;
  /**
   * Broadcasts an event to clear all notifications from specified `channel`.
   */
  clear(channel?: string): void;
  /**
   * Broadcasts an event to clear all notifications from any available.
   */
  clearAll(): void;
  private broadcast;
  private formatMessage;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNotificationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObNotificationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNotificationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObNotificationModule, never, [typeof ObNotificationComponent], [typeof ObNotificationComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObNotificationModule>;
}
declare class ObProgressComponent implements OnDestroy {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly singleRequest: import("@angular/core").InputSignal<boolean>;
  readonly uploadUrl: import("@angular/core").InputSignal<string>;
  readonly cancelConfirmation: import("@angular/core").InputSignal<boolean>;
  readonly files: import("@angular/core").InputSignal<File[]>;
  uploadedFiles: ObIFileList;
  private readonly changeDetectorRef;
  private readonly fileUploadService;
  private readonly translate;
  private readonly window;
  constructor();
  ngOnDestroy(): void;
  cancelUpload(file: ObIFile): void;
  retryUpload(file: ObIFile): void;
  private uploadFiles;
  private uploadFilesIndividually;
  private uploadSingleFile;
  private isUploadComplete;
  private uploadFilesTogether;
  private updateFileProgress;
  private convertToObIFile;
  private arrayifyFiles;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObProgressComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObProgressComponent, "ob-progress", never, {
    "singleRequest": {
      "alias": "singleRequest";
      "required": false;
      "isSignal": true;
    };
    "uploadUrl": {
      "alias": "uploadUrl";
      "required": false;
      "isSignal": true;
    };
    "cancelConfirmation": {
      "alias": "cancelConfirmation";
      "required": false;
      "isSignal": true;
    };
    "files": {
      "alias": "files";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
export declare class ObFileUploadService {
  uploadComplete$: Observable<void>;
  private readonly uploadComplete;
  private readonly events;
  private readonly httpClient;
  private readonly notification;
  constructor();
  multiUpload(uploadUrl: string, files: File[]): Observable<HttpEvent<ObTEventType>>;
  upload(uploadUrl: string, file: File): Observable<HttpEvent<ObTEventType>>;
  notifyUploadComplete(): void;
  getUploadedFiles(getUploadedFilesUrl: string): Observable<ObIFileDescription[]>;
  delete(deleteUrl: string, files: string[] | string): Observable<unknown>;
  private sendUploadRequest;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFileUploadService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObFileUploadModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFileUploadModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObFileUploadModule, never, [typeof i1$1.CommonModule, typeof i2.MatButtonModule, typeof i3.MatCheckboxModule, typeof i4.MatIconModule, typeof i5.MatProgressBarModule, typeof i6.MatSortModule, typeof i7.MatTableModule, typeof i8.MatTooltipModule, typeof ObAcceptAllPipe, typeof ObAlertModule, typeof ObButtonModule, typeof ObDragDropDirective, typeof ObDropZoneComponent, typeof ObFileInfoComponent, typeof ObFileUploadComponent, typeof ObNotificationModule, typeof ObProgressComponent, typeof i2$1.TranslatePipe], [typeof ObDropZoneComponent, typeof ObFileInfoComponent, typeof ObFileUploadComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObFileUploadModule>;
}
export declare class ObFocusInvalidDirective {
  readonly formElements: import("@angular/core").Signal<readonly ElementRef<any>[]>;
  focusFirstInvalidField(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFocusInvalidDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObFocusInvalidDirective, "form[obFocusInvalid]", ["obFocusInvalid"], {}, {}, ["formElements"], never, true, never>;
}
export declare class ObFocusInvalidModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObFocusInvalidModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObFocusInvalidModule, never, [typeof ObFocusInvalidDirective], [typeof ObFocusInvalidDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObFocusInvalidModule>;
}
interface ObIServiceNavigationBackendInfo {
  description?: string;
  helpText?: string;
  links?: ObIServiceNavigationLink[];
  contactText?: string;
  contact?: ObIServiceNavigationContact;
}
export declare class ObServiceNavigationComponent implements OnInit {
  readonly profileLinks: import("@angular/core").InputSignal<ObIServiceNavigationLink[]>;
  readonly infoDescription: import("@angular/core").InputSignal<string>;
  readonly infoHelpText: import("@angular/core").InputSignal<string>;
  readonly infoLinks: import("@angular/core").InputSignal<ObIServiceNavigationLink[]>;
  readonly infoContactText: import("@angular/core").InputSignal<string>;
  readonly infoContact: import("@angular/core").InputSignal<ObIServiceNavigationContact>;
  readonly maxFavoriteApplications: import("@angular/core").InputSignal<number>;
  readonly environment: import("@angular/core").InputSignal<ObEPamsEnvironment>;
  readonly rootUrl: import("@angular/core").InputSignal<string>;
  readonly returnUrl: import("@angular/core").InputSignal<string>;
  readonly replaceLoginUrl: import("@angular/core").InputSignal<string>;
  readonly replaceLogoutUrl: import("@angular/core").InputSignal<string>;
  readonly pamsAppId: import("@angular/core").InputSignal<string>;
  readonly displayMessage: import("@angular/core").InputSignal<boolean>;
  readonly useInfoBackend: import("@angular/core").InputSignal<boolean>;
  readonly displayInfo: import("@angular/core").InputSignal<boolean>;
  readonly displayApplications: import("@angular/core").InputSignal<boolean>;
  readonly displayProfile: import("@angular/core").InputSignal<boolean>;
  readonly displayAuthentication: import("@angular/core").InputSignal<boolean>;
  readonly displayLanguages: import("@angular/core").InputSignal<boolean>;
  readonly handleLogout: import("@angular/core").InputSignal<boolean>;
  readonly eportalLanguageSynchronization: import("@angular/core").InputSignal<boolean>;
  /**
   * @deprecated since version 16.1. It will be removed with Oblique 17. Use qualityOfAuthenticationChange instead
   */
  readonly loginStateChange: import("@angular/core").OutputRef<ObLoginState>;
  readonly qualityOfAuthenticationChange: import("@angular/core").OutputRef<ObEQualityOfAuthentication>;
  readonly logoutTriggered: import("@angular/core").OutputRef<string>;
  readonly customWidgetTemplate: import("@angular/core").Signal<readonly TemplateRef<unknown>[]>;
  readonly loginUrl: import("@angular/core").Signal<unknown>;
  /**
   * @deprecated since version 16.1. It will be removed with Oblique 17. Use qualityOfAuthentication instead
   */
  readonly loginState: import("@angular/core").Signal<any>;
  readonly qualityOfAuthentication: import("@angular/core").Signal<ObEQualityOfAuthentication>;
  readonly userName: import("@angular/core").Signal<string>;
  readonly profileUrls: import("@angular/core").Signal<ObISectionLink[]>;
  readonly inboxMailUrl: import("@angular/core").Signal<string>;
  readonly messageCount: import("@angular/core").Signal<number>;
  readonly applicationsUrl: import("@angular/core").Signal<string>;
  readonly lastUsedApplications: import("@angular/core").Signal<ObIServiceNavigationApplication[]>;
  readonly favoriteApplications: import("@angular/core").Signal<ObIServiceNavigationApplication[]>;
  readonly language: import("@angular/core").Signal<string>;
  readonly languages: import("@angular/core").Signal<{
    code: string;
    label: any;
  }[]>;
  readonly infoBackend: import("@angular/core").Signal<ObIServiceNavigationBackendInfo>;
  /** The effective info content, from the backend if `useInfoBackend` is set `true` or from the configured inputs. */
  readonly effectiveInfo: import("@angular/core").Signal<ObIServiceNavigationBackendInfo>;
  private readonly headerControlsService;
  private readonly info;
  constructor();
  ngOnInit(): void;
  changeLanguage(language: string): void;
  logoutClick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationComponent, "ob-service-navigation", never, {
    "profileLinks": {
      "alias": "profileLinks";
      "required": false;
      "isSignal": true;
    };
    "infoDescription": {
      "alias": "infoDescription";
      "required": false;
      "isSignal": true;
    };
    "infoHelpText": {
      "alias": "infoHelpText";
      "required": false;
      "isSignal": true;
    };
    "infoLinks": {
      "alias": "infoLinks";
      "required": false;
      "isSignal": true;
    };
    "infoContactText": {
      "alias": "infoContactText";
      "required": false;
      "isSignal": true;
    };
    "infoContact": {
      "alias": "infoContact";
      "required": false;
      "isSignal": true;
    };
    "maxFavoriteApplications": {
      "alias": "maxFavoriteApplications";
      "required": false;
      "isSignal": true;
    };
    "environment": {
      "alias": "environment";
      "required": false;
      "isSignal": true;
    };
    "rootUrl": {
      "alias": "rootUrl";
      "required": false;
      "isSignal": true;
    };
    "returnUrl": {
      "alias": "returnUrl";
      "required": false;
      "isSignal": true;
    };
    "replaceLoginUrl": {
      "alias": "replaceLoginUrl";
      "required": false;
      "isSignal": true;
    };
    "replaceLogoutUrl": {
      "alias": "replaceLogoutUrl";
      "required": false;
      "isSignal": true;
    };
    "pamsAppId": {
      "alias": "pamsAppId";
      "required": false;
      "isSignal": true;
    };
    "displayMessage": {
      "alias": "displayMessage";
      "required": false;
      "isSignal": true;
    };
    "useInfoBackend": {
      "alias": "useInfoBackend";
      "required": false;
      "isSignal": true;
    };
    "displayInfo": {
      "alias": "displayInfo";
      "required": false;
      "isSignal": true;
    };
    "displayApplications": {
      "alias": "displayApplications";
      "required": false;
      "isSignal": true;
    };
    "displayProfile": {
      "alias": "displayProfile";
      "required": false;
      "isSignal": true;
    };
    "displayAuthentication": {
      "alias": "displayAuthentication";
      "required": false;
      "isSignal": true;
    };
    "displayLanguages": {
      "alias": "displayLanguages";
      "required": false;
      "isSignal": true;
    };
    "handleLogout": {
      "alias": "handleLogout";
      "required": false;
      "isSignal": true;
    };
    "eportalLanguageSynchronization": {
      "alias": "eportalLanguageSynchronization";
      "required": false;
      "isSignal": true;
    };
  }, {
    "loginStateChange": "loginStateChange";
    "qualityOfAuthenticationChange": "qualityOfAuthenticationChange";
    "logoutTriggered": "logoutTriggered";
  }, ["customWidgetTemplate"], never, false, never>;
}
declare class ObContactToLinksPipe implements PipeTransform {
  transform(values?: ObIServiceNavigationContact): ObISectionLink[];
  private getMail;
  private getPhone;
  private getContact;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObContactToLinksPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObContactToLinksPipe, "obContactToLinks", false>;
}
declare class ObIsUserLoggedInPipe implements PipeTransform {
  transform(qualityOfLife: ObEQualityOfAuthentication | undefined): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObIsUserLoggedInPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObIsUserLoggedInPipe, "obIsUserLoggedIn", false>;
}
declare class ObServiceNavigationApplicationNameStatusPipe implements PipeTransform {
  private readonly translateService;
  transform(application: ObIServiceNavigationApplication): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationApplicationNameStatusPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObServiceNavigationApplicationNameStatusPipe, "ObServiceNavigationApplicationNameStatus", false>;
}
declare class ObServiceNavigationApplicationsComponent {
  readonly applicationsUrl: import("@angular/core").InputSignal<string>;
  readonly isLoggedIn: import("@angular/core").InputSignal<boolean>;
  readonly lastUsedApplications: import("@angular/core").InputSignal<ObIServiceNavigationApplication[]>;
  readonly favoriteApplications: import("@angular/core").InputSignal<ObIServiceNavigationApplication[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationApplicationsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationApplicationsComponent, "ob-service-navigation-applications", never, {
    "applicationsUrl": {
      "alias": "applicationsUrl";
      "required": false;
      "isSignal": true;
    };
    "isLoggedIn": {
      "alias": "isLoggedIn";
      "required": false;
      "isSignal": true;
    };
    "lastUsedApplications": {
      "alias": "lastUsedApplications";
      "required": false;
      "isSignal": true;
    };
    "favoriteApplications": {
      "alias": "favoriteApplications";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, false, never>;
}
declare class ObServiceNavigationAuthenticationComponent {
  readonly loginUrl: import("@angular/core").InputSignal<string>;
  readonly isLoggedIn: import("@angular/core").InputSignal<boolean>;
  readonly logoutClicked: import("@angular/core").OutputEmitterRef<void>;
  logoutClick(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationAuthenticationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationAuthenticationComponent, "ob-service-navigation-authentication", never, {
    "loginUrl": {
      "alias": "loginUrl";
      "required": false;
      "isSignal": true;
    };
    "isLoggedIn": {
      "alias": "isLoggedIn";
      "required": false;
      "isSignal": true;
    };
  }, {
    "logoutClicked": "logoutClicked";
  }, never, never, false, never>;
}
declare class ObServiceNavigationInfoComponent {
  readonly helpText: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string>;
  readonly links: import("@angular/core").InputSignal<ObIServiceNavigationLink[]>;
  readonly contactText: import("@angular/core").InputSignal<string>;
  readonly contact: import("@angular/core").InputSignal<ObIServiceNavigationContact>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationInfoComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationInfoComponent, "ob-service-navigation-info", never, {
    "helpText": {
      "alias": "helpText";
      "required": false;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "links": {
      "alias": "links";
      "required": false;
      "isSignal": true;
    };
    "contactText": {
      "alias": "contactText";
      "required": false;
      "isSignal": true;
    };
    "contact": {
      "alias": "contact";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, false, never>;
}
declare class ObServiceNavigationLanguagesComponent {
  readonly language: import("@angular/core").ModelSignal<string>;
  readonly languages: import("@angular/core").InputSignal<ObILanguage[]>;
  readonly chevron: import("@angular/core").WritableSignal<"chevron_down" | "chevron_up">;
  protected readonly languageLabel: import("@angular/core").Signal<string>;
  changeChevron(): void;
  changeLanguage(language: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationLanguagesComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationLanguagesComponent, "ob-service-navigation-languages", never, {
    "language": {
      "alias": "language";
      "required": false;
      "isSignal": true;
    };
    "languages": {
      "alias": "languages";
      "required": false;
      "isSignal": true;
    };
  }, {
    "language": "languageChange";
  }, never, never, false, never>;
}
declare class ObServiceNavigationMessageComponent {
  readonly linkHref: import("@angular/core").InputSignal<string>;
  readonly count: import("@angular/core").InputSignal<number>;
  readonly tooManyCount: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationMessageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationMessageComponent, "ob-service-navigation-message", never, {
    "linkHref": {
      "alias": "linkHref";
      "required": false;
      "isSignal": true;
    };
    "count": {
      "alias": "count";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, false, never>;
}
declare class ObServiceNavigationPopoverSectionComponent {
  readonly header: import("@angular/core").InputSignal<string>;
  readonly links: import("@angular/core").InputSignal<ObISectionLink[]>;
  readonly text: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationPopoverSectionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationPopoverSectionComponent, "ob-service-navigation-popover-section", never, {
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "links": {
      "alias": "links";
      "required": false;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[obHeaderPrefix]", "[obContent]"], false, never>;
}
declare class ObServiceNavigationProfileComponent {
  readonly userName: import("@angular/core").InputSignal<string>;
  readonly profileUrls: import("@angular/core").InputSignal<ObISectionLink[]>;
  readonly links: import("@angular/core").InputSignal<ObIServiceNavigationLink[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationProfileComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObServiceNavigationProfileComponent, "ob-service-navigation-profile", never, {
    "userName": {
      "alias": "userName";
      "required": false;
      "isSignal": true;
    };
    "profileUrls": {
      "alias": "profileUrls";
      "required": false;
      "isSignal": true;
    };
    "links": {
      "alias": "links";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, false, never>;
}
declare class ObDisableLinkDirective {
  readonly obDisableLink: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly href: import("@angular/core").InputSignal<string>;
  protected readonly disabled: import("@angular/core").Signal<string>;
  protected readonly role: import("@angular/core").Signal<string>;
  protected readonly attributeHref: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDisableLinkDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObDisableLinkDirective, "[obDisableLink]", never, {
    "obDisableLink": {
      "alias": "obDisableLink";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare enum ObEToggleType {
  CLICK = 0,
  HOVER = 1
}
export declare const OBLIQUE_POPOVER_TOGGLE_HANDLE: InjectionToken<ObEToggleType>;
export declare const OBLIQUE_POPOVER_CLOSE_ONLY_ON_TOGGLE: InjectionToken<boolean>;
export declare class ObPopoverDirective implements OnInit, OnChanges, OnDestroy {
  readonly target: import("@angular/core").InputSignal<TemplateRef<HTMLElement>>;
  readonly placement: import("@angular/core").InputSignal<Placement>;
  readonly popperOptions: import("@angular/core").InputSignal<Options>;
  readonly id: import("@angular/core").InputSignal<string>;
  readonly panelContentId: import("@angular/core").InputSignal<string>;
  readonly toggleHandle: import("@angular/core").InputSignal<ObEToggleType>;
  readonly closeOnlyOnToggle: import("@angular/core").InputSignal<boolean>;
  readonly appendToBody: import("@angular/core").InputSignal<boolean>;
  readonly visibilityChange: import("@angular/core").OutputEmitterRef<boolean>;
  idContent: string;
  isExpanded: boolean;
  private static idCount;
  private readonly body;
  private readonly host;
  private instance;
  private popover;
  private isMouseHoverConfigured;
  private isCloseOnlyOnToggleConfigured;
  private readonly globalEventsService;
  private readonly viewContainerRef;
  private readonly renderer;
  private readonly globalToggleHandle;
  private readonly globalCloseOnlyOnToggle;
  private readonly window;
  constructor();
  ngOnInit(): void;
  ngOnChanges(): void;
  ngOnDestroy(): void;
  toggle(event?: KeyboardEvent | MouseEvent): void;
  handleMouseLeave(): void;
  handleMouseEnter(): void;
  close(): void;
  open(): void;
  private updateToggleMethod;
  private getToggleMethod;
  private updateCloseOnlyOnToggle;
  private setPopperOptionsAndUpdate;
  private buildPopover;
  private listenForCloseEvent;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObPopoverDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObPopoverDirective, "[obPopover]", ["obPopover"], {
    "target": {
      "alias": "obPopover";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "popperOptions": {
      "alias": "popperOptions";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "panelContentId": {
      "alias": "panelContentId";
      "required": false;
      "isSignal": true;
    };
    "toggleHandle": {
      "alias": "toggleHandle";
      "required": false;
      "isSignal": true;
    };
    "closeOnlyOnToggle": {
      "alias": "closeOnlyOnToggle";
      "required": false;
      "isSignal": true;
    };
    "appendToBody": {
      "alias": "appendToBody";
      "required": false;
      "isSignal": true;
    };
  }, {
    "visibilityChange": "visibilityChange";
  }, never, never, true, never>;
}
export declare class ObPopoverModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObPopoverModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObPopoverModule, never, [typeof ObPopoverDirective], [typeof ObPopoverDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObPopoverModule>;
}
export declare class ObTranslateParamsModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObTranslateParamsModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObTranslateParamsModule, never, [typeof ObTranslateParamsPipe], [typeof ObTranslateParamsPipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObTranslateParamsModule>;
}
declare class ObIsCurrentUrlPipe implements PipeTransform {
  private readonly window;
  transform(url: string): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObIsCurrentUrlPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObIsCurrentUrlPipe, "obIsCurrentUrl", true>;
}
export declare class ObServiceNavigationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObServiceNavigationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObServiceNavigationModule, [typeof ObContactToLinksPipe, typeof ObIsUserLoggedInPipe, typeof ObServiceNavigationApplicationNameStatusPipe, typeof ObServiceNavigationApplicationsComponent, typeof ObServiceNavigationAuthenticationComponent, typeof ObServiceNavigationComponent, typeof ObServiceNavigationInfoComponent, typeof ObServiceNavigationLanguagesComponent, typeof ObServiceNavigationMessageComponent, typeof ObServiceNavigationPopoverSectionComponent, typeof ObServiceNavigationProfileComponent], [typeof i1$1.CommonModule, typeof i13.MatBadgeModule, typeof i2.MatButtonModule, typeof i4.MatIconModule, typeof i16.MatSelectModule, typeof i8.MatTooltipModule, typeof i18.A11yModule, typeof i1$1.NgOptimizedImage, typeof ObButtonModule, typeof ObDisableLinkDirective, typeof ObExternalLinkModule, typeof ObPopoverModule, typeof ObTranslateParamsModule, typeof ObIsCurrentUrlPipe, typeof i2$1.TranslatePipe], [typeof ObServiceNavigationComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObServiceNavigationModule>;
}
/**
 * @deprecated since 16.0.0, will be removed with version 17. Use provideObliqueConfiguration.pams instead
 */
export declare const OB_PAMS_CONFIGURATION: InjectionToken<ObIPamsConfiguration>;
/**
 * Configuration service for the Oblique HTTP interceptor.
 *
 * @link HttpApiInterceptor
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the Oblique HTTP interceptor, if imported as `HTTP_INTERCEPTORS` provider.
 */
export declare class ObHttpApiInterceptorConfig {
  /**
   * Configuration for application API.
   */
  api: {
    /**
     * Default application API URL for matching API calls.
     */
    url: string;
    /**
     * Defines if spinner should be activated whenever an API request starts.
     */
    spinner: boolean;
    /**
     * Defines the spinner channel used whenever an API request starts.
     * This value must only be set together with `spinner = true`.
     */
    spinnerChannel: string;
    /**
     * Configuration of notification on error
     */
    notification: {
      /**
       * Defines if notification are displayed at all
       */
      active: boolean;
      /**
       * Defines the severity (type) of the notification
       */
      severity: ObENotificationType;
      /**
       * Defines the title of the notification
       * @default error.statusText
       */
      title: any;
      /**
       * Defines the text of the notification
       * @default 'i18n.error.http.status.' + error.status
       */
      text: any;
      sticky: any;
    };
  };
  /**
   * The timeout delay to wait before a request will be considered as failed.
   * A notification will be issued to warn the user about request timeout, but the request itself won't be cancelled.
   * If the timeout is zero, null or undefined, no warning will be issued
   */
  timeout: number;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObHttpApiInterceptorConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export interface ObIHttpApiRequest {
  /**
   * Notification configuration applied to the intercepted request.
   */
  notification: ObIHttpApiRequestNotification;
  /**
   * Defines whether the interceptor should activate a spinner for the intercepted request.
   */
  spinner: boolean;
  /**
   * Defines the spinner channel used for the intercepted request.
   */
  spinnerChannel: string;
}
export interface ObIHttpApiRequestNotification {
  active: boolean;
  severity: ObENotificationType;
  title: string;
  text: string;
  sticky: boolean;
}
export interface ObIObliqueHttpErrorResponse {
  error: HttpErrorResponse;
  handled: boolean;
}
/**
 * Provides access to the Oblique HTTP Interceptor events.
 */
export declare class ObHttpApiInterceptorEvents {
  protected requested: Subject<ObIHttpApiRequest>;
  protected expired: Subject<void>;
  private readonly requestIntercepted$;
  private readonly sessionExpired$;
  /**
   * This will be fed with `requested` events
   */
  get requestIntercepted(): Observable<ObIHttpApiRequest>;
  /**
   * This will be fed with `expired` events
   */
  get sessionExpired(): Observable<void>;
  /**
   * Fire an `expire` event
   */
  sessionExpire(): void;
  /**
   * Fire an `requesteed` event
   */
  requestIntercept(request: ObIHttpApiRequest): void;
  deactivateSpinnerOnNextAPICalls(number?: number): void;
  deactivateNotificationOnNextAPICalls(number?: number): void;
  deactivateOnNextAPICalls(number?: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObHttpApiInterceptorEvents, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * HTTP interceptor for Oblique API calls.
 *
 * It can activate the spinner for matching API requests and route that spinner to a specific channel.
 * The channel is configured through `ObHttpApiInterceptorConfig.api.spinnerChannel` and defaults to ObSpinnerService.CHANNEL.
 */
export declare class ObHttpApiInterceptor implements HttpInterceptor {
  private readonly config;
  private readonly interceptorEvents;
  private readonly spinner;
  private readonly notificationService;
  private readonly translate;
  private readonly activeRequestUrlsByChannel;
  private readonly window;
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
  private handleUnknownError;
  private handleSessionExpiredError;
  private handleHttpError;
  private handleError;
  private setupHeader;
  private setTimer;
  private broadcast;
  private activateSpinner;
  private deactivateSpinner;
  private notify;
  private isApiCall;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObHttpApiInterceptor, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObIconService {
  private readonly registry;
  private readonly domSanitizer;
  registerOnAppInit(iconConfig?: ObIconConfig): void;
  registerIconSetsAsync(...urls: string[]): void;
  registerIconSets(...iconSets: string[]): void;
  registerIconsAsync(...icons: {
    name: string;
    url: string;
  }[]): void;
  registerIcons(...icons: {
    name: string;
    svg: string;
  }[]): void;
  private getIconSets;
  private registerSvg;
  private registerFontClass;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObIconService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export type ObDateFormat = 'isoDate' | 'fullDate' | 'longDate' | 'mediumDate' | 'shortDate' | 'longMonthYear' | 'mediumMonthYear' | 'longMonth';
export type ObTimeFormat = 'longTime' | 'mediumTime' | 'shortTime';
type ObDateTimeFormat = ObDateFormat | ObTimeFormat;
type ObDateValue = Date | number | string | null | undefined;
export declare class ObDatePipe implements PipeTransform {
  private readonly timeFormats;
  private locale;
  constructor();
  transform(value: ObDateValue, dateFormat: ObDateTimeFormat, timeFormat?: ObTimeFormat): string;
  private buildFormat;
  private isTimeFormat;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDatePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObDatePipe, "obDate", true>;
}
export declare class ObDateComponent {
  readonly date: import("@angular/core").InputSignal<string | number | Date>;
  readonly format: import("@angular/core").InputSignal<ObDateFormat>;
  readonly timeFormat: import("@angular/core").InputSignal<ObTimeFormat>;
  readonly formattedDate: import("@angular/core").Signal<string>;
  readonly isoDate: import("@angular/core").Signal<string>;
  private readonly locale;
  private buildFormat;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDateComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObDateComponent, "ob-date", never, {
    "date": {
      "alias": "date";
      "required": true;
      "isSignal": true;
    };
    "format": {
      "alias": "format";
      "required": false;
      "isSignal": true;
    };
    "timeFormat": {
      "alias": "timeFormat";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObLanguageModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObLanguageModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObLanguageModule, never, [typeof ObDatePipe, typeof ObDateComponent], [typeof ObDatePipe, typeof ObDateComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObLanguageModule>;
}
export declare enum ObEScrollMode {
  AUTO = 0,
  ENABLED = 1,
  DISABLED = 2
}
interface ObIMasterLayoutHeader {
  isSticky: boolean;
  isSmall: boolean;
  isCustom: boolean;
  readonly serviceNavigation: ObIServiceNavigationConfig;
}
interface ObIServiceNavigationConfig {
  profileLinks?: ObIServiceNavigationLink[];
  infoHelpText?: string;
  infoLinks?: ObIServiceNavigationLink[];
  infoContactText?: string;
  infoDescription?: string;
  infoContact?: ObIServiceNavigationContact;
  useInfoBackend?: boolean;
  maxFavoriteApplications?: number;
  returnUrl?: string;
  replaceLoginUrl?: string;
  replaceLogoutUrl?: string;
  pamsAppId?: string;
  displayApplications?: boolean;
  displayAuthentication?: boolean;
  displayInfo?: boolean;
  displayLanguages?: boolean;
  displayMessage?: boolean;
  displayProfile?: boolean;
  eportalLanguageSynchronization?: boolean;
  handleLogout?: boolean;
}
interface ObIMasterLayoutFooter {
  isSticky: boolean;
  isCustom: boolean;
}
interface ObIMasterLayoutNavigation {
  isFullWidth: boolean;
  scrollMode: ObEScrollMode;
  scrollDelta: number;
  activeClass: string;
  links: ObINavigationLink[];
}
export interface ObINavigationLink {
  label: string;
  url?: string;
  fragment?: string;
  queryParams?: Record<string, string>;
  children?: ObINavigationLink[];
  sameTarget?: boolean;
  isExternal?: boolean;
  id?: string;
  active?: boolean;
  routerLinkActiveOptions?: IsActiveMatchOptions;
  icon?: ObEIcon | string;
  iconOnly?: boolean;
  removable?: boolean;
  startOfRightSideLinks?: boolean;
}
export interface ObISkipLink {
  label: string;
  url: string | 'current';
  fragment?: string;
}
interface ObIDynamicSkipLink extends ObISkipLink {
  accessKey: number;
}
export interface ObIMasterLayoutEvent {
  name: ObEMasterLayoutEventValues;
  value?: boolean;
  mode?: ObEScrollMode;
  config?: ObIServiceNavigationConfig;
}
export declare enum ObEMasterLayoutEventValues {
  FOOTER_IS_CUSTOM = 0,
  FOOTER_IS_STICKY = 1,
  HEADER_IS_CUSTOM = 2,
  HEADER_IS_SMALL = 3,
  HEADER_IS_STICKY = 4,
  IS_MENU_OPENED = 5,
  LAYOUT_HAS_COVER = 6,
  LAYOUT_HAS_DEFAULT_LAYOUT = 7,
  LAYOUT_HAS_MAIN_NAVIGATION = 8,
  LAYOUT_HAS_MAX_WIDTH = 9,
  LAYOUT_HAS_OFF_CANVAS = 10,
  NAVIGATION_IS_FULL_WIDTH = 11,
  NAVIGATION_SCROLL_MODE = 12,
  SERVICE_NAVIGATION_CONFIGURATION = 13
}
export declare const OB_HIDE_EXTERNAL_LINKS_IN_MAIN_NAVIGATION: InjectionToken<boolean>;
export type ObICollapseBreakpoints = 'xs' | 'sm' | 'md' | 'lg' | 'xl';
declare class ObNavigationLink implements ObINavigationLink {
  id: string;
  isExternal: boolean;
  label: string;
  url: string;
  active?: boolean;
  children?: ObNavigationLink[];
  fragment?: string;
  icon?: ObEIcon | string;
  iconOnly?: boolean;
  removable?: boolean;
  queryParams?: Record<string, string>;
  routerLinkActiveOptions?: IsActiveMatchOptions;
  sameTarget?: boolean;
  startOfRightSideLinks?: boolean;
  constructor(link?: ObINavigationLink);
  private static getKebabCaseId;
}
declare class ObMasterLayoutNavigationGoToChildrenComponent {
  readonly hide: import("@angular/core").Signal<boolean>;
  readonly disableRipple: import("@angular/core").InputSignal<boolean>;
  readonly isCurrentParent: import("@angular/core").InputSignal<boolean>;
  readonly isChildWithoutUrl: import("@angular/core").InputSignal<boolean>;
  readonly link: import("@angular/core").InputSignal<ObNavigationLink>;
  readonly showChildren: import("@angular/core").InputSignal<boolean>;
  readonly changeCurrentParent: import("@angular/core").OutputEmitterRef<ObNavigationLink>;
  goToChildren(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationGoToChildrenComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutNavigationGoToChildrenComponent, "ob-master-layout-navigation-go-to-children", never, {
    "disableRipple": {
      "alias": "disableRipple";
      "required": false;
      "isSignal": true;
    };
    "isCurrentParent": {
      "alias": "isCurrentParent";
      "required": false;
      "isSignal": true;
    };
    "isChildWithoutUrl": {
      "alias": "isChildWithoutUrl";
      "required": false;
      "isSignal": true;
    };
    "link": {
      "alias": "link";
      "required": false;
      "isSignal": true;
    };
    "showChildren": {
      "alias": "showChildren";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changeCurrentParent": "changeCurrentParent";
  }, never, never, true, never>;
}
declare class ObAriaMenuButtonDirective implements OnInit {
  readonly target: import("@angular/core").InputSignal<string>;
  active: boolean;
  private readonly globalEvents;
  private readonly element;
  ngOnInit(): void;
  onClick(event?: KeyboardEvent | MouseEvent): void;
  onEscape(): void;
  private monitorForClickOutside;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAriaMenuButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObAriaMenuButtonDirective, "[obAriaMenuButton]", ["obAriaMenuButton"], {
    "target": {
      "alias": "obAriaMenuButton";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
declare class ObMasterLayoutHeaderToggleDirective {
  private readonly masterLayout;
  toggle(event?: KeyboardEvent | MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutHeaderToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMasterLayoutHeaderToggleDirective, "[obMasterLayoutHeaderToggle]", ["obMasterLayoutHeaderToggle"], {}, {}, never, never, true, never>;
}
declare class ObMasterLayoutNavigationItemDirective implements OnInit, OnDestroy {
  isExpanded: boolean;
  private readonly masterLayout;
  private readonly element;
  private readonly globalEventsService;
  private readonly mainMenu;
  private readonly unsubscribe;
  private readonly changeDetectorRef;
  ngOnInit(): void;
  ngOnDestroy(): void;
  toggleSubMenu(): void;
  openSubMenu(): void;
  closeSubMenu(closeMainMenu?: boolean): void;
  private monitorForClickOutside;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationItemDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMasterLayoutNavigationItemDirective, "[obMasterLayoutNavigationItem]", ["obMasterLayoutNavigationItem"], {}, {}, never, never, true, never>;
}
declare class ObMasterLayoutNavigationMenuDirective {
  hasOpenedMenu: boolean;
  private counter;
  private readonly renderer;
  private readonly element;
  menuOpened(): void;
  menuClosed(): void;
  private toggleBackdrop;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationMenuDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMasterLayoutNavigationMenuDirective, "[obMasterLayoutNavigationMenu]", ["obMasterLayoutNavigationMenu"], {}, {}, never, never, true, never>;
}
declare class ObMasterLayoutNavigationToggleDirective {
  private readonly item;
  onClick(event?: KeyboardEvent | MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMasterLayoutNavigationToggleDirective, "[obMasterLayoutNavigationToggle]", ["obMasterLayoutNavigationToggle"], {}, {}, never, never, true, never>;
}
export declare class ObOutlineDirective {
  private readonly document;
  removeOutline(): void;
  addOutline(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOutlineDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObOutlineDirective, "ob-master-layout", never, {}, {}, never, never, true, never>;
}
export declare class ObMasterLayoutFooterComponent {
  readonly templates: Signal<readonly TemplateRef<HTMLLinkElement>[]>;
  readonly version: import("@angular/core").InputSignal<string>;
  readonly isCustom: Signal<boolean>;
  private readonly masterLayout;
  private readonly config;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutFooterComponent, "ob-master-layout-footer", never, {
    "version": {
      "alias": "version";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["templates"], ["[obFooter]", "[obFooterInfo]"], true, never>;
}
/**
 *  @deprecated since Oblique 16.0.0. To be removed in Oblique 17.0.0. Use provideObliqueConfiguration instead.
 */
export declare const OB_BANNER: InjectionToken<ObTBanner>;
export declare class ObMasterLayoutHeaderComponent {
  home$: Observable<string>;
  readonly banner: Signal<ObIBanner>;
  readonly navigation: import("@angular/core").ModelSignal<ObINavigationLink[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `navigationChange` instead. */
  readonly navigationChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly serviceNavigationConfig: Signal<ObIServiceNavigationConfig & {
    environment: ObEPamsEnvironment;
    rootUrl: string;
  }>;
  readonly obLogo: Signal<TemplateRef<unknown>>;
  readonly templates: Signal<readonly TemplateRef<unknown>[]>;
  readonly mobileTemplates: Signal<readonly TemplateRef<unknown>[]>;
  readonly hasMainNavigation: Signal<boolean>;
  readonly headerControl: Signal<readonly ElementRef<any>[]>;
  readonly headerMobileControl: Signal<readonly ElementRef<any>[]>;
  readonly isCustom: Signal<boolean>;
  readonly isSmall: Signal<boolean>;
  readonly pamsConfiguration: ObIPamsConfiguration;
  private readonly masterLayout;
  private readonly config;
  constructor();
  /**
   * @deprecated since version 16.1 It will be removed with Oblique 17. Use emitQualityOfAuthentication instead
   */
  emitLoginState(loginState: ObLoginState): void;
  emitQualityOfAuthentication(qualityOfAuthentication: ObEQualityOfAuthentication): void;
  emitLogoutUrl(logoutUrl: string): void;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17.
   *
   * Use the `navigation` model with `[(navigation)]`
   * or update it with `navigation.set(...)` instead.
   */
  emitNavigation(navigation: ObINavigationLink[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutHeaderComponent, "ob-master-layout-header", never, {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigation": "navigationChange";
    "navigationChanged": "navigationChanged";
  }, ["obLogo", "templates", "mobileTemplates"], ["[obHeader]", "[obHeaderAction]", "[obHeaderTitle]", "[obNavigation]"], true, never>;
}
type ObIServiceNavigationConfigurationUpdate = Omit<Partial<ObIServiceNavigationConfig>, 'infoContact'> & {
  infoContact?: ObIServiceNavigationContactBase;
};
export declare class ObMasterLayoutHeaderService {
  readonly configEvents$: Observable<ObIMasterLayoutEvent>;
  /**
   * @deprecated since version 16.1 It will be removed with Oblique 17. Use qualityOfAuthentication$ instead
   */
  readonly loginState$: Observable<ObLoginState>;
  readonly qualityOfAuthentication$: Observable<ObEQualityOfAuthentication>;
  readonly logoutUrl$: Observable<string>;
  readonly serviceNavigationConfiguration: Signal<ObIServiceNavigationConfig>;
  private readonly serviceNavigationConfigurationInternal;
  private readonly events;
  /**
   * @deprecated since version 16.1 It will be removed with Oblique 17. Use qualityOfAuthentication instead
   */
  private readonly loginState;
  private readonly qualityOfAuthentication;
  private readonly logoutUrl;
  private readonly config;
  private isCustomInternal;
  private isSmallInternal;
  private isStickyInternal;
  constructor();
  get isCustom(): boolean;
  set isCustom(value: boolean);
  get isSmall(): boolean;
  set isSmall(value: boolean);
  get isSticky(): boolean;
  set isSticky(value: boolean);
  /**
   * Updates the service navigation configuration by merging top-level and nested contact properties.
   * An `undefined` value explicitly clears the corresponding property.
   */
  updateServiceNavigationConfiguration(configuration: ObIServiceNavigationConfigurationUpdate): void;
  /**
   * @deprecated since version 16.1 It will be removed with Oblique 17. Use emitQualityOfAuthentication instead
   */
  emitLoginState(loginState: ObLoginState): void;
  emitQualityOfAuthentication(qualityOfAuthentication: ObEQualityOfAuthentication): void;
  emitLogoutUrl(logoutUrl: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutHeaderService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObMasterLayoutFooterService {
  readonly configEvents$: Observable<ObIMasterLayoutEvent>;
  private readonly events;
  private readonly config;
  private isCustomInternal;
  private isStickyInternal;
  constructor();
  get isCustom(): boolean;
  set isCustom(value: boolean);
  get isSticky(): boolean;
  set isSticky(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutFooterService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObMasterLayoutNavigationService {
  readonly configEvents$: Observable<ObIMasterLayoutEvent>;
  private readonly events;
  private readonly scrolledInternal;
  private readonly scrolled$;
  private readonly refreshedInternal;
  private readonly refreshed$;
  private readonly config;
  private isFullWidthInternal;
  private scrollModeInternal;
  private readonly globalEventsService;
  private readonly window;
  constructor();
  get isFullWidth(): boolean;
  set isFullWidth(value: boolean);
  get scrollMode(): ObEScrollMode;
  set scrollMode(value: ObEScrollMode);
  get scrolled(): Observable<number>;
  get refreshed(): Observable<void>;
  refresh(): void;
  scrollLeft(offset?: number): void;
  scrollRight(offset?: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObMasterLayoutComponentService {
  readonly configEvents$: Observable<ObIMasterLayoutEvent>;
  private readonly events;
  private readonly config;
  private isMenuOpenedInternal;
  private hasCoverInternal;
  private hasOffCanvasInternal;
  private hasMainNavigationInternal;
  private hasLayoutInternal;
  private hasMaxWidthInternal;
  constructor();
  get isMenuOpened(): boolean;
  set isMenuOpened(value: boolean);
  get hasCover(): boolean;
  set hasCover(value: boolean);
  get hasOffCanvas(): boolean;
  set hasOffCanvas(value: boolean);
  get hasMainNavigation(): boolean;
  set hasMainNavigation(value: boolean);
  get hasLayout(): boolean;
  set hasLayout(value: boolean);
  get hasMaxWidth(): boolean;
  set hasMaxWidth(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutComponentService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObMasterLayoutService {
  readonly homePageRouteChange$: Observable<string>;
  readonly header: ObMasterLayoutHeaderService;
  readonly footer: ObMasterLayoutFooterService;
  readonly navigation: ObMasterLayoutNavigationService;
  readonly layout: ObMasterLayoutComponentService;
  private readonly router;
  private readonly activatedRoute;
  private readonly config;
  private homePageRouteInternal;
  private readonly homePageRouteChange;
  constructor();
  set homePageRoute(homePageRoute: string);
  get homePageRoute(): string;
  private routeChange;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
declare class MasterLayoutComponentBase {
  protected readonly masterLayout: ObMasterLayoutService;
  home: string;
  hasCover: import("@angular/core").Signal<boolean>;
  hasLayout: import("@angular/core").Signal<boolean>;
  hasMaxWidth: import("@angular/core").Signal<boolean>;
  isMenuOpened: import("@angular/core").Signal<boolean>;
  noNavigation: import("@angular/core").Signal<boolean>;
  hasOffCanvas: import("@angular/core").Signal<boolean>;
  isHeaderSticky: import("@angular/core").Signal<boolean>;
  isFooterSticky: import("@angular/core").Signal<boolean>;
  protected readonly unsubscribe: Subject<void>;
  private readonly config;
  constructor();
}
export declare class ObMasterLayoutComponent extends MasterLayoutComponentBase implements OnInit, DoCheck, OnDestroy, OnChanges {
  readonly contentId: WritableSignal<string>;
  readonly route: WritableSignal<{
    path: string | undefined;
    params: Params | undefined;
  }>;
  readonly hasHighContrast: WritableSignal<boolean>;
  readonly navigation: import("@angular/core").ModelSignal<ObINavigationLink[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `navigationChange` instead. */
  readonly navigationChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly skipLinks: import("@angular/core").InputSignal<ObISkipLink[] | ObIDynamicSkipLink[]>;
  readonly collapseBreakpoint: import("@angular/core").InputSignal<ObICollapseBreakpoints>;
  readonly version: import("@angular/core").InputSignal<string>;
  readonly isLayoutCollapsed: WritableSignal<boolean>;
  readonly isLayoutExpanded: WritableSignal<boolean>;
  readonly isScrolling: WritableSignal<boolean>;
  readonly prefersReducedMotion: WritableSignal<boolean>;
  readonly obLogo: import("@angular/core").Signal<TemplateRef<unknown>>;
  readonly headerControlTemplates: import("@angular/core").Signal<readonly TemplateRef<unknown>[]>;
  readonly headerMobileControlTemplates: import("@angular/core").Signal<readonly TemplateRef<unknown>[]>;
  readonly footerLinkTemplates: import("@angular/core").Signal<readonly TemplateRef<HTMLLinkElement>[]>;
  readonly offCanvasClose: import("@angular/core").Signal<ElementRef<any>>;
  readonly main: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly wrapper: import("@angular/core").Signal<ElementRef<HTMLElement>>;
  readonly skipLinksInternal: import("@angular/core").Signal<any[]>;
  private readonly unsubscribeMediaQuery;
  private navigationLength;
  private readonly staticSkipLinks;
  private readonly router;
  private readonly offCanvasService;
  private readonly globalEventsService;
  private readonly document;
  private readonly window;
  private readonly highContrastModeDetector;
  private readonly changeDetectorRef;
  private readonly gridBreakpoints;
  private readonly obConsole;
  constructor();
  ngOnChanges(changes: SimpleChanges): void;
  ngOnInit(): void;
  ngDoCheck(): void;
  ngOnDestroy(): void;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17.
   *
   * Use the `navigation` model with `[(navigation)]`
   * or update it with `navigation.set(...)` instead.
   */
  emitNavigation(navigation: ObINavigationLink[]): void;
  scrollTop(element?: HTMLElement): void;
  focusElementById(elementId: string): void;
  private isMainFocusedInStickyLayout;
  private createElementDescription;
  private handleFocusAfterNavigation;
  private focusMainAfterNavigation;
  private handleLayoutMode;
  private isInHighContrastMode;
  private focusFragment;
  private extractUrlPart;
  private formatQueryParameters;
  private focusOffCanvasClose;
  private getElement;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutComponent, "ob-master-layout", ["obMasterLayout"], {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
    "skipLinks": {
      "alias": "skipLinks";
      "required": false;
      "isSignal": true;
    };
    "collapseBreakpoint": {
      "alias": "collapseBreakpoint";
      "required": false;
      "isSignal": true;
    };
    "version": {
      "alias": "version";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigation": "navigationChange";
    "navigationChanged": "navigationChanged";
  }, ["obLogo", "headerControlTemplates", "headerMobileControlTemplates", "footerLinkTemplates"], ["[obHeader]", "[obHeaderAction]", "[obHeaderTitle]", "[obNavigation]", "[obFooter]", "[obFooterInfo]", "[obOffCanvasTitle]", "[obOffCanvasContent]"], true, never>;
}
declare class MasterLayoutNavigationComponentBase {
  readonly isFullWidth: WritableSignal<boolean>;
  activeClass: string;
  protected readonly masterLayout: ObMasterLayoutService;
  protected readonly destroyRef: DestroyRef;
  protected readonly isScrollable: WritableSignal<boolean>;
  protected readonly el: ElementRef<HTMLElement>;
  protected readonly currentScroll: WritableSignal<number>;
  protected readonly maxScroll: WritableSignal<number>;
  private static readonly buttonWidth;
  private readonly globalEventsService;
  private readonly config;
  private readonly renderer;
  private readonly changeDetectorRef;
  constructor();
  close(): void;
  scrollLeft(): void;
  scrollRight(): void;
  protected closeOnEscape(): void;
  protected getNav(): HTMLElement | null;
  protected updateScroll(delta: number): void;
  private scrollModeChange;
  private fullWidthChange;
  private refresh;
  /**
   * Prevents the browser from automatically scrolling the last navigation item into view
   * when focus moves back from an element after the navigation using Shift+Tab.
   *
   * By default, the browser pulls the last item into view, breaking the scrollable
   * navigation's position. This function prevents the default browser behavior, and manually focuses
   * the last navigation item without triggering any native scroll.
   *
   * The actual scroll animation is triggered separately by `toggleFocus`
   */
  private preventBrowserFocusOnLastItem;
}
export declare class ObMasterLayoutNavigationComponent extends MasterLayoutNavigationComponentBase implements OnInit, AfterViewInit {
  readonly currentGrandparentLink: import("@angular/core").Signal<ObNavigationLink>;
  readonly currentParentLink: import("@angular/core").Signal<ObNavigationLink>;
  readonly currentParentRouterLinkBase: import("@angular/core").Signal<string>;
  readonly isCurrentParentLinkExactMatch: import("@angular/core").Signal<boolean>;
  hideExternalLinks: boolean;
  readonly links: import("@angular/core").ModelSignal<ObINavigationLink[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `linksChange` instead. */
  readonly linksChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly navigationLinks: import("@angular/core").Signal<ObNavigationLink[]>;
  readonly activeLinks: import("@angular/core").Signal<Set<ObNavigationLink>>;
  routerLinkActiveOptions: IsActiveMatchOptions;
  private readonly router;
  private readonly translate;
  private readonly hasLanguageInUrl;
  private readonly emptyNavigationLink;
  private readonly navigationEnd;
  private readonly navigationResetSource;
  private readonly parentStack;
  constructor();
  ngOnInit(): void;
  ngAfterViewInit(): void;
  focusIn(prefix: string, linkId: string): void;
  focusOut(prefix: string, linkId: string): void;
  backUpOrCloseSubMenu(link: ObNavigationLink, obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective): void;
  changeCurrentParentLink(link: ObNavigationLink): void;
  closeSubMenu(obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective, link: ObNavigationLink): void;
  toggleSubMenu(obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective, link: ObNavigationLink): void;
  removeMenuItem(item: ObINavigationLink, mouseEvent: MouseEvent): void;
  private handleNavItemFocusChange;
  private backUpSubMenu;
  private flattenLinks;
  private getParentIndex;
  private onSubMenuExpandedChanges;
  private localizeUrl;
  private joinUrls;
  private resetCurrentAncestorRelatedProps;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutNavigationComponent, "ob-master-layout-navigation", never, {
    "links": {
      "alias": "links";
      "required": false;
      "isSignal": true;
    };
  }, {
    "links": "linksChange";
    "linksChanged": "linksChanged";
  }, never, ["*"], true, never>;
}
declare class ObMasterLayoutNavigationSubMenuItemComponent {
  readonly child: import("@angular/core").InputSignal<ObNavigationLink>;
  readonly currentParent: import("@angular/core").InputSignal<ObNavigationLink>;
  readonly link: import("@angular/core").InputSignal<ObNavigationLink>;
  readonly activeClass: import("@angular/core").InputSignal<string>;
  readonly activeLinks: import("@angular/core").InputSignal<ReadonlySet<ObNavigationLink>>;
  readonly hideExternalLinks: import("@angular/core").InputSignal<boolean>;
  readonly obMasterLayoutNavigationItem: import("@angular/core").InputSignal<ObMasterLayoutNavigationItemDirective>;
  readonly routerLinkActiveOptions: import("@angular/core").InputSignal<IsActiveMatchOptions>;
  readonly routerLinkBase: import("@angular/core").InputSignal<string>;
  readonly showChildren: import("@angular/core").InputSignal<boolean>;
  hasFocusedChild: boolean;
  readonly column: import("@angular/core").Signal<boolean>;
  readonly changeCurrentParent: import("@angular/core").OutputEmitterRef<ObNavigationLink>;
  private readonly el;
  goToChildren(child: ObNavigationLink): void;
  toggleFocus(childId: string): void;
  private doAnyDescendantsMatchCurrentParent;
  private doesChildMatchCurrentParent;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutNavigationSubMenuItemComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMasterLayoutNavigationSubMenuItemComponent, "ob-master-layout-navigation-sub-menu-item", never, {
    "child": {
      "alias": "child";
      "required": false;
      "isSignal": true;
    };
    "currentParent": {
      "alias": "currentParent";
      "required": false;
      "isSignal": true;
    };
    "link": {
      "alias": "link";
      "required": false;
      "isSignal": true;
    };
    "activeClass": {
      "alias": "activeClass";
      "required": false;
      "isSignal": true;
    };
    "activeLinks": {
      "alias": "activeLinks";
      "required": false;
      "isSignal": true;
    };
    "hideExternalLinks": {
      "alias": "hideExternalLinks";
      "required": false;
      "isSignal": true;
    };
    "obMasterLayoutNavigationItem": {
      "alias": "obMasterLayoutNavigationItem";
      "required": false;
      "isSignal": true;
    };
    "routerLinkActiveOptions": {
      "alias": "routerLinkActiveOptions";
      "required": false;
      "isSignal": true;
    };
    "routerLinkBase": {
      "alias": "routerLinkBase";
      "required": false;
      "isSignal": true;
    };
    "showChildren": {
      "alias": "showChildren";
      "required": false;
      "isSignal": true;
    };
  }, {
    "changeCurrentParent": "changeCurrentParent";
  }, never, never, true, never>;
}
export declare class ObOffCanvasBackdropDirective implements OnInit, OnDestroy {
  private readonly offCanvas;
  private readonly globalEventsService;
  private readonly unsubscribe;
  close(): void;
  ngOnInit(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOffCanvasBackdropDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObOffCanvasBackdropDirective, ".ob-off-canvas-backdrop", never, {}, {}, never, never, true, never>;
}
export declare class ObOffCanvasContainerDirective implements OnDestroy {
  open: boolean;
  private readonly unsubscribe;
  constructor();
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOffCanvasContainerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObOffCanvasContainerDirective, ".ob-off-canvas, ob-master-layout", never, {}, {}, never, never, true, never>;
}
export declare class ObOffCanvasToggleDirective {
  private readonly changeDetectorRef;
  private readonly window;
  private readonly offCanvas;
  toggle(event?: KeyboardEvent | MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOffCanvasToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObOffCanvasToggleDirective, "[obOffCanvasToggle]", ["obOffCanvasToggle"], {}, {}, never, never, true, never>;
}
/**
 * Service for controlling ObliqueUI offcanvas composite features.
 */
export declare class ObOffCanvasService {
  /**
   * Fire an `opened` event
   */
  readonly opened$: Observable<boolean>;
  private readonly openedSubject;
  private isOpen;
  constructor();
  get open(): boolean;
  set open(value: boolean);
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOffCanvasService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObOffCanvasModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObOffCanvasModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObOffCanvasModule, never, [typeof ObOffCanvasBackdropDirective, typeof ObOffCanvasContainerDirective, typeof ObOffCanvasToggleDirective], [typeof ObOffCanvasBackdropDirective, typeof ObOffCanvasContainerDirective, typeof ObOffCanvasToggleDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObOffCanvasModule>;
}
export declare class ObTopControlComponent {
  readonly scrollToTop: import("@angular/core").OutputEmitterRef<void>;
  scrollTop(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObTopControlComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObTopControlComponent, "ob-top-control", never, {}, {
    "scrollToTop": "scrollToTop";
  }, never, never, true, never>;
}
export declare class ObScrollingModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObScrollingModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObScrollingModule, never, [typeof ObTopControlComponent], [typeof ObTopControlComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObScrollingModule>;
}
export declare class ObSpinnerComponent implements OnInit {
  readonly channel: import("@angular/core").InputSignal<string>;
  readonly fixed: import("@angular/core").InputSignal<boolean>;
  isActive$: Observable<boolean>;
  storedFocusedElement: HTMLElement;
  elementOutsideInertArea: HTMLElement;
  private readonly renderer;
  private readonly destroyRef;
  private readonly spinnerService;
  private readonly spinnerRegistry;
  private readonly element;
  private readonly document;
  private readonly liveAnnouncer;
  private readonly translate;
  private readonly parentElement;
  ngOnInit(): void;
  private createFocusableElement;
  private setInert;
  private announceSpinnerState;
  private getAnnouncementText;
  private handleFocus;
  private handleFocusOnActivation;
  private isElementInsideInertArea;
  private moveFocusOutsideInertArea;
  private handleFocusOnDeactivation;
  private removeElementOutsideInertArea;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSpinnerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObSpinnerComponent, "ob-spinner", ["obSpinner"], {
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "fixed": {
      "alias": "fixed";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export interface ObISpinnerEvent {
  active: boolean;
  channel: string;
}
/**
 * SpinnerService (TODO: Rethink this concept)
 *
 */
export declare class ObSpinnerService {
  /**
   * The channel name where spinner events will be broadcasted to.
   */
  static CHANNEL: string;
  readonly events$: Observable<ObISpinnerEvent>;
  private calls;
  private readonly events;
  private readonly spinnerRegistry;
  private readonly obConsole;
  constructor();
  activate(channel?: string): void;
  deactivate(channel?: string): void;
  forceDeactivate(channel?: string): void;
  private broadcast;
  private increase;
  private decrease;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSpinnerService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObSpinnerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSpinnerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObSpinnerModule, never, [typeof ObSpinnerComponent], [typeof ObSpinnerComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObSpinnerModule>;
}
export declare class ObLocalizePipe implements PipeTransform {
  /**
   * RegExp construction is relatively expensive. To improve performances, they are cached as static variable so that
   * they are created only once per language configuration and not once per instance or worse: once per call
   */
  private static readonly languageSegmentRegex;
  private static readonly routeSegmentSplitter;
  private readonly router;
  private readonly route;
  private readonly hasLanguageInUrl;
  private readonly translate;
  private readonly currentLang;
  transform(route: string | string[] | null | undefined): string | null | undefined;
  /**
   * Converts a route string into the segment array format expected by the Angular router
   * "path/to/somewhere" => ['path', 'to', 'somewhere']
   * "/path/to/somewhere" => ['/path', 'to', 'somewhere']
   * "./path/to/somewhere" => ['./path', 'to', 'somewhere']
   * "../../path/to/somewhere" => ['../../path', 'to', 'somewhere']
   * */
  private routeToSegments;
  private getRegExps;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObLocalizePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObLocalizePipe, "obLocalize", true>;
}
/**
 * Configuration service for the Master Layout component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for the master layout
 */
export declare class ObMasterLayoutConfig {
  /**
   * Route to the home page
   */
  homePageRoute: string;
  /**
   * Duration of the scroll to top functionality
   */
  scrollToTopDuration: number;
  showAccessibilityTitle: boolean;
  /**
   *  Controls the application's layout
   */
  layout: {
    hasCover: boolean;
    hasMainNavigation: boolean;
    hasOffCanvas: boolean;
    hasLayout: boolean;
    hasMaxWidth: boolean;
  };
  /**
   * Controls the application's header
   */
  header: ObIMasterLayoutHeader;
  /**
   * Controls the application's main navigation
   */
  navigation: ObIMasterLayoutNavigation;
  /**
   * Controls the applications's footer
   */
  footer: ObIMasterLayoutFooter;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObMasterLayoutModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMasterLayoutModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMasterLayoutModule, never, [typeof i1$1.CommonModule, typeof i2.MatButtonModule, typeof i4.MatIconModule, typeof i8.MatTooltipModule, typeof i1$1.NgOptimizedImage, typeof ObButtonModule, typeof ObExternalLinkModule, typeof ObMasterLayoutNavigationGoToChildrenComponent, typeof ObAriaMenuButtonDirective, typeof ObMasterLayoutHeaderToggleDirective, typeof ObMasterLayoutNavigationItemDirective, typeof ObMasterLayoutNavigationMenuDirective, typeof ObMasterLayoutNavigationToggleDirective, typeof ObOutlineDirective, typeof ObMasterLayoutFooterComponent, typeof ObMasterLayoutHeaderComponent, typeof ObMasterLayoutComponent, typeof ObMasterLayoutNavigationComponent, typeof ObMasterLayoutNavigationSubMenuItemComponent, typeof ObNotificationModule, typeof ObOffCanvasModule, typeof ObScrollingModule, typeof ObServiceNavigationModule, typeof ObSpinnerModule, typeof i24.RouterModule, typeof i25.ScrollingModule, typeof i2$1.TranslatePipe, typeof ObLocalizePipe], [typeof ObMasterLayoutComponent, typeof ObMasterLayoutFooterComponent, typeof ObMasterLayoutHeaderComponent, typeof ObMasterLayoutNavigationComponent, typeof ObOutlineDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMasterLayoutModule>;
}
export declare class ObPaginatorService extends MatPaginatorIntl {
  private ofLabel;
  private pageLabel;
  private readonly translateService;
  constructor();
  getRangeLabel: (page: number, pageSize: number, length: number) => string;
  private initTranslation;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObPaginatorService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @deprecated since version 16.0.0. It will be removed with Oblique 17, use `provideObliqueConfiguration` instead.
 */
export declare class ObDatepickerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObDatepickerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObDatepickerModule, never, [typeof i1.MatDatepickerModule], [typeof i1.MatDatepickerModule]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObDatepickerModule>;
}
export declare class ObStepperIntlService extends MatStepperIntl {
  private readonly translateService;
  constructor();
  private initTranslation;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObStepperIntlService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Model for the `NavTreeComponent` items.
 *
 * @see NavTreeComponent
 */
export declare class ObNavTreeItemModel {
  id: string;
  label: string;
  labelParams?: Record<string, string | number>;
  items?: ObNavTreeItemModel[];
  path?: string;
  fragment?: string;
  queryParams?: any;
  disabled?: boolean;
  collapsed?: boolean;
  parent?: ObNavTreeItemModel;
  routes: any[];
  constructor(json: any, parent?: ObNavTreeItemModel);
}
export declare class ObNavTreeComponent {
  static DEFAULTS: {
    HIGHLIGHT: string;
    LABEL_FORMATTER: typeof defaultLabelFormatterFactory;
  };
  readonly formatter: import("@angular/core").Signal<(item: ObNavTreeItemModel, filterPattern?: string) => string>;
  readonly activeFragment: import("@angular/core").WritableSignal<string>;
  readonly items: import("@angular/core").InputSignal<ObNavTreeItemModel[]>;
  readonly prefix: import("@angular/core").InputSignal<string>;
  readonly hasFilter: import("@angular/core").InputSignal<boolean>;
  readonly filterPattern: import("@angular/core").ModelSignal<string>;
  readonly labelFormatter: import("@angular/core").InputSignal<(item: ObNavTreeItemModel, filterPattern?: string) => string>;
  readonly treeAriaLabelledBy: import("@angular/core").InputSignal<string>;
  readonly treeAriaLabel: import("@angular/core").InputSignal<string>;
  readonly patternMatcher: import("@angular/core").InputSignal<(item: ObNavTreeItemModel, pattern?: string) => boolean>;
  private readonly changeDetector;
  private readonly route;
  private readonly translate;
  private readonly defaultFormatter;
  private readonly defaultPatternMatcher;
  private readonly effectivePatternMatcher;
  constructor();
  visible(item: ObNavTreeItemModel): boolean;
  itemKey(item: ObNavTreeItemModel): string;
  isLinkActive(rla: RouterLinkActive, item: ObNavTreeItemModel): boolean;
  changeCollapsed(items: ObNavTreeItemModel[], collapsed: boolean, all?: boolean): void;
  collapseAll(): void;
  expandAll(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNavTreeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObNavTreeComponent, "ob-nav-tree", ["obNavTree"], {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "prefix": {
      "alias": "prefix";
      "required": false;
      "isSignal": true;
    };
    "hasFilter": {
      "alias": "hasFilter";
      "required": false;
      "isSignal": true;
    };
    "filterPattern": {
      "alias": "filterPattern";
      "required": false;
      "isSignal": true;
    };
    "labelFormatter": {
      "alias": "labelFormatter";
      "required": false;
      "isSignal": true;
    };
    "treeAriaLabelledBy": {
      "alias": "treeAriaLabelledBy";
      "required": false;
      "isSignal": true;
    };
    "treeAriaLabel": {
      "alias": "treeAriaLabel";
      "required": false;
      "isSignal": true;
    };
    "patternMatcher": {
      "alias": "patternMatcher";
      "required": false;
      "isSignal": true;
    };
  }, {
    "filterPattern": "filterPatternChange";
  }, never, never, true, never>;
}
declare function defaultLabelFormatterFactory(translate: TranslateService): (item: ObNavTreeItemModel, filterPattern?: string) => string;
export declare class ObNavTreeModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNavTreeModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObNavTreeModule, never, [typeof ObNavTreeComponent], [typeof ObNavTreeComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObNavTreeModule>;
}
export declare class ObNestedFormComponent implements ControlValueAccessor, Validator, AfterViewInit {
  readonly nestedForm: import("@angular/core").InputSignal<UntypedFormGroup>;
  private onTouched;
  private readonly parent;
  private readonly destroyRef;
  onBlur(): void;
  ngAfterViewInit(): void;
  registerOnChange(fn: (value: unknown) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  writeValue(obj: {
    field1?: string;
    field2?: string;
  }): void;
  validate(control: AbstractControl): ValidationErrors | null;
  private formatErrors;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNestedFormComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObNestedFormComponent, "ob-nested-form", ["obNestedForm"], {
    "nestedForm": {
      "alias": "nestedForm";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export declare class ObParentFormDirective implements OnDestroy {
  readonly submit$: Observable<void>;
  readonly reset$: Observable<void>;
  private readonly submitSubject;
  private readonly resetSubject;
  constructor();
  ngOnDestroy(): void;
  submit(): void;
  reset(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObParentFormDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObParentFormDirective, "[obParentFormDirective]", ["obParentFormDirective"], {}, {}, never, never, true, never>;
}
export declare class ObNestedFormModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNestedFormModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObNestedFormModule, never, [typeof ObNestedFormComponent, typeof ObParentFormDirective], [typeof ObNestedFormComponent, typeof ObParentFormDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObNestedFormModule>;
}
export declare class ObNumberFormatDirective implements OnInit {
  readonly decimals: import("@angular/core").InputSignal<number>;
  readonly persistent: import("@angular/core").InputSignal<boolean>;
  private changed;
  private focused;
  private readonly ngControl;
  private readonly el;
  onBlur(): void;
  onFocus(): void;
  ngOnInit(): void;
  private static toFixedNumber;
  private setValue;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNumberFormatDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObNumberFormatDirective, "[obNumberFormat]", ["obNumberFormat"], {
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "persistent": {
      "alias": "persistent";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObNumberFormatModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObNumberFormatModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObNumberFormatModule, never, [typeof ObNumberFormatDirective], [typeof ObNumberFormatDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObNumberFormatModule>;
}
export declare function obPauseWhenPageHidden<T>(doc?: Document): (source$: Observable<T>) => Observable<T>;
export declare class ObSelectableDirective<T = any> {
  readonly value: import("@angular/core").InputSignal<T>;
  readonly selected: import("@angular/core").ModelSignal<boolean>;
  readonly tabindex: import("@angular/core").ModelSignal<number>;
  readonly role: import("@angular/core").Signal<"checkbox" | "radio">;
  private disabled;
  private readonly initialTabindex;
  private readonly element;
  private readonly group;
  constructor();
  onClick($event: KeyboardEvent | MouseEvent): void;
  onFocus(): void;
  focus(): void;
  private toggleDisabled;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSelectableDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObSelectableDirective<any>, "[obSelectable]", ["obSelectable"], {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "tabindex": {
      "alias": "tabindex";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "tabindex": "tabindexChange";
  }, never, never, true, never>;
}
export declare class ObSelectableGroupDirective<T = any> implements AfterContentInit, ControlValueAccessor {
  readonly role: import("@angular/core").Signal<"radiogroup" | "group">;
  readonly selected: import("@angular/core").ModelSignal<ObSelectableDirective<T>[]>;
  readonly mode: import("@angular/core").ModelSignal<"checkbox" | "radio" | "windows">;
  readonly effectiveMode: import("@angular/core").Signal<"checkbox" | "radio" | "windows">;
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly effectiveDisabled: import("@angular/core").WritableSignal<boolean>;
  private readonly selectables;
  private focused;
  private prevFocused;
  private startFocused;
  private initialSelection;
  private readonly modeToggle;
  constructor();
  ngAfterContentInit(): void;
  registerOnChange(fn: (value: T[]) => void): void;
  registerOnTouched(fn: () => void): void;
  writeValue(selection: T[]): void;
  setDisabledState(isDisabled: boolean): void;
  register(directive: ObSelectableDirective<T>): void;
  toggle(directive: ObSelectableDirective<T>, ctrl?: boolean, shift?: boolean): void;
  focus(directive: ObSelectableDirective<T>): void;
  selectAll(): void;
  deselectAll(): void;
  sort(sortFunction: (a: ObSelectableDirective<T>, b: ObSelectableDirective<T>) => number): void;
  onArrowDown($event: KeyboardEvent): void;
  onArrowUp($event: KeyboardEvent): void;
  onShiftArrowDown($event: KeyboardEvent): void;
  onShiftArrowUp($event: KeyboardEvent): void;
  onCtrlArrowDown($event: KeyboardEvent): void;
  onCtrlArrowUp($event: KeyboardEvent): void;
  private add;
  private move;
  private next;
  private checkboxSelect;
  private radioSelect;
  private windowsSelect;
  private updateSelection;
  private getSelected;
  private onChange;
  private onTouched;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSelectableGroupDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObSelectableGroupDirective<any>, "[obSelectableGroup]", ["obSelectableGroup"], {
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "mode": "modeChange";
  }, never, never, true, never>;
}
export declare class ObSelectableModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObSelectableModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObSelectableModule, never, [typeof ObSelectableDirective, typeof ObSelectableGroupDirective], [typeof ObSelectableDirective, typeof ObSelectableGroupDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObSelectableModule>;
}
export declare function provideObliqueTranslations(configuration?: ObITranslateConfig): EnvironmentProviders;
export declare class ObInputClearDirective implements OnInit {
  readonly control: import("@angular/core").InputSignal<HTMLInputElement | NgModel | AbstractControl<any, any, any>>;
  readonly focusOnClear: import("@angular/core").InputSignal<boolean>;
  readonly datePickerRef: import("@angular/core").InputSignal<MatDatepicker<unknown>>;
  readonly onClear: import("@angular/core").OutputEmitterRef<MouseEvent>;
  cssClass: boolean;
  private readonly element;
  private readonly validControlTypes;
  private readonly window;
  private readonly destroyRef;
  private readonly obConsole;
  constructor();
  ngOnInit(): void;
  onClick($event: MouseEvent): void;
  private checkControlType;
  private clearDatePicker;
  private subscribeToInputValueChange;
  private clearInputField;
  private clearReactiveForm;
  private clearTemplateDrivenForm;
  private clearHtmlInput;
  private isInvalidControlType;
  private setFocus;
  private addParentClass;
  private removeParentClass;
  private handleParentClass;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObInputClearDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObInputClearDirective, "[obInputClear]", ["obInputClear"], {
    "control": {
      "alias": "obInputClear";
      "required": false;
      "isSignal": true;
    };
    "focusOnClear": {
      "alias": "focusOnClear";
      "required": false;
      "isSignal": true;
    };
    "datePickerRef": {
      "alias": "datePickerRef";
      "required": false;
      "isSignal": true;
    };
  }, {
    "onClear": "onClear";
  }, never, never, true, never>;
}
export declare class ObInputClearModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObInputClearModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObInputClearModule, never, [typeof ObInputClearDirective], [typeof ObInputClearDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObInputClearModule>;
}
export declare class ObUnknownRouteComponent {
  homePageRoute: any;
  private readonly masterLayoutConfig;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnknownRouteComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObUnknownRouteComponent, "ob-unknown-route", never, {}, {}, never, never, true, never>;
}
export declare class ObUnknownRouteModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnknownRouteModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObUnknownRouteModule, never, [typeof i1$1.CommonModule, typeof ObUnknownRouteComponent, typeof i24.RouterModule, typeof i2$1.TranslatePipe], [typeof ObUnknownRouteComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObUnknownRouteModule>;
}
export declare class ObUnsavedChangesDirective implements OnChanges, OnDestroy {
  readonly id: import("@angular/core").InputSignal<string>;
  readonly isActive: import("@angular/core").InputSignal<boolean>;
  private readonly unsavedChangesService;
  private readonly form;
  ngOnChanges(): void;
  ngOnDestroy(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnsavedChangesDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObUnsavedChangesDirective, "[obUnsavedChanges]", ["obUnsavedChanges"], {
    "id": {
      "alias": "id";
      "required": true;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export declare class ObUnsavedChangesGuard implements CanDeactivate<any> {
  private readonly unsavedChangesService;
  canDeactivate(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnsavedChangesGuard, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObUnsavedChangesService {
  readonly isActive: import("@angular/core").WritableSignal<boolean>;
  private readonly forms;
  private readonly hasPendingChanges;
  private readonly translateService;
  private readonly window;
  constructor();
  watch(formId: string, form: ControlContainer): void;
  unWatch(formId: string): void;
  canDeactivate(): boolean;
  ignoreChanges(formIds?: string[]): boolean;
  private onUnload;
  private hasPendingChangesFor;
  private message;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnsavedChangesService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare class ObUnsavedChangesModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObUnsavedChangesModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObUnsavedChangesModule, never, [typeof ObUnsavedChangesDirective], [typeof ObUnsavedChangesDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObUnsavedChangesModule>;
}
export declare function provideObliqueConfiguration(config: ObIObliqueConfiguration): EnvironmentProviders;
export declare function provideObliqueTestingConfiguration(config?: ObIObliqueTestingConfiguration): EnvironmentProviders;
export declare function obFocusWithOutline(doc: Document, focusableElement: HTMLElement): void;
export declare const WINDOW: InjectionToken<Window>;
export declare enum ObEColor {
  GRAY_EXTRA_LIGHT = "#f0f4f7",
  GRAY_LIGHTER = "#dfe4e9",
  GRAY_LIGHT = "#acb4bd",
  GRAY = "#828e9a",
  GRAY_DARK = "#46596b",
  GRAY_DARKER = "#2f4356",
  DEFAULT = "#1c2834",
  ACCENT = "#e53940",
  EXTRA_LIGHT = "#f0f4f7",
  LIGHT = "#acb4bd",
  PRIMARY = "#46596b",
  DARK = "#263645",
  SUCCESS_LIGHT = "#d1fae5",
  SUCCESS = "#047857",
  SUCCESS_DARK = "#064e3b",
  WARNING_LIGHT = "#ffedd5",
  WARNING = "#ea580c",
  WARNING_DARK = "#c2410c",
  ERROR_LIGHT = "#fae1e2",
  ERROR = "#99191e",
  ERROR_DARK = "#801519",
  ENV_LOCAL = "var(--ob-env-local)",
  ENV_DEV = "var(--ob-env-dev)",
  ENV_REF = "var(--ob-env-ref)",
  ENV_TEST = "var(--ob-env-test)",
  ENV_ABN = "var(--ob-env-abn)"
}
interface NavigateEvent {
  destination: {
    url: string;
  };
}
export declare class ObGlobalEventsService {
  readonly beforeUnload$: Observable<BeforeUnloadEvent>;
  readonly click$: Observable<MouseEvent>;
  readonly mouseDown$: Observable<MouseEvent>;
  readonly mouseMove$: Observable<MouseEvent>;
  readonly keyDown$: Observable<KeyboardEvent>;
  readonly keyUp$: Observable<KeyboardEvent>;
  readonly scroll$: Observable<Event>;
  readonly wheel$: Observable<Event>;
  readonly resize$: Observable<UIEvent>;
  readonly navigate$: Observable<NavigateEvent>;
  private readonly window;
  constructor();
  private buildObservable;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObGlobalEventsService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
export declare function obOutsideFilter<T extends Event>(...elements: HTMLElement[]): (source$: Observable<T>) => Observable<T>;
export declare class ObliqueModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObliqueModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObliqueModule, never, [typeof ObAlertModule, typeof ObButtonModule, typeof ObBreadcrumbModule, typeof ObCollapseModule, typeof ObColumnLayoutModule, typeof ObDocumentMetaModule, typeof ObErrorMessagesModule, typeof ObFileUploadModule, typeof ObLanguageModule, typeof ObMasterLayoutModule, typeof ObNavTreeModule, typeof ObNestedFormModule, typeof ObNotificationModule, typeof ObNumberFormatModule, typeof ObOffCanvasModule, typeof ObPopoverModule, typeof ObScrollingModule, typeof ObServiceNavigationModule, typeof ObSelectableModule, typeof ObSpinnerModule, typeof ObInputClearModule, typeof ObTranslateParamsModule, typeof ObUnknownRouteModule, typeof ObUnsavedChangesModule, typeof ObExternalLinkModule], [typeof ObAlertModule, typeof ObButtonModule, typeof ObBreadcrumbModule, typeof ObCollapseModule, typeof ObColumnLayoutModule, typeof ObDocumentMetaModule, typeof ObErrorMessagesModule, typeof ObFileUploadModule, typeof ObLanguageModule, typeof ObMasterLayoutModule, typeof ObNavTreeModule, typeof ObNestedFormModule, typeof ObNotificationModule, typeof ObNumberFormatModule, typeof ObOffCanvasModule, typeof ObPopoverModule, typeof ObScrollingModule, typeof ObServiceNavigationModule, typeof ObSelectableModule, typeof ObSpinnerModule, typeof ObInputClearModule, typeof ObTranslateParamsModule, typeof ObUnknownRouteModule, typeof ObUnsavedChangesModule, typeof ObExternalLinkModule]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObliqueModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAlertComponent {
  readonly type: import("@angular/core").InputSignal<string>;
  info: boolean;
  success: boolean;
  warning: boolean;
  error: boolean;
  readonly hasRoleAlert: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAlertComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockAlertComponent, "ob-alert", ["obAlert"], {
    "type": {
      "alias": "type";
      "required": false;
      "isSignal": true;
    };
    "hasRoleAlert": {
      "alias": "hasRoleAlert";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAlertModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAlertModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockAlertModule, never, [typeof ObMockAlertComponent], [typeof ObMockAlertComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockAlertModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAuthenticationConfigService {
  configureFlow(authFlowConfig: AuthConfig, tokenValidationHandler?: ValidationHandler): Observable<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAuthenticationConfigService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAuthenticationService {
  performLogin(additionalState?: string, params?: any): void;
  performLogout(): void;
  getIdentityClaims(): object;
  getAllResourceAccessRoles(): ObIResourceAccessRoles[];
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAuthenticationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAuthenticationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAuthenticationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockAuthenticationModule, never, never, never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockAuthenticationModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockBreadcrumbComponent {
  static DEFAULTS: ObBreadcrumbConfig;
  readonly maxWidthInput: import("@angular/core").InputSignal<string>;
  readonly separatorInput: import("@angular/core").InputSignal<string>;
  readonly beautifyUrlsInput: import("@angular/core").InputSignal<boolean>;
  get maxWidth(): string;
  showTooltip(event: HTMLElement): boolean;
  getCrumbs(route: ActivatedRoute, crumbs?: ObIBreadcrumb[], currentUrl?: string): Observable<ObIBreadcrumb[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockBreadcrumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockBreadcrumbComponent, "ob-breadcrumb", ["obBreadcrumb"], {
    "maxWidthInput": {
      "alias": "maxWidth";
      "required": false;
      "isSignal": true;
    };
    "separatorInput": {
      "alias": "parameterSeparator";
      "required": false;
      "isSignal": true;
    };
    "beautifyUrlsInput": {
      "alias": "beautifyUrls";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockBreadcrumbModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockBreadcrumbModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockBreadcrumbModule, never, [typeof ObMockBreadcrumbComponent], [typeof ObMockBreadcrumbComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockBreadcrumbModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockButtonDirective {
  readonly obButton: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockButtonDirective, "[obButton]", ["obButton"], {
    "obButton": {
      "alias": "obButton";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockButtonModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockButtonModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockButtonModule, never, [typeof ObMockButtonDirective], [typeof ObMockButtonDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockButtonModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockCollapseComponent {
  static index: number;
  readonly active: import("@angular/core").ModelSignal<boolean>;
  readonly id: import("@angular/core").InputSignal<string>;
  readonly duration: import("@angular/core").InputSignal<number | "slow" | "fast">;
  readonly iconPosition: import("@angular/core").InputSignal<"none" | "left" | "right" | "justified">;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockCollapseComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockCollapseComponent, "ob-collapse", ["obCollapse"], {
    "active": {
      "alias": "active";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "duration": {
      "alias": "duration";
      "required": false;
      "isSignal": true;
    };
    "iconPosition": {
      "alias": "iconPosition";
      "required": false;
      "isSignal": true;
    };
  }, {
    "active": "activeChange";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockCollapseModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockCollapseModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockCollapseModule, never, [typeof ObMockCollapseComponent], [typeof ObMockCollapseComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockCollapseModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockColumnLayoutComponent {
  readonly left: import("@angular/core").InputSignal<boolean>;
  readonly right: import("@angular/core").InputSignal<boolean>;
  readonly noLayout: import("@angular/core").InputSignal<boolean>;
  readonly wider: import("@angular/core").InputSignal<boolean>;
  toggleLeft(): void;
  toggleRight(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockColumnLayoutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockColumnLayoutComponent, "ob-column-layout", ["obColumnLayout"], {
    "left": {
      "alias": "left";
      "required": false;
      "isSignal": true;
    };
    "right": {
      "alias": "right";
      "required": false;
      "isSignal": true;
    };
    "noLayout": {
      "alias": "noLayout";
      "required": false;
      "isSignal": true;
    };
    "wider": {
      "alias": "wider";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
declare class ObMockColumnPanelDirective {
  toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockColumnPanelDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockColumnPanelDirective, "[obColumnPanel]", ["obColumnPanel"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
declare class ObMockColumnToggleDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockColumnToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockColumnToggleDirective, "[obColumnToggle]", ["obColumnToggle"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockColumnLayoutModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockColumnLayoutModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockColumnLayoutModule, never, [typeof ObMockColumnLayoutComponent, typeof ObMockColumnPanelDirective, typeof ObMockColumnToggleDirective], [typeof ObMockColumnLayoutComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockColumnLayoutModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockDocumentMetaModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockDocumentMetaModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockDocumentMetaModule, never, never, never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockDocumentMetaModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockErrorMessagesDirective {
  readonly errors$: Observable<ValidationErrors>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockErrorMessagesDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockErrorMessagesDirective, "[obErrorMessages]", ["obErrorMessages"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMatErrorDirective {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMatErrorDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockMatErrorDirective, "mat-error", never, {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockErrorMessagesService {
  createMessages(control: NgControl): {
    key: string;
    params: Record<string, any>;
  }[];
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockErrorMessagesService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockErrorMessagesModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockErrorMessagesModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockErrorMessagesModule, never, [typeof ObMockErrorMessagesDirective, typeof ObMockMatErrorDirective], [typeof ObMockErrorMessagesDirective, typeof ObMockMatErrorDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockErrorMessagesModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockExternalLinkDirective {
  isExternal: boolean;
  readonly rel: import("@angular/core").InputSignal<string>;
  readonly target: import("@angular/core").InputSignal<string>;
  readonly href: import("@angular/core").InputSignal<string>;
  readonly icon: import("@angular/core").InputSignal<ObEExternalLinkIcon>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockExternalLinkDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockExternalLinkDirective, "a[href]", never, {
    "rel": {
      "alias": "rel";
      "required": false;
      "isSignal": true;
    };
    "target": {
      "alias": "target";
      "required": false;
      "isSignal": true;
    };
    "href": {
      "alias": "href";
      "required": false;
      "isSignal": true;
    };
    "icon": {
      "alias": "icon";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockExternalLinkModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockExternalLinkModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockExternalLinkModule, never, [typeof ObMockExternalLinkDirective], [typeof ObMockExternalLinkDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockExternalLinkModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockDropZoneComponent {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly accept: import("@angular/core").InputSignal<string[]>;
  readonly maxFileSize: import("@angular/core").InputSignal<number>;
  readonly maxFileAmount: import("@angular/core").InputSignal<number>;
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  addFiles(fileList: FileList): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockDropZoneComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockDropZoneComponent, "ob-drop-zone", ["obDropZone"], {
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "maxFileAmount": {
      "alias": "maxFileAmount";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockFileInfoComponent {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly deleteUrl: import("@angular/core").InputSignal<string>;
  readonly getUploadedFilesUrl: import("@angular/core").InputSignal<string>;
  readonly sort: import("@angular/core").Signal<MatSort>;
  dataSource: MatTableDataSource<ObIFileDescription, MatPaginator>;
  displayedColumns: string[];
  fields: string[];
  selectionStatus: ObTSelectionStatus;
  readonly selection: SelectionModel<ObIFileDescription>;
  readonly COLUMN_SELECT = "select";
  readonly COLUMN_ACTION = "action";
  readonly mapFunction: import("@angular/core").InputSignal<(files: ObIFileDescription[]) => ObIFileDescription[]>;
  readonly mapFilesToDeleteUrlFunction: import("@angular/core").InputSignal<(files: ObIFileDescription[]) => string>;
  selectOrUnselectAllItems(): void;
  toggle(row: ObIFileDescription): void;
  delete(files: ObIFileDescription[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockFileInfoComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockFileInfoComponent, "ob-file-info", ["obFileInfo"], {
    "deleteUrl": {
      "alias": "deleteUrl";
      "required": false;
      "isSignal": true;
    };
    "getUploadedFilesUrl": {
      "alias": "getUploadedFilesUrl";
      "required": false;
      "isSignal": true;
    };
    "mapFunction": {
      "alias": "mapFunction";
      "required": false;
      "isSignal": true;
    };
    "mapFilesToDeleteUrlFunction": {
      "alias": "mapFilesToDeleteUrlFunction";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockFileUploadComponent {
  readonly uploadEvent: import("@angular/core").OutputEmitterRef<ObIUploadEvent>;
  readonly accept: import("@angular/core").InputSignal<string[]>;
  readonly singleRequest: import("@angular/core").InputSignal<boolean>;
  readonly maxFileSize: import("@angular/core").InputSignal<number>;
  readonly maxFileAmount: import("@angular/core").InputSignal<number>;
  readonly multiple: import("@angular/core").InputSignal<boolean>;
  readonly uploadUrl: import("@angular/core").InputSignal<string>;
  readonly cancelConfirmation: import("@angular/core").InputSignal<boolean>;
  showLoadingBox: boolean;
  files: File[];
  processEvent(event: ObIUploadEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockFileUploadComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockFileUploadComponent, "ob-file-upload", ["obFileUpload"], {
    "accept": {
      "alias": "accept";
      "required": false;
      "isSignal": true;
    };
    "singleRequest": {
      "alias": "singleRequest";
      "required": false;
      "isSignal": true;
    };
    "maxFileSize": {
      "alias": "maxFileSize";
      "required": false;
      "isSignal": true;
    };
    "maxFileAmount": {
      "alias": "maxFileAmount";
      "required": false;
      "isSignal": true;
    };
    "multiple": {
      "alias": "multiple";
      "required": false;
      "isSignal": true;
    };
    "uploadUrl": {
      "alias": "uploadUrl";
      "required": false;
      "isSignal": true;
    };
    "cancelConfirmation": {
      "alias": "cancelConfirmation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "uploadEvent": "uploadEvent";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockFileUploadService {
  uploadComplete$: Observable<void>;
  delete(deleteUrl: string, files: string[]): Observable<unknown>;
  getUploadedFiles(getUploadedFilesUrl: string): Observable<any>;
  multiUpload(uploadUrl: string, files: File[]): Observable<HttpEvent<unknown> | undefined>;
  notifyUploadComplete(): void;
  upload(uploadUrl: string, file: File): Observable<HttpEvent<unknown> | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockFileUploadService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockFileUploadModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockFileUploadModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockFileUploadModule, never, [typeof ObMockDropZoneComponent, typeof ObMockFileInfoComponent, typeof ObMockFileUploadComponent], [typeof ObMockFileInfoComponent, typeof ObMockFileUploadComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockFileUploadModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockHttpApiInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockHttpApiInterceptor, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockHttpApiInterceptorEvents {
  get requestIntercepted(): Observable<ObIHttpApiRequest>;
  get sessionExpired(): Observable<void>;
  sessionExpire(): void;
  requestIntercept(request: ObIHttpApiRequest): void;
  deactivateSpinnerOnNextAPICalls(number?: number): void;
  deactivateNotificationOnNextAPICalls(number?: number): void;
  deactivateOnNextAPICalls(number?: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockHttpApiInterceptorEvents, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockHttpApiInterceptorConfig {
  api: {
    url: string;
    spinner: boolean;
    spinnerChannel: string;
    notification: {
      active: boolean;
      severity: ObENotificationType;
      title: any;
      text: any;
      sticky: any;
    };
  };
  timeout: number;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockHttpApiInterceptorConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockHttpApiInterceptorModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockHttpApiInterceptorModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockHttpApiInterceptorModule, never, never, never>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockHttpApiInterceptorModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockAriaMenuButtonDirective {
  readonly target: import("@angular/core").InputSignal<string>;
  active: boolean;
  popup: boolean;
  onClick(): void;
  onEscape(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockAriaMenuButtonDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockAriaMenuButtonDirective, "[obAriaMenuButton]", never, {
    "target": {
      "alias": "obAriaMenuButton";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutComponent {
  readonly contentId: WritableSignal<string>;
  readonly route: WritableSignal<{
    path: string | undefined;
    params: Params | undefined;
  }>;
  readonly hasHighContrast: WritableSignal<boolean>;
  readonly navigation: import("@angular/core").ModelSignal<ObINavigationLink[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `navigationChange` instead. */
  readonly navigationChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly skipLinks: import("@angular/core").InputSignal<ObISkipLink[] | ObIDynamicSkipLink[]>;
  readonly collapseBreakpoint: import("@angular/core").InputSignal<ObICollapseBreakpoints>;
  readonly version: import("@angular/core").InputSignal<string>;
  readonly isLayoutCollapsed: WritableSignal<boolean>;
  readonly isLayoutExpanded: WritableSignal<boolean>;
  readonly isScrolling: WritableSignal<boolean>;
  readonly prefersReducedMotion: WritableSignal<boolean>;
  readonly obLogo: Signal<TemplateRef<unknown>>;
  readonly headerControlTemplates: Signal<readonly TemplateRef<unknown>[]>;
  readonly headerMobileControlTemplates: Signal<readonly TemplateRef<unknown>[]>;
  readonly footerLinkTemplates: Signal<readonly TemplateRef<HTMLLinkElement>[]>;
  readonly offCanvasClose: Signal<ElementRef<any>>;
  readonly main: Signal<ElementRef<HTMLElement>>;
  readonly wrapper: Signal<ElementRef<HTMLElement>>;
  readonly skipLinksInternal: Signal<{
    accessKey: number;
    label: string;
    url: string | 'current';
    fragment?: string;
  }[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17.
   *
   * Use the `navigation` model with `[(navigation)]`
   * or update it with `navigation.set(...)` instead.
   */
  emitNavigation(navigation: ObINavigationLink[]): void;
  scrollTop(element?: HTMLElement): void;
  focusElementById(elementId: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockMasterLayoutComponent, "ob-master-layout", ["obMasterLayout"], {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
    "skipLinks": {
      "alias": "skipLinks";
      "required": false;
      "isSignal": true;
    };
    "collapseBreakpoint": {
      "alias": "collapseBreakpoint";
      "required": false;
      "isSignal": true;
    };
    "version": {
      "alias": "version";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigation": "navigationChange";
    "navigationChanged": "navigationChanged";
  }, ["obLogo", "headerControlTemplates", "headerMobileControlTemplates", "footerLinkTemplates"], never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutFooterComponent {
  readonly templates: Signal<readonly TemplateRef<HTMLLinkElement>[]>;
  version: import("@angular/core").InputSignal<string>;
  isCustom: Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutFooterComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockMasterLayoutFooterComponent, "ob-master-layout-footer", ["obMasterLayoutFooter"], {
    "version": {
      "alias": "version";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["templates"], never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutHeaderComponent {
  home$: Observable<string>;
  banner: ObIBanner;
  readonly navigation: ModelSignal<ObINavigationLink[]>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `navigationChange` instead. */
  readonly navigationChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly serviceNavigationConfig: Signal<ObIServiceNavigationConfig & {
    environment: ObEPamsEnvironment;
    rootUrl: string;
  }>;
  readonly obLogo: Signal<TemplateRef<unknown>>;
  readonly templates: Signal<readonly TemplateRef<unknown>[]>;
  readonly mobileTemplates: Signal<readonly TemplateRef<unknown>[]>;
  readonly hasMainNavigation: Signal<boolean>;
  readonly headerControl: Signal<readonly ElementRef<any>[]>;
  readonly headerMobileControl: Signal<readonly ElementRef<any>[]>;
  readonly isCustom: Signal<boolean>;
  readonly isSmall: Signal<boolean>;
  readonly pamsConfiguration: ObIPamsConfiguration | null;
  /**
   * @deprecated since version 16.1 It will be removed with Oblique 17. Use emitQualityOfAuthentication instead
   */
  emitLoginState(loginState: ObLoginState): void;
  emitQualityOfAuthentication(qualityOfAuthentication: ObEQualityOfAuthentication): void;
  emitLogoutUrl(logoutUrl: string): void;
  emitNavigation(navigation: ObINavigationLink[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockMasterLayoutHeaderComponent, "ob-master-layout-header", ["obMasterLayoutHeader"], {
    "navigation": {
      "alias": "navigation";
      "required": false;
      "isSignal": true;
    };
  }, {
    "navigation": "navigationChange";
    "navigationChanged": "navigationChanged";
  }, ["obLogo", "templates", "mobileTemplates"], never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutHeaderToggleDirective {
  toggle($event: any): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutHeaderToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockMasterLayoutHeaderToggleDirective, "[obMasterLayoutHeaderToggle]", ["obMasterLayoutHeaderToggle"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutNavigationComponent {
  readonly currentGrandparentLink: Signal<ObINavigationLink | undefined>;
  readonly currentParentLink: Signal<ObINavigationLink>;
  readonly currentParentRouterLinkBase: Signal<string>;
  readonly isCurrentParentLinkExactMatch: Signal<boolean>;
  hideExternalLinks: boolean;
  readonly links: ModelSignal<ObINavigationLink[] | null>;
  /** @deprecated since Oblique 16. Will be removed in Oblique 17. Use `linksChange` instead. */
  readonly linksChanged: import("@angular/core").OutputEmitterRef<ObINavigationLink[]>;
  readonly navigationLinks: Signal<ObNavigationLink[]>;
  readonly activeLinks: Signal<Set<ObNavigationLink>>;
  routerLinkActiveOptions: IsActiveMatchOptions;
  focusIn(prefix: string, linkId: string): void;
  focusOut(prefix: string, linkId: string): void;
  backUpOrCloseSubMenu(link: ObNavigationLink, obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective): void;
  changeCurrentParentLink(link: ObNavigationLink): void;
  closeSubMenu(obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective, link: ObNavigationLink): void;
  toggleSubMenu(obMasterLayoutNavigationItem: ObMasterLayoutNavigationItemDirective, link: ObNavigationLink): void;
  removeMenuItem(item: ObINavigationLink, mouseEvent: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutNavigationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockMasterLayoutNavigationComponent, "ob-master-layout-navigation", ["obMasterLayoutNavigation"], {
    "links": {
      "alias": "links";
      "required": false;
      "isSignal": true;
    };
  }, {
    "links": "linksChange";
    "linksChanged": "linksChanged";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutNavigationItemDirective {
  isExpanded: boolean;
  toggleSubMenu(): void;
  openSubMenu(): void;
  closeSubMenu(closeMainMenu?: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutNavigationItemDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockMasterLayoutNavigationItemDirective, "[obMasterLayoutNavigationItem]", ["obMasterLayoutNavigationItem"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutNavigationMenuDirective {
  hasOpenedMenu: boolean;
  menuOpened(): void;
  menuClosed(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutNavigationMenuDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockMasterLayoutNavigationMenuDirective, "[obMasterLayoutNavigationMenu]", ["obMasterLayoutNavigationMenu"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutNavigationToggleDirective {
  onClick(event?: KeyboardEvent | MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutNavigationToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockMasterLayoutNavigationToggleDirective, "[obMasterLayoutNavigationToggle]", ["obMasterLayoutNavigationToggle"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutFooterService {
  isCustom: boolean;
  isSticky: boolean;
  get configEvents$(): Observable<ObIMasterLayoutEvent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutFooterService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutHeaderService {
  isCustom: boolean;
  isMedium: boolean;
  isSticky: boolean;
  readonly serviceNavigationConfiguration: import("@angular/core").WritableSignal<ObIServiceNavigationConfig>;
  loginState$: Observable<boolean>;
  updateServiceNavigationConfiguration(configuration: Partial<ObIServiceNavigationConfig>): void;
  get configEvents$(): Observable<ObIMasterLayoutEvent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutHeaderService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutNavigationService {
  isFullWidth: boolean;
  scrollMode: ObEScrollMode;
  get configEvents$(): Observable<ObIMasterLayoutEvent>;
  get scrolled(): Observable<number>;
  get refreshed(): Observable<void>;
  refresh(): void;
  scrollLeft(offset?: number): void;
  scrollRight(offset?: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutNavigationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutComponentService {
  isMenuOpened: boolean;
  hasCover: boolean;
  hasOffCanvas: boolean;
  hasMainNavigation: boolean;
  hasLayout: boolean;
  get configEvents$(): Observable<ObIMasterLayoutEvent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutComponentService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutConfig {
  homePageRoute: string;
  scrollToTopDuration: number;
  showAccessibilityTitle: boolean;
  layout: {
    hasCover: boolean;
    hasMainNavigation: boolean;
    hasOffCanvas: boolean;
    hasLayout: boolean;
    hasMaxWidth: boolean;
  };
  header: ObIMasterLayoutHeader;
  navigation: ObIMasterLayoutNavigation;
  footer: ObIMasterLayoutFooter;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutService {
  readonly header: ObMasterLayoutHeaderService;
  readonly footer: ObMasterLayoutFooterService;
  readonly navigation: ObMasterLayoutNavigationService;
  readonly layout: ObMasterLayoutComponentService;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMasterLayoutModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMasterLayoutModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockMasterLayoutModule, never, [typeof ObMockAriaMenuButtonDirective, typeof ObMockMasterLayoutComponent, typeof ObMockMasterLayoutFooterComponent, typeof ObMockMasterLayoutHeaderComponent, typeof ObMockMasterLayoutHeaderToggleDirective, typeof ObMockMasterLayoutNavigationComponent, typeof ObMockMasterLayoutNavigationItemDirective, typeof ObMockMasterLayoutNavigationMenuDirective, typeof ObMockMasterLayoutNavigationToggleDirective], [typeof ObMockAriaMenuButtonDirective, typeof ObMockMasterLayoutComponent, typeof ObMockMasterLayoutFooterComponent, typeof ObMockMasterLayoutHeaderComponent, typeof ObMockMasterLayoutHeaderToggleDirective, typeof ObMockMasterLayoutNavigationComponent, typeof ObMockMasterLayoutNavigationItemDirective, typeof ObMockMasterLayoutNavigationMenuDirective, typeof ObMockMasterLayoutNavigationToggleDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockMasterLayoutModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNavTreeComponent {
  static DEFAULTS: {
    VARIANT: string;
    HIGHLIGHT: string;
    LABEL_FORMATTER: {};
  };
  readonly items: import("@angular/core").InputSignal<ObNavTreeItemModel[]>;
  readonly prefix: import("@angular/core").InputSignal<string>;
  readonly hasFilter: import("@angular/core").InputSignal<boolean>;
  readonly filterPattern: import("@angular/core").ModelSignal<string>;
  readonly labelFormatter: import("@angular/core").InputSignal<(item: ObNavTreeItemModel, filterPattern?: string) => string>;
  readonly treeAriaLabelledBy: import("@angular/core").InputSignal<string>;
  readonly treeAriaLabel: import("@angular/core").InputSignal<string>;
  readonly patternMatcher: import("@angular/core").InputSignal<(item: ObNavTreeItemModel, pattern?: string) => boolean>;
  visible(item: ObNavTreeItemModel): boolean;
  itemKey(item: ObNavTreeItemModel): string;
  isLinkActive(rla: RouterLinkActive, item: ObNavTreeItemModel): boolean;
  changeCollapsed(items: ObNavTreeItemModel[], collapsed: boolean, all?: boolean): void;
  collapseAll(): void;
  expandAll(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNavTreeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockNavTreeComponent, "ob-nav-tree", ["obNavTree"], {
    "items": {
      "alias": "items";
      "required": false;
      "isSignal": true;
    };
    "prefix": {
      "alias": "prefix";
      "required": false;
      "isSignal": true;
    };
    "hasFilter": {
      "alias": "hasFilter";
      "required": false;
      "isSignal": true;
    };
    "filterPattern": {
      "alias": "filterPattern";
      "required": false;
      "isSignal": true;
    };
    "labelFormatter": {
      "alias": "labelFormatter";
      "required": false;
      "isSignal": true;
    };
    "treeAriaLabelledBy": {
      "alias": "treeAriaLabelledBy";
      "required": false;
      "isSignal": true;
    };
    "treeAriaLabel": {
      "alias": "treeAriaLabel";
      "required": false;
      "isSignal": true;
    };
    "patternMatcher": {
      "alias": "patternMatcher";
      "required": false;
      "isSignal": true;
    };
  }, {
    "filterPattern": "filterPatternChange";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNavTreeModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNavTreeModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockNavTreeModule, never, [typeof ObMockNavTreeComponent], [typeof ObMockNavTreeComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockNavTreeModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNestedFormComponent implements ControlValueAccessor, Validator {
  readonly nestedForm: import("@angular/core").InputSignal<UntypedFormGroup>;
  registerOnChange(fn: any): void;
  registerOnTouched(fn: any): void;
  setDisabledState(isDisabled: boolean): void;
  writeValue(obj: {
    field1?: string;
    field2?: string;
  }): void;
  validate(control: AbstractControl): ValidationErrors | null;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNestedFormComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockNestedFormComponent, "ob-nested-form", ["obNestedForm"], {
    "nestedForm": {
      "alias": "nestedForm";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockParentFormDirective {
  readonly submit$: Observable<void>;
  readonly reset$: Observable<void>;
  submit(): void;
  reset(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockParentFormDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockParentFormDirective, "[obParentFormDirective]", ["obParentFormDirective"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNestedFormModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNestedFormModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockNestedFormModule, never, [typeof ObMockNestedFormComponent, typeof ObMockParentFormDirective], [typeof ObMockNestedFormComponent, typeof ObMockParentFormDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockNestedFormModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNotificationComponent {
  static REMOVE_DELAY: number;
  channel: string;
  customChannel: boolean;
  notifications: ObINotification[];
  variant: Record<string, string>;
  open(notification: ObINotification): void;
  close(notification: any): void;
  remove(notification: Notification): void;
  clear(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNotificationComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockNotificationComponent, "ob-notification", ["obNotification"], {
    "channel": {
      "alias": "channel";
      "required": false;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNotificationService {
  config: ObNotificationConfig;
  clearAllOnNavigate: boolean;
  events: Subject<ObINotification>;
  info(config: ObINotification | string): ObINotification;
  success(config: ObINotification | string): ObINotification;
  warning(config: ObINotification | string): ObINotification;
  error(config: ObINotification | string): ObINotification;
  send(config: ObINotification | string, type?: ObENotificationType): ObINotification;
  clear(channel: any): void;
  clearAll(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNotificationService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNotificationConfig {
  sticky: boolean;
  timeout: number;
  channel: string;
  clearAllOnNavigate: boolean;
  groupSimilar: boolean;
  info: {};
  success: {};
  warning: {};
  error: {};
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNotificationConfig, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNotificationModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNotificationModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockNotificationModule, never, [typeof ObMockNotificationComponent], [typeof ObMockNotificationComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockNotificationModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNumberFormatDirective {
  readonly decimals: import("@angular/core").InputSignal<number>;
  readonly persistent: import("@angular/core").InputSignal<boolean>;
  onBlur(): void;
  onFocus(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNumberFormatDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockNumberFormatDirective, "[obNumberFormat]", ["obNumberFormat"], {
    "decimals": {
      "alias": "decimals";
      "required": false;
      "isSignal": true;
    };
    "persistent": {
      "alias": "persistent";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockNumberFormatModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockNumberFormatModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockNumberFormatModule, never, [typeof ObMockNumberFormatDirective], [typeof ObMockNumberFormatDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockNumberFormatModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockOffCanvasBackdropDirective {
  close(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockOffCanvasBackdropDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockOffCanvasBackdropDirective, ".ob-off-canvas-backdrop", never, {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockOffCanvasContainerDirective {
  open: boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockOffCanvasContainerDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockOffCanvasContainerDirective, ".ob-off-canvas, ob-master-layout", never, {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockOffCanvasToggleDirective {
  toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockOffCanvasToggleDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockOffCanvasToggleDirective, "[obOffCanvasToggle]", ["obOffCanvasToggle"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockOffCanvasService {
  open: boolean;
  readonly opened$: import("rxjs").Observable<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockOffCanvasService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockOffCanvasModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockOffCanvasModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockOffCanvasModule, never, [typeof ObMockOffCanvasBackdropDirective, typeof ObMockOffCanvasContainerDirective, typeof ObMockOffCanvasToggleDirective], [typeof ObMockOffCanvasBackdropDirective, typeof ObMockOffCanvasContainerDirective, typeof ObMockOffCanvasToggleDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockOffCanvasModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockPopoverDirective {
  readonly target: import("@angular/core").InputSignal<TemplateRef<HTMLElement>>;
  readonly placement: import("@angular/core").InputSignal<Placement>;
  readonly popperOptions: import("@angular/core").InputSignal<Options>;
  readonly id: import("@angular/core").InputSignal<string>;
  readonly toggleHandle: import("@angular/core").InputSignal<ObEToggleType>;
  readonly closeOnlyOnToggle: import("@angular/core").InputSignal<boolean>;
  idContent: string;
  toggle(): void;
  handleMouseLeave(): void;
  handleMouseEnter(): void;
  close(): void;
  open(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockPopoverDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockPopoverDirective, "[obPopover]", ["obPopover"], {
    "target": {
      "alias": "obPopover";
      "required": false;
      "isSignal": true;
    };
    "placement": {
      "alias": "placement";
      "required": false;
      "isSignal": true;
    };
    "popperOptions": {
      "alias": "popperOptions";
      "required": false;
      "isSignal": true;
    };
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "toggleHandle": {
      "alias": "toggleHandle";
      "required": false;
      "isSignal": true;
    };
    "closeOnlyOnToggle": {
      "alias": "closeOnlyOnToggle";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockPopoverModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockPopoverModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockPopoverModule, never, [typeof ObMockPopoverDirective], [typeof ObMockPopoverDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockPopoverModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockTopControlComponent {
  readonly scrollToTop: import("@angular/core").OutputEmitterRef<void>;
  scrollTop(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockTopControlComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockTopControlComponent, "ob-top-control", ["obTopControl"], {}, {
    "scrollToTop": "scrollToTop";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockScrollingModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockScrollingModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockScrollingModule, never, [typeof ObMockTopControlComponent], [typeof ObMockTopControlComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockScrollingModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSelectableDirective<T = any> {
  selected: import("@angular/core").ModelSignal<boolean>;
  tabindex: import("@angular/core").ModelSignal<number>;
  value: import("@angular/core").InputSignal<T>;
  cursor: string;
  role: import("@angular/core").WritableSignal<string>;
  onClick($event: KeyboardEvent | MouseEvent): void;
  onFocus(): void;
  focus(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSelectableDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockSelectableDirective<any>, "[obSelectable]", ["obSelectable"], {
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "tabindex": {
      "alias": "tabindex";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "tabindex": "tabindexChange";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSelectableGroupDirective<T = any> {
  readonly role: import("@angular/core").WritableSignal<string>;
  readonly selected: import("@angular/core").ModelSignal<ObSelectableDirective<T>[]>;
  readonly mode: import("@angular/core").ModelSignal<"checkbox" | "radio" | "windows">;
  register(directive: ObSelectableDirective<T>): void;
  toggle(directive: ObSelectableDirective<T>, ctrl?: boolean, shift?: boolean): void;
  focus(directive: ObSelectableDirective<T>): void;
  sort(sortFunction: (a: ObSelectableDirective<T>, b: ObSelectableDirective<T>) => number): void;
  onArrowDown($event: KeyboardEvent): void;
  onArrowUp($event: KeyboardEvent): void;
  onShiftArrowDown($event: KeyboardEvent): void;
  onShiftArrowUp($event: KeyboardEvent): void;
  onCtrlArrowDown($event: KeyboardEvent): void;
  onCtrlArrowUp($event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSelectableGroupDirective<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockSelectableGroupDirective<any>, "[obSelectableGroup]", ["obSelectableGroup"], {
    "selected": {
      "alias": "selected";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selected": "selectedChange";
    "mode": "modeChange";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockObSelectableModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockObSelectableModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockObSelectableModule, never, [typeof ObMockSelectableDirective, typeof ObMockSelectableGroupDirective], [typeof ObMockSelectableDirective, typeof ObMockSelectableGroupDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockObSelectableModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSpinnerComponent {
  readonly channel: import("@angular/core").InputSignal<string>;
  readonly fixed: import("@angular/core").InputSignal<boolean>;
  $state: string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSpinnerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockSpinnerComponent, "ob-spinner", ["obSpinner"], {
    "channel": {
      "alias": "channel";
      "required": false;
      "isSignal": true;
    };
    "fixed": {
      "alias": "fixed";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSpinnerService {
  static CHANNEL: string;
  get events(): Observable<ObISpinnerEvent>;
  activate(channel?: string): void;
  deactivate(channel?: string): void;
  forceDeactivate(channel?: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSpinnerService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockSpinnerModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockSpinnerModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockSpinnerModule, never, [typeof ObMockSpinnerComponent], [typeof ObMockSpinnerComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockSpinnerModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockInputClearDirective {
  readonly control: import("@angular/core").InputSignal<HTMLInputElement>;
  readonly focusOnClear: import("@angular/core").InputSignal<boolean>;
  readonly datePickerRef: import("@angular/core").InputSignal<MatDatepicker<any>>;
  readonly onClear: import("@angular/core").OutputEmitterRef<MouseEvent>;
  cssClass: boolean;
  onClick($event: MouseEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockInputClearDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockInputClearDirective, "[obInputClear]", ["obInputClear"], {
    "control": {
      "alias": "obInputClear";
      "required": false;
      "isSignal": true;
    };
    "focusOnClear": {
      "alias": "focusOnClear";
      "required": false;
      "isSignal": true;
    };
    "datePickerRef": {
      "alias": "datePickerRef";
      "required": false;
      "isSignal": true;
    };
  }, {
    "onClear": "onClear";
  }, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockInputClearModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockInputClearModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockInputClearModule, never, [typeof ObMockInputClearDirective], [typeof ObMockInputClearDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockInputClearModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockTranslateParamsPipe implements PipeTransform {
  transform(value: string, params?: any): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockTranslateParamsPipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObMockTranslateParamsPipe, "obTranslateParams", true>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockTranslateParamsModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockTranslateParamsModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockTranslateParamsModule, never, [typeof ObMockTranslateParamsPipe], [typeof ObMockTranslateParamsPipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockTranslateParamsModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnknownRouteComponent {
  homePageRoute: any;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnknownRouteComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockUnknownRouteComponent, "ob-unknown-route", ["obUnknownRoute"], {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnknownRouteModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnknownRouteModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockUnknownRouteModule, never, [typeof ObMockUnknownRouteComponent], [typeof ObMockUnknownRouteComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockUnknownRouteModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnsavedChangesDirective {
  readonly id: import("@angular/core").InputSignal<string>;
  readonly isActive: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnsavedChangesDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<ObMockUnsavedChangesDirective, "[obUnsavedChanges]", ["obUnsavedChanges"], {
    "id": {
      "alias": "id";
      "required": true;
      "isSignal": true;
    };
    "isActive": {
      "alias": "isActive";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnsavedChangesService {
  readonly isActive: import("@angular/core").WritableSignal<boolean>;
  watch(formId: string, form: ControlContainer): void;
  unWatch(formId: string): void;
  canDeactivate(): boolean;
  ignoreChanges(formIds?: string[]): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnsavedChangesService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnsavedChangesGuard {
  canDeactivate(): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnsavedChangesGuard, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockUnsavedChangesModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockUnsavedChangesModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockUnsavedChangesModule, never, [typeof ObMockUnsavedChangesDirective], [typeof ObMockUnsavedChangesDirective]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockUnsavedChangesModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockTranslatePipe implements PipeTransform {
  transform(value: string): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockTranslatePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObMockTranslatePipe, "translate", true>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockDatePipe implements PipeTransform {
  transform(value: string | number | Date, format?: string, timezone?: string): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockDatePipe, never>;
  static ɵpipe: i0.ɵɵPipeDeclaration<ObMockDatePipe, "obDate", true>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockLanguageModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockLanguageModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockLanguageModule, never, [typeof ObMockDatePipe], [typeof ObMockDatePipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockLanguageModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockIconService {
  registerOnAppInit(iconConfig?: ObIconConfig): void;
  registerIconSetsAsync(...urls: string[]): void;
  registerIconSets(...iconSets: string[]): void;
  registerIconsAsync(...icons: {
    name: string;
    url: string;
  }[]): void;
  registerIcons(...icons: {
    name: string;
    svg: string;
  }[]): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockIconService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockTranslateService {
  translations: any;
  onLangChange: EventEmitter<LangChangeEvent>;
  onTranslationChange: EventEmitter<TranslationChangeEvent>;
  onFallbackLangChange: EventEmitter<FallbackLangChangeEvent>;
  fallbackLang: import("@angular/core").WritableSignal<string>;
  currentLang: import("@angular/core").WritableSignal<string>;
  private langs;
  setTranslation(lang: string, translations: object, shouldMerge?: boolean): void;
  getStreamOnTranslationChange(key: string | string[], interpolateParams?: object): Observable<any>;
  stream(key: string | string[], interpolateParams?: object): Observable<any>;
  getBrowserLang(): string;
  getFallbackLang(): string;
  setFallbackLang(lang: string): void;
  get(key: string | string[], interpolateParams?: object): Observable<string | any>;
  use(lang: string): Observable<any>;
  translate(key: string | string[], interpolateParams?: object, lang?: string): string | any;
  instant(string: string): string;
  getTranslation(lang: string): Observable<any>;
  getLangs(): string[];
  addLangs(langs: string[]): void;
  getParsedResult(translations: any, key: any, interpolateParams?: object): any;
  set(key: string, value: string, lang?: string): void;
  reloadLang(lang: string): Observable<any>;
  resetLang(lang: string): void;
  getBrowserCultureLang(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockTranslateService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * @deprecated since version 9.0.0. No removal version is planned. Real implementation of Oblique Modules should be used instead.
 */
export declare class ObliqueTestingModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObliqueTestingModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObliqueTestingModule, never, [typeof ObMockAlertModule, typeof ObMockAuthenticationModule, typeof ObMockBreadcrumbModule, typeof ObMockButtonModule, typeof ObMockCollapseModule, typeof ObMockColumnLayoutModule, typeof ObMockDocumentMetaModule, typeof ObMockErrorMessagesModule, typeof ObMockExternalLinkModule, typeof ObMockFileUploadModule, typeof ObMockHttpApiInterceptorModule, typeof ObMockMasterLayoutModule, typeof ObMockNavTreeModule, typeof ObMockNestedFormModule, typeof ObMockNotificationModule, typeof ObMockNumberFormatModule, typeof ObMockOffCanvasModule, typeof ObMockPopoverModule, typeof ObMockScrollingModule, typeof ObMockObSelectableModule, typeof ObMockSpinnerModule, typeof ObMockInputClearModule, typeof ObMockTranslateParamsModule, typeof ObMockUnknownRouteModule, typeof ObMockUnsavedChangesModule, typeof ObMockTranslatePipe], [typeof ObMockAlertModule, typeof ObMockAuthenticationModule, typeof ObMockBreadcrumbModule, typeof ObMockButtonModule, typeof ObMockCollapseModule, typeof ObMockColumnLayoutModule, typeof ObMockDocumentMetaModule, typeof ObMockErrorMessagesModule, typeof ObMockExternalLinkModule, typeof ObMockFileUploadModule, typeof ObMockHttpApiInterceptorModule, typeof ObMockMasterLayoutModule, typeof ObMockNavTreeModule, typeof ObMockNestedFormModule, typeof ObMockNotificationModule, typeof ObMockNumberFormatModule, typeof ObMockOffCanvasModule, typeof ObMockPopoverModule, typeof ObMockScrollingModule, typeof ObMockObSelectableModule, typeof ObMockSpinnerModule, typeof ObMockInputClearModule, typeof ObMockTranslateParamsModule, typeof ObMockUnknownRouteModule, typeof ObMockUnsavedChangesModule, typeof ObMockTranslatePipe]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObliqueTestingModule>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockMatElement implements ControlValueAccessor {
  registerOnChange(fn: any): void;
  registerOnTouched(fn: any): void;
  setDisabledState(isDisabled: boolean): void;
  writeValue(obj: any): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockMatElement, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObMockMatElement, "mat-select, mat-slide-toggle, mat-slider", never, {}, {}, never, never, true, never>;
}
/**
 *  @deprecated since Oblique 11. No removal version is planned. Use the real instances instead
 */
export declare class ObMockModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObMockModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObMockModule, never, [typeof ObMockMatElement], [typeof ObMockMatElement]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObMockModule>;
}
export interface ObIAutocompleteInputOption<T = string> {
  label: T;
  iconName?: ObEIcon;
  disabled?: boolean;
  ariaLabel?: string;
}
export interface ObIAutocompleteInputOptionGroup<T = string> {
  groupLabel: string;
  groupOptions: ObIAutocompleteInputOption<T>[];
  disabled?: boolean;
}
export type OptionLabelIconPosition = 'start' | 'end' | 'none';
export declare class ObAutocompleteComponent<T = string> implements ControlValueAccessor, AfterViewInit, DoCheck {
  readonly withErrorMessages: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly inputLabelKey: import("@angular/core").InputSignal<string>;
  readonly noResultKey: import("@angular/core").InputSignal<string>;
  readonly autocompleteOptions: import("@angular/core").InputSignal<(ObIAutocompleteInputOption<T> | ObIAutocompleteInputOptionGroup<T>)[]>;
  readonly filterRegexFlag: import("@angular/core").InputSignal<string>;
  readonly highlightCssClass: import("@angular/core").InputSignal<string>;
  readonly optionIconPosition: import("@angular/core").InputSignal<OptionLabelIconPosition>;
  readonly displayWith: import("@angular/core").InputSignal<(value: any) => string>;
  readonly selectedOptionChange: import("@angular/core").OutputEmitterRef<ObIAutocompleteInputOption<T>>;
  autocompleteInputControl: FormControl<string | T>;
  filteredOptions: Signal<(ObIAutocompleteInputOption<T> | ObIAutocompleteInputOptionGroup<T>)[]>;
  hasGroupOptions: Signal<boolean>;
  readonly searchText: Signal<string>;
  readonly hints: Signal<{
    align: 'start' | 'end';
    template: string;
  }[]>;
  private readonly autocompleteTrigger;
  private readonly matHints;
  private readonly matHintsElementRefs;
  private readonly destroyRef;
  private readonly obAutocompleteTextToFindService;
  private readonly injector;
  private readonly elementRef;
  private lastRect?;
  constructor();
  ngDoCheck(): void;
  ngAfterViewInit(): void;
  setDisabledState(isDisabled: boolean): void;
  /**
   * Write a new value to the element.
   */
  writeValue(value: T): void;
  /**
   * Set the function to be called
   * when the control receives a change event.
   */
  registerOnChange(fn: (v: unknown) => void): void;
  /**
   * Set the function to be called
   * when the control receives a touch event.
   */
  registerOnTouched(fn: () => void): void;
  onModelTouched: () => void;
  protected selectionChange(option: ObIAutocompleteInputOption<T>, event: MatOptionSelectionChange): void;
  private getStringValue;
  private filterAutocomplete;
  private filterGroups;
  private filterOptions;
  private isGroupOption;
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAutocompleteComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ObAutocompleteComponent<any>, "ob-autocomplete", never, {
    "withErrorMessages": {
      "alias": "withErrorMessages";
      "required": false;
      "isSignal": true;
    };
    "inputLabelKey": {
      "alias": "inputLabelKey";
      "required": false;
      "isSignal": true;
    };
    "noResultKey": {
      "alias": "noResultKey";
      "required": false;
      "isSignal": true;
    };
    "autocompleteOptions": {
      "alias": "autocompleteOptions";
      "required": false;
      "isSignal": true;
    };
    "filterRegexFlag": {
      "alias": "filterRegexFlag";
      "required": false;
      "isSignal": true;
    };
    "highlightCssClass": {
      "alias": "highlightCssClass";
      "required": false;
      "isSignal": true;
    };
    "optionIconPosition": {
      "alias": "optionIconPosition";
      "required": false;
      "isSignal": true;
    };
    "displayWith": {
      "alias": "displayWith";
      "required": false;
      "isSignal": true;
    };
  }, {
    "selectedOptionChange": "selectedOptionChange";
  }, ["matHints", "matHintsElementRefs"], ["[matPrefix]", "[matSuffix]", "[matPrefix]", "[matSuffix]"], true, never>;
}
export declare class ObAutocompleteModule {
  static ɵfac: i0.ɵɵFactoryDeclaration<ObAutocompleteModule, never>;
  static ɵmod: i0.ɵɵNgModuleDeclaration<ObAutocompleteModule, never, [typeof ObAutocompleteComponent], [typeof ObAutocompleteComponent]>;
  static ɵinj: i0.ɵɵInjectorDeclaration<ObAutocompleteModule>;
}
export declare const appVersion = "16.0.5";
export {};
//# sourceMappingURL=oblique.d.ts.map