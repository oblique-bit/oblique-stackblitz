/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV8toV9 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const schematics_2 = require("@angular/cdk/schematics");
const utils_1 = require("../utils");
class UpdateV8toV9 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Analyzing project');
            return (0, schematics_1.chain)([
                this.renameTranslationKeys(),
                this.removeObUseObliqueIconsToken(),
                this.updateBrowserCompatibilityMessages(),
                this.renameJumpLinks(),
                this.useKebabCaseForMixins(),
                this.renameOpened(),
                this.addTelemetryInfo(),
                this.addIconModule(),
            ])(tree, context);
        };
    }
    renameTranslationKeys() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming Oblique translation keys');
            const apply = (filePath) => {
                [
                    'progressBar',
                    'mainContent',
                    'checkAll',
                    'uncheckAll',
                    'searchPlaceholder',
                    'defaultTitle',
                    'allSelected',
                    'offCanvas',
                    'topControl',
                    'noResults',
                ].forEach(key => (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`(?<=i18n\\.oblique[\\w.-]*)${key}`, 'g'), this.toKebabCase(key)));
            };
            return (0, utils_1.applyInTree)(tree, apply, '*.{html,ts,json}');
        });
    }
    toKebabCase(input) {
        return (input
            ?.match(/[A-Z]?[a-z]+/g)
            ?.map(match => match.toLowerCase())
            ?.join('-') ?? '');
    }
    removeObUseObliqueIconsToken() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObUseObliqueIcons is set to true');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /\s*{\s*provide\s*:\s*ObUseObliqueIcons\s*,\s*useValue\s*:\s*true\s*}\s*,+/g, '');
                (0, utils_1.replaceInFile)(tree, filePath, /,+\s*{\s*provide\s*:\s*ObUseObliqueIcons\s*,\s*useValue\s*:\s*true\s*}\s*/, '');
                (0, utils_1.replaceInFile)(tree, filePath, /ObUseObliqueIcons\s*,?/, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    updateBrowserCompatibilityMessages() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Oblique: Updating browser compatibility check message');
            (0, utils_1.getIndexPaths)(tree).forEach((indexPath) => (0, utils_1.overwriteIndexFile)(indexPath, tree, new RegExp(/<noscript>(?:.|\r?\n)*<\/div>/gm)));
            return tree;
        });
    }
    renameJumpLinks() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename jumpLinks into skipLinks');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /ObIJumpLink/g, 'ObISkipLink');
                (0, utils_1.replaceInFile)(tree, filePath, /jumpLinks/g, 'skipLinks');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.tsAndHtml);
        });
    }
    useKebabCaseForMixins() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename some mixins to use kebab-case');
            const apply = (filePath) => {
                [
                    'ob-gridTemplate',
                    'ob-gridSpan',
                    'ob-gridWidth',
                    'ob-flexBase',
                    'ob-flexGrow',
                    'ob-dropShadow',
                    'ob-innerBottomShadow',
                ].forEach(mixin => {
                    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(mixin, 'g'), this.toKebabCase(mixin));
                });
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        });
    }
    renameOpened() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename getOpened to opened$');
            const apply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                const offCanvas = /(?<offCanvas>\w*)\s*:\s*ObOffCanvasService/.exec(fileContent)?.groups?.offCanvas;
                if (offCanvas) {
                    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`${offCanvas}.opened(?!\\$)`), `${offCanvas}.opened$`);
                }
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    addTelemetryInfo() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Update Telemetry info');
            const mainTsPathPerProject = (0, utils_1.getFilePathPerProject)(tree, ['architect', 'build', 'options', 'main']);
            const rootModulesPathPerProject = (0, utils_1.getRootModulePathPerProject)(tree, mainTsPathPerProject);
            this.addTelemetry(tree, context, mainTsPathPerProject, rootModulesPathPerProject);
            this.removeTelemetryDisable(tree, context, rootModulesPathPerProject.map(file => file.path));
            return tree;
        });
    }
    addTelemetry(tree, context, mainTsPathPerProject, rootModulesPathPerProject) {
        (0, utils_1.infoMigration)(context, "Configure Telemetry for projects that didn't disable it.");
        const tsConfigPathsPerProject = (0, utils_1.getFilePathPerProject)(tree, ['architect', 'build', 'options', 'tsConfig']);
        rootModulesPathPerProject
            .map(file => ({ ...file, content: (0, utils_1.readFile)(tree, file.path) }))
            .map(file => ({ ...file, isDisabled: this.extractIsTelemetryDisabled(file.content) }))
            .filter(file => !file.isDisabled)
            .map(file => file.project)
            .map(project => ({
            project,
            mainTsPath: this.getProjectPath(mainTsPathPerProject, project),
            tsConfigPath: this.getProjectPath(tsConfigPathsPerProject, project),
        }))
            .filter(paths => !!paths.mainTsPath && !!paths.tsConfigPath)
            .forEach(paths => {
            this.updateMainTs(tree, paths.mainTsPath, paths.project);
            this.updateTsConfig(tree, paths.tsConfigPath);
            this.updatePackageJson(tree);
        });
    }
    extractIsTelemetryDisabled(fileContent) {
        return (/{\s*provide\s*:\s*TELEMETRY_DISABLE\s*,\s*useValue\s*:\s*(?<isDisabled>\w*)}/.exec(fileContent)?.groups
            ?.isDisabled === 'true');
    }
    getProjectPath(target, project) {
        return target.find(config => config.project === project)?.path ?? '';
    }
    removeTelemetryDisable(tree, context, rootModulePaths) {
        (0, utils_1.infoMigration)(context, 'Remove TELEMETRY_DISABLE injection token');
        rootModulePaths.forEach(path => (0, utils_1.replaceInFile)(tree, path, /{\s*provide\s*:\s*TELEMETRY_DISABLE\s*,\s*useValue\s*:\s*(?:true|false)}\s*,?/, ''));
    }
    updateMainTs(tree, mainTsPath, project) {
        const content = (0, utils_1.readFile)(tree, mainTsPath);
        if (!/{\s*provide\s*:\s*OB_PROJECT_INFO\s*,\s*useValue/.test(content)) {
            tree.overwrite(mainTsPath, [
                "import {OB_PROJECT_INFO} from '@oblique/oblique';",
                `import packageInfo from '${(0, utils_1.getPackageJsonPath)(tree, project)}';`,
                content
                    .replace(/(?<=platformBrowserDynamic\(\s*)\[?\s*(?<providers>{\s*provide.*})?\s*]?\s*(?=\))/s, '[$<providers>,\n{provide: OB_PROJECT_INFO, useValue: {name: packageInfo.name, version: packageInfo.version, title: packageInfo.title}}\n]')
                    .replace(/\[,/, '['),
            ].join('\n'));
        }
    }
    updateTsConfig(tree, tsConfigPath) {
        const content = (0, utils_1.readFile)(tree, tsConfigPath);
        let replacement = (0, utils_1.addTsCompilerOption)(content, 'resolveJsonModule');
        replacement = (0, utils_1.addTsCompilerOption)(replacement, 'allowSyntheticDefaultImports');
        tree.overwrite(tsConfigPath, replacement);
    }
    updatePackageJson(tree) {
        const content = (0, utils_1.readFile)(tree, utils_1.packageJsonConfigPath);
        if (!/^\s*"title"/.test(content)) {
            tree.overwrite(utils_1.packageJsonConfigPath, content.replace(/^(?<tabs>\s*)"name"\s*:\s*"(?<name>.*)"/m, '$<tabs>"title": "$<name>",\n$<tabs>"name": "$<name>"'));
        }
    }
    addIconModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Import Oblique icons in the root module');
            const mainTsPathPerProject = (0, utils_1.getFilePathPerProject)(tree, ['architect', 'build', 'options', 'main']);
            (0, utils_1.getRootModulePathPerProject)(tree, mainTsPathPerProject)
                .map(item => item.path)
                .forEach(rootModulePath => {
                (0, schematics_2.addModuleImportToModule)(tree, rootModulePath, 'ObIconModule', '@oblique/oblique');
                const content = (0, utils_1.readFile)(tree, rootModulePath);
                tree.overwrite(rootModulePath, content.replace(/(?<=imports)(?<prefix>.*)ObIconModule(?!\.forRoot\()/s, '$<prefix>ObIconModule.forRoot()'));
            });
            return tree;
        });
    }
}
exports.UpdateV8toV9 = UpdateV8toV9;
