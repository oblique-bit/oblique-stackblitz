/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV9toV10 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
const utils_1 = require("../utils");
class UpdateV9toV10 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            this.renameIcons(),
            this.removeObUseObliqueIcons(),
            this.removeTelemetryFromMainTs(),
            this.removeBootstrapCSS(),
            this.removeMaterialCSS(),
            this.addAngularAuthAndJwtDecodeDependencies(),
        ])(tree, context);
    }
    renameIcons() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename attachement into attachment for icon names');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="attachement/g, 'svgIcon="attachment');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="mail-attachement/g, 'svgIcon="mail-attachment');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon.ATTACHEMENT/g, 'ObEIcon.ATTACHMENT');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon.MAIL_ATTACHEMENT/g, 'ObEIcon.MAIL_ATTACHMENT');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.tsAndHtml);
        });
    }
    removeObUseObliqueIcons() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObUseObliqueIcons');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObUseObliqueIcons', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /(?:,\s*)?{\s*provide\s*:\s*ObUseObliqueIcons\s*,\s*useValue\s*:\s*(?:true|false)\s*}/, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeTelemetryFromMainTs() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove the OB_PROJECT_INFO injection token');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'OB_PROJECT_INFO', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /import\s+packageInfo\s+from\s+['"]\.\.\/package\.json['"]\s*;\s?/s, '');
                (0, utils_1.replaceInFile)(tree, filePath, /(?:,\s*)?{\s*provide\s*:\s*OB_PROJECT_INFO\s*,\s*useValue\s*:\s*{.*}\s*,?\s*/s, '');
                (0, utils_1.replaceInFile)(tree, filePath, /\s*\[\s*]\s*/, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, 'main.ts');
        });
    }
    removeBootstrapCSS() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove oblique-bootstrap and oblique-utilities from angular.json');
            return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => (config || []).filter((style) => !/node_modules\/@oblique\/oblique\/styles\/s?css\/oblique-(?:utilities|bootstrap)\.s?css?/.test(style)));
        });
    }
    removeMaterialCSS() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove oblique-material from angular.json');
            return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => (config || []).filter((style) => !/node_modules\/@oblique\/oblique\/styles\/s?css\/oblique-material\.s?css/.test(style)));
        });
    }
    addAngularAuthAndJwtDecodeDependencies() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Oblique: Adding angular-oauth2-oidc and jwt-decode dependencies');
            (0, ng_add_utils_1.addDependency)(tree, 'angular-oauth2-oidc');
            (0, ng_add_utils_1.addDependency)(tree, 'jwt-decode');
            return tree;
        });
    }
}
exports.UpdateV9toV10 = UpdateV9toV10;
