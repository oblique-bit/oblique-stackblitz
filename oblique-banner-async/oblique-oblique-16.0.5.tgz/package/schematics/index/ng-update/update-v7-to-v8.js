/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV7toV8 = void 0;
/* eslint-disable prefer-named-capture-group */
const schematics_1 = require("@angular-devkit/schematics");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
const utils_1 = require("../utils");
const ng_update_utils_1 = require("./ng-update-utils");
class UpdateV7toV8 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Analyzing project');
            return (0, schematics_1.chain)([
                this.prefixScssVariableNames(),
                this.prefixMixinNames(),
                this.removeLayoutCollapse(),
                this.removeDlHorizontalVariants(),
                this.removeCompatCss(),
                this.removeThemeService(),
                this.removeObMandatory(),
                this.migrateMasterLayoutProperties(),
                this.migrateObEMasterLayoutEventValues(),
                this.migrateConfigEvents(),
                this.updateBrowserCompatibilityMessage(),
                this.migrateEditorConfig(),
                this.migrateLinting(),
            ])(tree, context);
        };
    }
    prefixScssVariableNames() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Prefix scss variable names');
            const apply = (filePath) => {
                [
                    // Palette CI-CD colors
                    'venetian-red',
                    'red',
                    'cerulean',
                    'malibu',
                    'pattens-blue',
                    'solitude',
                    'clear-day',
                    'mocassin',
                    'white',
                    'smoke',
                    'gainsboro',
                    'light-gray',
                    'silver',
                    'empress',
                    'coal',
                    'night-rider',
                    'black',
                    'gray-extra-light',
                    'gray-lighter',
                    'gray-light',
                    'gray',
                    'gray-dark',
                    'gray-darker',
                    // Bootstrap
                    'secondary',
                    'info',
                    'body-width',
                    'danger',
                    'body-color',
                    'link-color',
                    'link-hover-color',
                    'theme-color-interval',
                    'input-color',
                    'input-border-color',
                    'input-border-radius',
                    'input-border-radius-lg',
                    'input-border-radius-sm',
                    'dropdown-border-color',
                    'dropdown-link-color',
                    'dropdown-link-hover-color',
                    'nav-link-disabled-color',
                    'nav-tabs-link-hover-border-color',
                    'nav-pills-border-radius',
                    'list-group-border-radius',
                    'list-group-item-padding-x',
                    'modal-content-border-color',
                    'alert-border-radius',
                    'alert-border-width',
                    // Variables
                    'duration-default',
                    'duration-fast',
                    'smaller',
                    'smallest',
                    'bigger',
                    'biggest',
                    'font-size-base',
                    'font-size-xl',
                    'font-size-lg',
                    'font-size-sm',
                    'font-size-xs',
                    'font-size-normal',
                    'font-size-biggest',
                    'font-size-bigger',
                    'font-size-smaller',
                    'font-size-smallest',
                    'spacing-xl',
                    'spacing-lg',
                    'spacing-default',
                    'spacing-sm',
                    'spacing-xs',
                    'z-index-default',
                    'z-index-controls',
                    'z-index-layout',
                    'z-index-widget',
                    'z-index-overlay',
                    'z-index-overlay-top',
                    'header-height',
                    'header-height-md',
                    'header-height-no-navigation',
                    'header-height-collapsed',
                    'navigation-height',
                    'footer-height',
                    'footer-height-md',
                    'footer-height-sm',
                    'footer-height-collapsed',
                    'layout-collapse',
                    'border-radius-base',
                    'navigation-scrollable-padding',
                    'column-width',
                    'off-canvas-sidebar-width',
                    'off-canvas-sidebar-collapsed-width',
                    'alert-symbol-width',
                    'column-layout-toggle-height',
                    'column-layout-toggle-width',
                    'column-layout-toggle-radius',
                    'sticky-element-height',
                    'sticky-element-height-sm',
                    'sticky-element-height-lg',
                    'stepper-size',
                    'stepper-size-sm',
                    'stepper-size-lg',
                    'stepper-font-size',
                    'stepper-sm-font-size',
                    'stepper-lg-font-size',
                    'table-collapsed-header-width',
                    'grid-breakpoints',
                    'icon-font-family',
                ].forEach(scssVariable => (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\$${scssVariable}`, 'g'), `$ob-${scssVariable}`));
                [
                    // Brand
                    'default',
                    'accent',
                    'extra-light',
                    'light',
                    'primary',
                    'dark',
                    'success-light',
                    'success',
                    'success-dark',
                    'warning-light',
                    'warning',
                    'warning-dark',
                    'error-light',
                    'error',
                    'error-dark',
                    'logo-width',
                    'logo-height',
                    'logo-height-collapsed',
                    'logo-width-collapsed',
                    'line-width',
                ].forEach(scssVariable => (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\$brand-${scssVariable}`, 'g'), `$ob-${scssVariable}`));
                // Palette Oblique colors
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\$(primary|error|gray|success|warning)-(\d00?)/g), '$ob-$1-$2');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        });
    }
    prefixMixinNames() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Prefix mixin names');
            const apply = (filePath) => {
                [
                    'callout-styles',
                    'firefox',
                    'bubble-tail',
                    'bubble-tail-border',
                    'link-btn',
                    'column-separator',
                    'layout-collapse-down',
                    'layout-collapse-up',
                    'media-breakpoint-up',
                    'media-breakpoint-down',
                    'horizontal-description-list',
                    'nav-hover',
                    'nav-indent',
                    'stepper-state',
                    'stepper-variant',
                    'table-collapse',
                    'h1',
                    'h2',
                    'h3',
                    'h4',
                    'h5',
                    'h6',
                    'subtitle1',
                    'subtitle2',
                    'body1',
                    'body2',
                    'button',
                    'caption',
                    'overline',
                    'badge-styles',
                    'btn-variant',
                    'mixed-dropdown-btn-group',
                    'box-shadow-secondary',
                    'checkbox-variant',
                    'radio-variant',
                    'form-control-validation',
                    'icon-base',
                    'icon',
                    'table-variant',
                    'text-control-clear-position',
                    'toggle-state',
                    'toggle-before',
                    'toggle-after',
                    'toggle-icon-before',
                    'toggle-icon-after',
                    'add-toggle',
                    'form-field-size',
                    'dropShadow',
                    'innerBottomShadow',
                    'list-title',
                ].forEach(mixin => (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\@include ${mixin}`, 'g'), `@include ob-${mixin}`));
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        });
    }
    removeLayoutCollapse() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replacing layout-collapse mixins');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(?:ob-)?layout-collapse-(up|down)(?:\(\))?/g, `ob-media-breakpoint-$1(md)`);
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        });
    }
    removeObMandatory() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObMandatoryModule, ObMandatoryDirective and their Testing-Mocks');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\s?(Ob(?:Mock)?Mandatory(?:Module|Directive),?)/g), '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeDlHorizontalVariants() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove .ob-horizontal-* classes');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\s?ob-horizontal-(?:large|small)/g), '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    removeCompatCss() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Removing compat styles');
            return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => (config || []).filter((style) => !/node_modules\/@oblique\/oblique\/styles\/css\/oblique-compat\.s?css/.test(style)));
        });
    }
    removeThemeService() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObThemeService');
            const apply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                if (fileContent.includes('ObThemeService')) {
                    const service = /(?<service>\w*)\s*:\s*ObThemeService,?/.exec(fileContent)?.groups?.service;
                    const theme = this.getCSSPath(new RegExp(`${service}\\.setTheme\\((?<theme>.*)\\)`).exec(fileContent)?.groups?.theme || '');
                    const font = this.getCSSPath(new RegExp(`${service}\\.setFont\\((?<font>.*)\\)`).exec(fileContent)?.groups?.font || '');
                    const stylesPath = ['architect', 'build', 'options', 'styles'];
                    [theme, font]
                        .filter(property => !!property)
                        .forEach(property => {
                        (0, utils_1.addAngularConfigInList)(tree, stylesPath, property);
                    });
                    tree.overwrite(filePath, fileContent
                        .replace(/(?:THEMES|FONTS),?(?!\.)\s*/g, '') // remove imports of THEMES and FONTS
                        .replace(/[\w ]*\s*:\s*ObThemeService,?\s*/, '') // remove service injection in constructor
                        .replace(/ObThemeService,?\s*/, '') // remove service import
                        .replace(new RegExp(`(?:this\\.)?${service}\\.set(?:Theme|Font)\\(.*\\);\\s*`, 'g'), '') // remove call to setTheme / setFont
                        .replace(/,(\s*(?:\)|}))/g, '$1') // remove eventual trailing commas im imports
                        .replace(/import\s*{\s*}\s*from\s*['"]@oblique\/oblique['"]\s*;\s*/g, '') // remove empty imports
                        .replace(/constructor\s*\(\s*\)\s*{\s*}/g, '') // remove empty imports
                    );
                }
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    getCSSPath(themeOrFont) {
        switch (themeOrFont) {
            case 'oblique-material':
            case 'THEMES.MATERIAL':
                return 'node_modules/@oblique/oblique/styles/css/oblique-material.css';
            case 'oblique-bootstrap':
            case 'THEMES.BOOTSTRAP':
                return 'node_modules/@oblique/oblique/styles/css/oblique-bootstrap.css';
            case 'frutiger':
            case 'FONTS.FRUTIGER':
                return 'node_modules/@oblique/oblique/styles/css/frutiger.css';
            case 'roboto':
            case 'FONTS.ROBOTO':
                return 'node_modules/@oblique/oblique/styles/css/roboto.css';
            default:
                return undefined;
        }
    }
    migrateMasterLayoutProperties() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replacing master Layout properties: header.isAnimated, footer.isSmall, layout.isFixed, hasScrollTransition, isMedium');
            const toApply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                let replacement = fileContent;
                replacement = this.migrateMasterLayoutConfig(replacement);
                replacement = (0, ng_update_utils_1.removeProperty)(replacement, 'header', 'isAnimated');
                replacement = (0, ng_update_utils_1.removeProperty)(replacement, 'footer', 'isSmall');
                replacement = this.migrateMasterLayoutIsFixed(replacement); // migrate the setter
                replacement = (0, ng_update_utils_1.removeProperty)(replacement, 'layout', 'isFixed'); // remove the getter
                replacement = this.migrateProperty(replacement, 'footer', 'hasScrollTransition', 'hasLogoOnScroll');
                replacement = this.migrateProperty(replacement, 'header', 'hasScrollTransition', 'reduceOnScroll');
                replacement = this.migrateProperty(replacement, 'header', 'isMedium', 'isSmall');
                if (fileContent !== replacement) {
                    tree.overwrite(filePath, replacement);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    migrateObEMasterLayoutEventValues() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replacing ObEMasterLayoutEventValues values');
            const toApply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                const replacement = fileContent
                    .replace(/ObEMasterLayoutEventValues\.STICKY\b/g, 'ObEMasterLayoutEventValues.HEADER_IS_STICKY')
                    .replace(/ObEMasterLayoutEventValues\.MEDIUM\b/g, 'ObEMasterLayoutEventValues.HEADER_IS_SMALL')
                    .replace(/ObEMasterLayoutEventValues\.COVER\b/g, 'ObEMasterLayoutEventValues.LAYOUT_HAS_COVER')
                    .replace(/ObEMasterLayoutEventValues\.OFF_CANVAS\b/g, 'ObEMasterLayoutEventValues.LAYOUT_HAS_OFF_CANVAS')
                    .replace(/ObEMasterLayoutEventValues\.MAIN_NAVIGATION\b/g, 'ObEMasterLayoutEventValues.LAYOUT_HAS_MAIN_NAVIGATION')
                    .replace(/ObEMasterLayoutEventValues\.LAYOUT\b/g, 'ObEMasterLayoutEventValues.LAYOUT_HAS_DEFAULT_LAYOUT')
                    .replace(/ObEMasterLayoutEventValues\.COLLAPSE\b/g, 'ObEMasterLayoutEventValues.IS_MENU_OPENED')
                    .replace(/ObEMasterLayoutEventValues\.FULL_WIDTH\b/g, 'ObEMasterLayoutEventValues.NAVIGATION_IS_FULL_WIDTH')
                    .replace(/ObEMasterLayoutEventValues\.SCROLLABLE\b/g, 'ObEMasterLayoutEventValues.NAVIGATION_SCROLL_MODE');
                if (fileContent !== replacement) {
                    tree.overwrite(filePath, replacement);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    migrateConfigEvents() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replacing configEvents');
            const toApply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                const replacement = fileContent.replace(/\.configEvents(?!\$)/g, '.configEvents$');
                if (fileContent !== replacement) {
                    tree.overwrite(filePath, replacement);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    migrateMasterLayoutConfig(fileContent) {
        const service = /(?<service>\w+)\s*:\s*ObMasterLayoutConfig/.exec(fileContent)?.groups?.service;
        return service
            ? fileContent
                .replace(new RegExp(`^\\s*${service}\\.header\\.isAnimated\\s*=\\s*\\w*\\s*;$`, 'm'), '')
                .replace(new RegExp(`^\\s*${service}\\.footer\\.isSmall\\s*=\\s*\\w*\\s*;$`, 'm'), '')
                .replace(new RegExp(`^(\\s*${service})\\.layout\\.isFixed\\s*=\\s*(\\w*)\\s*;$`, 'm'), `$1.header.isSticky = $2;\n$1.footer.isSticky = $2;`)
                .replace(new RegExp(`^(\\s*${service}\\.footer)\\.hasScrollTransitions\\s*=\\s*(\\w*)\\s*;$`, 'm'), '$1.hasLogoOnScroll = $2;')
                .replace(new RegExp(`^(\\s*${service}\\.header)\\.hasScrollTransitions\\s*=\\s*(\\w*)\\s*;$`, 'm'), '$1.reduceOnScroll = $2;')
                .replace(new RegExp(`^(\\s*${service}\\.header)\\.isMedium\\s*=\\s*(\\w*)\\s*;$`, 'm'), '$1.isSmall = $2;')
            : fileContent;
    }
    migrateMasterLayoutIsFixed(fileContent) {
        const service = /(?<service>\w+)\s*:\s*ObMasterLayoutService/.exec(fileContent)?.groups?.service;
        return service
            ? this.migrateObMasterLayoutServiceIsFixed(fileContent, service)
            : this.migrateObMasterLayoutComponentServiceIsFixed(fileContent);
    }
    migrateObMasterLayoutServiceIsFixed(fileContent, service) {
        return fileContent.replace(new RegExp(`^(\\s*(?:this\\.)?${service})\\.layout\\.isFixed\\s+=\\s+(\\w*);$`, 'm'), `$1.header.isSticky = $2;\n$1.footer.isSticky = $2;`);
    }
    migrateObMasterLayoutComponentServiceIsFixed(fileContent) {
        const service = /(?<service>\w+)\s*:\s*ObMasterLayoutComponentService/.exec(fileContent)?.groups?.service;
        if (service) {
            let masterLayoutService = /(?<service>\w+)\s*:\s*ObMasterLayoutService/.exec(fileContent)?.groups?.service;
            if (!masterLayoutService) {
                fileContent = fileContent
                    .replace(/(constructor\s*\()(\s*)/, '$1$2private readonly masterLayout: ObMasterLayoutService,$2')
                    .replace(/import\s*{(.*)}\s*from\s*['"]@oblique\/oblique['"]/, `import {$1, ObMasterLayoutService} from '@oblique/oblique'`);
                masterLayoutService = 'masterLayout';
            }
            return fileContent.replace(new RegExp(`^(\\s*this\\.)?${service}\\.isFixed\\s*=\\s*(\\w*)\\s*;$`, 'm'), `$1${masterLayoutService}.header.isSticky = $2;\n$1${masterLayoutService}.footer.isSticky = $2;`);
        }
        return fileContent;
    }
    migrateProperty(fileContent, service, name, newName) {
        const serviceName = (0, ng_update_utils_1.getServiceName)(fileContent, service);
        return serviceName ? fileContent.replace(new RegExp(`(?<=${serviceName}\\.)${name}`, 'gm'), newName) : fileContent;
    }
    updateBrowserCompatibilityMessage() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Oblique: Updating browser compatibility check message');
            (0, utils_1.getIndexPaths)(tree).forEach((indexPath) => (0, utils_1.overwriteIndexFile)(indexPath, tree, new RegExp(/(<noscript style="display: table; height: 98vh; width: 98vw">)((.|\r?\n)*)(<\/div>)/gm)));
            return tree;
        });
    }
    migrateEditorConfig() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: update or integrate "editorconfig" to Oblique standards"');
            (0, utils_1.writeFile)(tree, '.editorconfig', (0, ng_add_utils_1.getTemplate)(tree, 'default-editorconfig.config'));
            return tree;
        });
    }
    migrateLinting() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: update or integrate linting to Oblique standards');
            const prefix = /\s*"@angular-eslint\/(?:component|directive)-selector"\s*:\s*\[.*?"prefix"\s*:\s*"(?<prefix>.*?)"/s.exec((0, utils_1.readFile)(tree, '.eslintrc.json'))?.groups?.prefix || '';
            return (0, schematics_1.chain)([
                this.removeCurrentLinter(),
                this.addEslint(),
                this.addEslintConfiguration(),
                this.addPrettier(),
                this.overwriteEslintRC(prefix),
            ]);
        });
    }
    removeCurrentLinter() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: remove the current linting solution if any');
            (0, ng_add_utils_1.removeDevDependencies)(tree, 'lint');
            (0, ng_add_utils_1.removeScript)(tree, 'prettier');
            (0, ng_add_utils_1.removeScript)(tree, 'lint');
            (0, ng_add_utils_1.removeScript)(tree, 'lint:fix');
            (0, ng_add_utils_1.removeScript)(tree, 'format');
            (0, utils_1.deleteFile)(tree, '.eslintrc.json');
            (0, utils_1.deleteFile)(tree, '.prettierrc');
            (0, utils_1.removeAngularProjectsConfig)(tree, ['architect', 'lint']);
            // remove eventual leftover
            (0, ng_add_utils_1.removeDevDependencies)(tree, 'codelyzer');
            tree.delete('tslint.json');
            return tree;
        });
    }
    addEslint() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: add "eslint"');
            return (0, schematics_1.externalSchematic)('@angular-eslint/schematics', 'ng-add', {});
        });
    }
    addEslintConfiguration() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            // this step is only necessary because "ng add @angular-eslint" won't do it if there are more than one projects
            // and prior to Angular 13, an e2e projects was always created.
            (0, utils_1.infoMigration)(context, 'Toolchain: add "@angular-eslint" configuration');
            (0, utils_1.getAngularConfigs)(tree, []).forEach(project => {
                const rootPath = project.config.root || project.config.sourceRoot;
                (0, utils_1.setAngularConfig)(tree, ['architect', 'lint'], {
                    project: project.project,
                    config: {
                        builder: '@angular-eslint/builder:lint',
                        options: {
                            lintFilePatterns: [`${rootPath}/**/*.ts`, `${rootPath}/**/*.html`],
                        },
                    },
                });
            });
            return tree;
        });
    }
    addPrettier() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: add "prettier"');
            ['prettier', 'eslint-config-prettier', 'eslint-plugin-prettier'].forEach(dependency => (0, ng_add_utils_1.addDevDependency)(tree, dependency));
            (0, ng_add_utils_1.addScript)(tree, 'format', 'npm run lint -- --fix');
            (0, utils_1.writeFile)(tree, '.prettierrc', (0, ng_add_utils_1.getTemplate)(tree, 'default-prettierrc.config'));
            return tree;
        });
    }
    overwriteEslintRC(prefix) {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Toolchain: overwrite ".eslintrc.json"');
            (0, utils_1.writeFile)(tree, '.eslintrc.json', this.formatEsLintRC(tree, prefix));
            return tree;
        });
    }
    formatEsLintRC(tree, prefix) {
        const eslintFile = (0, ng_add_utils_1.getTemplate)(tree, 'default-eslintrc.json.config');
        return prefix
            ? eslintFile.replace(/APP_PREFIX/g, prefix)
            : eslintFile.replace(/\s*"@angular-eslint\/(?:component|directive)-selector": \[.*?],/gs, '');
    }
}
exports.UpdateV7toV8 = UpdateV7toV8;
