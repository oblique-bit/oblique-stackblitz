/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV10toV11 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
class UpdateV10toV11 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            (0, utils_1.checkForStandalone)(),
            (0, utils_1.checkForSSR)(),
            this.replaceObPopUpWithWindowInTests(),
            this.replaceObPopUpWithWindow(),
            this.removeInputVariantInNavTree(),
            this.removeInputActivateAncestorsInNavTree(),
            this.removeObSearchBox(),
            this.removeFakeFocus(),
            this.replaceScssWithCssStylesInAngularJson(),
            this.replaceNgContainerToken('obHeaderCustomControl'),
            this.replaceNgContainerToken('obLocales'),
            this.wrapOneLinerContentProjectionWithNgTemplate('obHeaderCustomControl'),
            this.wrapOneLinerContentProjectionWithNgTemplate('obLocales'),
            this.wrapMultiLinerContentProjectionWithNgTemplate('obHeaderCustomControl'),
            this.wrapMultiLinerContentProjectionWithNgTemplate('obLocales'),
            this.removeContentProjectionMarker('obHeaderCustomControl'),
            this.removeContentProjectionMarker('obLocales'),
            this.removeActivateServiceNavigationToken(),
            this.removeTableCicd(),
            this.runMDCMigration(),
            this.removeTransformMock(),
            this.deactivatePreferStandalone(),
            this.removeGlobalsFromJestConfig(),
            this.addNodeToCompilerOptions(),
            this.addDataNoSnippet(),
            this.addBrowserslistrcFile(),
        ])(tree, context);
    }
    replaceObPopUpWithWindowInTests() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replace ObPopUpService with Window');
            const apply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('ObPopUpService')) {
                    (0, utils_1.addImport)(tree, filePath, 'WINDOW', '@oblique/oblique');
                    (0, utils_1.removeImport)(tree, filePath, 'ObPopUpService', '@oblique/oblique');
                    (0, utils_1.removeImport)(tree, filePath, 'ObMockPopUpService', '@oblique/oblique');
                    (0, utils_1.replaceInFile)(tree, filePath, /\{\s*provide\s*:\s*ObPopUpService\s*,\s*useClass\s*:\s*Ob(?:Mock)?PopUpService\s*},?/g, '{provide: WINDOW, useValue: window},');
                    const propertyName = /(?<propertyName>\w+)\s*(?::\s*ObPopUpService)?\s*=\s*TestBed\s*\.\s*inject\(\s*ObPopUpService\s*\)\s*;/.exec(content)?.groups?.propertyName;
                    if (propertyName) {
                        (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`let\\s+${propertyName}\\s*(?::\\s*ObPopUpService\\s*)?;`, 'g'), '');
                        (0, utils_1.replaceInFile)(tree, filePath, new RegExp(propertyName, 'g'), 'window');
                        (0, utils_1.replaceInFile)(tree, filePath, /[^;]*TestBed\s*.\s*inject\(\s*ObPopUpService\s*\)\s*;/gs, '');
                    }
                }
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.test);
        });
    }
    replaceObPopUpWithWindow() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replace ObPopUpService with Window');
            const apply = (filePath) => {
                const varName = /(?<varname>\w+)\s*:\s*ObPopUpService/.exec((0, utils_1.readFile)(tree, filePath))?.groups?.varname;
                if (varName) {
                    (0, utils_1.addInjectionInClass)(tree, filePath, 'WINDOW', '@oblique/oblique');
                    (0, utils_1.removeInjectionInClass)(tree, filePath, 'ObPopUpService', '@oblique/oblique');
                    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(varName, 'g'), 'window');
                    (0, utils_1.replaceInFile)(tree, filePath, 'wINDOW', 'window');
                }
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeInputVariantInNavTree() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove the @Input "variant" in the nav-tree component');
            const apply = (filePath) => {
                (0, utils_1.removeHtmlTagAttribute)(tree, filePath, 'ob-nav-tree', 'variant');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    removeInputActivateAncestorsInNavTree() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove the @Input "activateAncestors" in the nav-tree component');
            const apply = (filePath) => {
                (0, utils_1.removeHtmlTagAttribute)(tree, filePath, 'ob-nav-tree', 'activateAncestors');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    removeObSearchBox() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove search box feature');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObSearchBoxModule', '@oblique/oblique');
                (0, utils_1.removeImport)(tree, filePath, 'ObSearchBoxComponent', '@oblique/oblique');
                (0, utils_1.removeImport)(tree, filePath, 'ObISearchWidgetItem', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /ObSearchBoxModule\s*,?\s*/, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeFakeFocus() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove fake focus');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObNavTreeFakeFocusDirective', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /\[?obNavTreeFakeFocus]?\s*=\s*["'].*?["']\s*/g, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    replaceScssWithCssStylesInAngularJson() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replace scss with css styles in angular.json');
            return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => {
                const styles = ['oblique-core', 'oblique-alert', 'oblique-icons'];
                styles.forEach(style => {
                    const index = config.indexOf(`node_modules/@oblique/oblique/styles/scss/${style}.scss`);
                    if (index !== -1) {
                        config[index] = `node_modules/@oblique/oblique/styles/css/${style}.css`;
                    }
                });
                return config;
            });
        });
    }
    replaceNgContainerToken(token) {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Replace ${token} with #obHeaderControl`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`<ng-container[^>]*?${token}.*?>(?<content>.*?)<\\/ng-container>`, 'gs'), '<ng-template #obHeaderControl>$<content></ng-template>');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    wrapOneLinerContentProjectionWithNgTemplate(token) {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Wrap one liner ${token} with #obHeaderControl`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`(?<content><(?<tag>[\\w-]+).*?${token}.*?>.*?<\\/\\k<tag>>)`, 'g'), '<ng-template #obHeaderControl>$<content></ng-template>');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    wrapMultiLinerContentProjectionWithNgTemplate(token) {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Wrap ${token} with #obHeaderControl`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`(?<content>(?<whitespace>[\t ]*)<(?<tag>[\\w-]+)[^<]*?${token}.*?>.*?^\\k<whitespace><\\/\\k<tag>>)`, 'gsm'), '<ng-template #obHeaderControl>\n$<content>\n</ng-template>');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    removeContentProjectionMarker(token) {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Remove ${token} content projection marker`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\s*${token}`, 'g'), '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    removeActivateServiceNavigationToken() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Remove OB_ACTIVATE_SERVICE_NAVIGATION token`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /{\s*provide\s*:\s*OB_ACTIVATE_SERVICE_NAVIGATION\s*,\s*useValue\s*:\s*(?:true|false)\s*}\s*,?\s*/, '');
                (0, utils_1.replaceInFile)(tree, filePath, /OB_ACTIVATE_SERVICE_NAVIGATION\s*,?\s*/, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeTableCicd() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Remove ob-table-cicd class`);
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /\[class\.ob-table-cicd]=["']\w+["']/g, ''); // [class.ob-table-cicd]="true"
                (0, utils_1.replaceInFile)(tree, filePath, /['"]ob-table-cicd["']\s*:[^},]*,?/g, ''); // [ngClass]="{'ob-table-cicd': true}"
                (0, utils_1.replaceInFile)(tree, filePath, /ob-table-cicd/g, ''); // class="ob-table-cicd"
                (0, utils_1.replaceInFile)(tree, filePath, /class\s*=\s*["']\s*["']/g, ''); // class=""
                (0, utils_1.replaceInFile)(tree, filePath, /\[ngClass]\s*=\s*['"]\{\s*}\s*["']/g, ''); // [ngClass]="{}"
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
    runMDCMigration() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Check the @angular/material version before running the mdc-migration.`);
            const angularMaterialVersion = (0, ng_add_utils_1.getDepVersion)(tree, '@angular/material') || '';
            if (angularMaterialVersion.startsWith('17')) {
                (0, utils_1.infoMigration)(context, `Runs the mdc-migration.`);
                return (0, schematics_1.externalSchematic)('@angular/material', 'mdc-migration', {
                    components: ['all'],
                });
            }
            (0, utils_1.warn)(context, `No compatible @angular/material version found to run the mdc-migration. @angular/material@17 is needed.`);
            return tree;
        });
    }
    removeTransformMock() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Remove transform mock in jest configuration`);
            const path = 'tests/jestGlobalMocks.ts';
            tree.overwrite(path, (0, utils_1.readFile)(tree, path).replace(/Object\.defineProperty\s*\(\s*document\.body\.style\s*,\s*['"]transform['"].*?}\s*\)\s*;\s+/gs, ''));
            // can't use applyInTree as the target file is outside sourceRoot
            return tree;
        });
    }
    deactivatePreferStandalone() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Deactivate "@angular-eslint/prefer-standalone-component" rule`);
            const path = '.eslintrc.json';
            const eslintConfiguration = JSON.parse((0, utils_1.readFile)(tree, path));
            // can't use filter or conditional chaining as we need to modify a value
            if (eslintConfiguration.overrides) {
                eslintConfiguration.overrides.forEach(configuration => {
                    if (configuration.files?.[0] === utils_1.filePatterns.ts) {
                        if (!configuration.rules) {
                            configuration.rules = {};
                        }
                        configuration.rules['@angular-eslint/prefer-standalone-component'] = 'off';
                    }
                });
            }
            tree.overwrite(path, JSON.stringify(eslintConfiguration, null, 2));
            // can't use applyInTree as the target file is outside sourceRoot
            return tree;
        });
    }
    removeGlobalsFromJestConfig() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Remove "globals" configuration from jest configuration`);
            const path = 'tests/jest.config.js';
            tree.overwrite(path, (0, utils_1.readFile)(tree, path).replace(/\s*globals.*?}(?:,|(?=\s*};))/s, ''));
            // can't use applyInTree as the target file is outside sourceRoot
            return tree;
        });
    }
    addNodeToCompilerOptions() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Add "node" to compiler options for tests`);
            (0, utils_1.getAngularConfigs)(tree, ['architect', 'test', 'options', 'tsConfig'])
                .map(({ config }) => config)
                .filter(path => tree.exists(path))
                .map(path => ({ path, content: JSON.parse((0, utils_1.readFile)(tree, path)) }))
                .filter(({ content }) => content?.compilerOptions?.types && !content.compilerOptions.types.includes('node'))
                .forEach(({ path, content }) => {
                content.compilerOptions.types.push('node');
                tree.overwrite(path, JSON.stringify(content, null, 2));
            });
            // can't use applyInTree as the target file is outside sourceRoot
            return tree;
        });
    }
    addDataNoSnippet() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, `Add data-nosnippet to browser compatibility warning in the index.html`);
            (0, utils_1.getIndexPaths)(tree).forEach((indexPath) => (0, utils_1.overwriteIndexFile)(indexPath, tree, 'class="ob-compatibility"', 'class="ob-compatibility" data-nosnippet'));
            return tree;
        });
    }
    addBrowserslistrcFile() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Add the .browserslistrc file if not already present');
            const browserlistrcFile = (0, ng_add_utils_1.getTemplate)(tree, 'default-browserslistrc.config');
            (0, utils_1.addFile)(tree, '.browserslistrc', browserlistrcFile);
            return tree;
        });
    }
}
exports.UpdateV10toV11 = UpdateV10toV11;
