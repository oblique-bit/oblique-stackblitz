/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV4toV5 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
class UpdateV4toV5 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => {
            (0, utils_1.warn)(context, 'The update schematics from version 4 to 5 have been removed. Please update to version 5 first');
            return (0, schematics_1.chain)([])(tree, context);
        };
    }
}
exports.UpdateV4toV5 = UpdateV4toV5;
