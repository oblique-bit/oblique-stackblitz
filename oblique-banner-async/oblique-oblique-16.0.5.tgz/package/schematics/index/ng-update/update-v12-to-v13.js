/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV12toV13 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
class UpdateV12toV13 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            this.removeObFormField(),
            this.removeObPaginatorDirective(),
            this.migrateMasterLayoutProperties(),
            this.removeObCheckbox(),
            this.migrateTableRowCheckedClass(),
            this.addObliqueProviders(),
            this.migrateCustomConfig(),
            this.removeObMaterialConfig(),
            this.removeIconModule(),
            this.removeMultiTranslateLoader(),
            this.removeTranslationFiles(),
            this.removeOldFontReferences(),
            this.removeOBShowExternalLinkIconClass(),
            (0, utils_1.warnIfStandalone)(),
        ])(tree, context);
    }
    removeObFormField() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove form field feature');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObSelectDirective', '@oblique/oblique');
                (0, utils_1.removeImport)(tree, filePath, 'ObFormFieldDirective', '@oblique/oblique');
                (0, utils_1.removeImport)(tree, filePath, 'ObFormFieldModule', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /(?:ObFormFieldModule|ObFormFieldDirective|ObSelectDirective)\s*,?\s*/g, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeObPaginatorDirective() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObPaginatorDirective');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObPaginatorDirective', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /ObPaginatorDirective\s*,?\s*/g, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    migrateMasterLayoutProperties() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove deprecated MasterLayoutService configs.');
            const toApply = (filePath) => {
                const fileContent = (0, utils_1.readFile)(tree, filePath);
                const replacement = fileContent
                    .replace(/^.*footer\.hasLogoOnScroll.*$/gm, '')
                    .replace(/^.*header\.reduceOnScroll.*$/gm, '');
                if (fileContent !== replacement) {
                    tree.overwrite(filePath, replacement);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeObCheckbox() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove checkbox feature');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObCheckboxModule', '@oblique/oblique');
                (0, utils_1.removeImport)(tree, filePath, 'ObCheckboxDirective', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /(?:ObCheckboxModule|ObCheckboxDirective)\s*,?\s*/g, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    migrateTableRowCheckedClass() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate ob-table-row-checked class');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=tr|&)\.ob-table-row-checked/g, ':has([checked])');
                (0, utils_1.replaceInFile)(tree, filePath, /\.ob-table-row-checked/g, 'tr:has([checked])');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scssAndCss);
        });
    }
    addObliqueProviders() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Add Oblique providers');
            const apply = (filePath) => {
                (0, utils_1.addImport)(tree, filePath, 'provideObliqueConfiguration', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=providers\s*:\s*)\[/, '[provideObliqueConfiguration(),\n');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    migrateCustomConfig() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate OB_MATERIAL_CONFIG, ObIconModule.forRoot and multiTranslateLoader');
            const apply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                const configs = [
                    `accessibilityStatement: {applicationName: "Replace me with the application's name", conformity: 'none', applicationOperator: 'Replace me with the name and address of the federal office that exploit this application, HTML is permitted', contact: {/* at least 1 email or phone number has to be provided */ emails: [''], phones: ['']}}`,
                    this.getMaterialConfiguration(content),
                    this.getIconConfiguration(content),
                    this.getTranslateConfiguration(content),
                ].join(',');
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=provideObliqueConfiguration\()(?=\))/, `{${configs}}`);
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    getMaterialConfiguration(content) {
        const materialConfiguration = [
            'MAT_FORM_FIELD_DEFAULToptions',
            'STEPPER_GLOBALoptions',
            'MAT_CHECKBOXoptions',
            'MAT_RADIOoptions',
            'MAT_SLIDE_TOGGLEoptions',
            'MAT_TABS_CONFIG',
        ]
            .map(token => ({ token, result: new RegExp(`(?<=${token}:\\s*){[^}]*}`).exec(content) }))
            .filter(({ result }) => !!result)
            .map(({ token, result }) => `${token}: ${result?.[0]}`)
            .join(',');
        return materialConfiguration.length ? `material: {${materialConfiguration}}` : '';
    }
    getIconConfiguration(content) {
        const iconConfig = /(?<=ObIconModule\.forRoot\s*\(\s*).*?(?=\))/s.exec(content) ?? [];
        return iconConfig[0]?.length ? `icon: ${iconConfig[0]}` : '';
    }
    getTranslateConfiguration(content) {
        const translateConfig = /(?<=TranslateModule\.forRoot\s*\(\s*multiTranslateLoader\().*?(?=\)+)/s.exec(content) ?? [];
        const translateFiles = /(?<={\s*provide\s*:\s*TRANSLATION_FILES\s*,\s*useValue\s*:\s*).*?(?=})/s.exec(content) ?? [];
        const config = [];
        if (translateConfig[0]?.length) {
            config.push(`config: ${translateConfig[0]}`);
        }
        if (translateFiles[0]?.length) {
            config.push(`additionalFiles: ${translateFiles[0]}`);
        }
        return config.length ? `translate: {${config.join(',')}}` : '';
    }
    removeObMaterialConfig() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove OB_MATERIAL_CONFIG');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'OB_MATERIAL_CONFIG', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /\s*{\s*provide\s*:\s*OB_MATERIAL_CONFIG\s*,\s*useValue\s*:\s*\{.*?}\s*}\s*}.?/s, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    removeIconModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObIconModule.forRoot');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'ObIconModule', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /ObIconModule\.forRoot\s*\(.*?\),?\s*/s, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    removeMultiTranslateLoader() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove multiTranslateLoader');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'multiTranslateLoader', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=TranslateModule)\.forRoot\s*\(.*?\)+/s, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    removeTranslationFiles() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove TRANSLATION_FILES');
            const apply = (filePath) => {
                (0, utils_1.removeImport)(tree, filePath, 'TRANSLATION_FILES', '@oblique/oblique');
                (0, utils_1.replaceInFile)(tree, filePath, /\s*{\s*provide\s*:\s*TRANSLATION_FILES\s*,\s*useValue\s*:.*},?/s, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.appModule);
        });
    }
    removeOldFontReferences() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove Roboto and Frutiger fonts references');
            (0, utils_1.getAngularConfigs)(tree, ['architect', 'build', 'options', 'styles']).forEach(project => {
                (0, utils_1.setAngularConfig)(tree, ['architect', 'build', 'options', 'styles'], {
                    project: project.project,
                    config: project.config.filter((style) => !(style.endsWith('roboto.css') || style.endsWith('frutiger.css'))),
                });
            });
            return tree;
        });
    }
    removeOBShowExternalLinkIconClass() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove "ob-show-external-link-icon" class');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /ob-show-external-link-icon/g, '');
                (0, utils_1.replaceInFile)(tree, filePath, /class="" ?/g, '');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        });
    }
}
exports.UpdateV12toV13 = UpdateV12toV13;
