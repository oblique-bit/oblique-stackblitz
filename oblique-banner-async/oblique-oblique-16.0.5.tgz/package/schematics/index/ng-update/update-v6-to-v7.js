/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV6toV7 = void 0;
/* eslint-disable prefer-named-capture-group */
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
const ng_update_utils_1 = require("./ng-update-utils");
class UpdateV6toV7 {
    dependencies = {
        ajv: 8,
        'ajv-formats': 2,
    };
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Analyzing project');
            return (0, schematics_1.chain)([
                this.adaptPolyfills(),
                this.renameObIconsConfig(),
                this.renameSpacingLg(),
                this.renameTableTitleAttribute(),
                this.removeDirection(),
                this.migrateAlerts(),
                this.migrateNavigationPathMatch(),
            ])(tree, context);
        };
    }
    adaptPolyfills() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Removing IE 11 polyfills');
            (0, ng_update_utils_1.removePolyFill)(tree, 'web-animations-js', /^\s*import\s+['"]web-animations-js['"];.*/gm);
            (0, ng_update_utils_1.removePolyFill)(tree, 'classlist.js', /^\s*import\s+['"]classlist.js['"];.*/gm);
        };
    }
    renameObIconsConfig() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming ObIconsConfig into ObIconConfig');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /ObIconsConfig/g, 'ObIconConfig');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        };
    }
    renameSpacingLg() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming $spacing-lg into $spacing-xl');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /\$spacing-lg/g, '$spacing-xl');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.scss);
        };
    }
    renameTableTitleAttribute() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming title attribute into data-title for tables');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=<table[^>]*?class=".*?ob-table-collapse.*?".*?<td[^>]*?)(?<!data-)title="/gs, 'data-title="');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.html);
        };
    }
    removeDirection() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Removing direction input on collapse');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(<ob-collapse\s.*?)\[?direction]?=".*?"\s?(.*?>)/g, '$1$2');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.html);
        };
    }
    migrateAlerts() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Use ob-alert instead of alert classes');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /<div class="ob-alert ob-alert-(?<type>[a-z]+)"(?: role="alert")?>(?<content>.*?)<\/div>/gs, '<ob-alert type="$1">$2</ob-alert>');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.html);
        };
    }
    migrateNavigationPathMatch() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate pathMatch to routerLinkActiveOptions');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(?:(?<={.*(url|label).*)|(?=.*(url|label).*}))pathMatch\s*:\s*['"]full['"]/g, "routerLinkActiveOptions: {paths: 'exact', queryParams: 'exact', fragment: 'ignored', matrixParams: 'ignored'}");
                (0, utils_1.replaceInFile)(tree, filePath, /(?:(?<={.*(url|label).*)|(?=.*(url|label).*}))pathMatch\s*:\s*['"]prefix['"]/g, "routerLinkActiveOptions: {paths: 'subset', queryParams: 'subset', fragment: 'ignored', matrixParams: 'ignored'}");
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        };
    }
}
exports.UpdateV6toV7 = UpdateV6toV7;
