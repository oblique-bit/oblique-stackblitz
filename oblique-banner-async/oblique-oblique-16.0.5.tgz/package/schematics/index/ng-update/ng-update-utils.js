/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkDependencies = checkDependencies;
exports.minAngularVersion = minAngularVersion;
exports.addClassesPrefix = addClassesPrefix;
exports.addClassPrefix = addClassPrefix;
exports.addPrefixMatchExactOrSuffix = addPrefixMatchExactOrSuffix;
exports.addPrefixMatchSuffix = addPrefixMatchSuffix;
exports.addPrefixMatchExact = addPrefixMatchExact;
exports.renameExactOrSuffix = renameExactOrSuffix;
exports.removePolyFill = removePolyFill;
exports.removeProperty = removeProperty;
exports.getServiceName = getServiceName;
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
const utils_1 = require("../utils");
function checkDependencies(tree, context, deps) {
    const angular = getDepVersion(tree, '@angular/core');
    const warnings = Object.keys(deps)
        .reduce((warns, dep) => [...warns, checkDependency(tree, context, dep, getVersions(deps[dep], angular))], [])
        .filter(warning => !!warning)
        .map(warning => `\n    • ${warning}`)
        .join('');
    if (warnings.length) {
        (0, utils_1.warn)(context, `Unmet peer dependencies.\n  Following peers are required by Oblique but were not found:${warnings}.\n  You must install peer dependencies yourself.`);
    }
}
function minAngularVersion(tree, context, oblique, angular) {
    if (getDepVersion(tree, '@angular/core') < angular) {
        (0, utils_1.warn)(context, `Oblique ${oblique} is designed to work with Angular ${angular}. If the update fails, try to update angular first.`);
    }
}
function addClassesPrefix(tree, filePath, target, suffixes) {
    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`class="((?:[\\w-]*\\s)*|)(${target})(\\s.*|)"`, 'g'), `class="$1ob-$2$3"`);
    if (suffixes) {
        addClassPrefix(tree, filePath, target, suffixes);
    }
}
function addClassPrefix(tree, filePath, target, suffixes) {
    suffixes.forEach(suffix => {
        (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`class="((?:[\\w-]*\\s)*|)(${target}-${suffix})(\\s.*|)"`, 'g'), `class="$1ob-$2$3"`);
    });
}
function addPrefixMatchExactOrSuffix(tree, filePath, target, suffix) {
    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\.(${target}(?:[:\\.\\s{]|(?:-(?:${suffix.join('|')}))))`, 'g'), '.ob-$1');
}
function addPrefixMatchSuffix(tree, filePath, target, suffix) {
    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\.(${target}-(?:${suffix.join('|')})[:\\.\\s{])`, 'g'), '.ob-$1');
}
function addPrefixMatchExact(tree, filePath, targets) {
    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\.(${targets.join('|')}[:\\.\\s{])`, 'g'), '.ob-$1');
}
function renameExactOrSuffix(tree, filePath, target, suffix, result) {
    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`\\.${target}([:\\.\\s{]|(?:-(?:${suffix.join('|')})))`, 'g'), `.${result}$1`);
}
function checkDependency(tree, context, dependency, versions) {
    const currentVersion = getDepVersion(tree, dependency);
    return versions.includes(currentVersion)
        ? ''
        : `"${dependency}" at version ${versions
            .filter(version => version > 0)
            .reduce((supportedVersions, version) => [...supportedVersions, version], [])
            .join(' or ')}`;
}
function getVersions(versions, angular) {
    if (versions instanceof Function) {
        versions = versions(angular);
    }
    if (!Array.isArray(versions)) {
        versions = [versions];
    }
    return versions;
}
function getDepVersion(tree, dep) {
    const pattern = new RegExp(`"${dep}":\\s*"[~,^]?(?<version>\\d+)\\.\\d+\\.\\d+"`);
    const version = (0, utils_1.readFile)(tree, utils_1.packageJsonConfigPath).match(pattern)?.groups?.version;
    return version ? parseInt(version, 10) : 0;
}
function removePolyFill(tree, polyfillName, importPattern) {
    const polyfills = (0, utils_1.getAngularConfigs)(tree, ['architect', 'build', 'options', 'polyfills'])
        .map(polyfill => ({ name: polyfill.config, file: (0, ng_add_utils_1.createSrcFile)(tree, polyfill.config).getText() }))
        .filter(polyfill => importPattern.test(polyfill.file));
    if (polyfills.length) {
        polyfills.forEach(polyfill => {
            tree.overwrite(polyfill.name, polyfill.file.replace(importPattern, ''));
        });
        (0, dependencies_1.removePackageJsonDependency)(tree, polyfillName);
    }
}
function removeProperty(fileContent, service, name) {
    const serviceName = getServiceName(fileContent, service);
    return serviceName
        ? fileContent.replace(new RegExp(`^\\s*(?:return\\s*)?(?:this\\.)?${serviceName}\\.${name}(?:\\s*=\\s*(\\w*))?;$`, 'gm'), '')
        : fileContent;
}
function getServiceName(fileContent, serviceName) {
    const serviceClass = serviceName.charAt(0).toUpperCase() + serviceName.slice(1);
    let service = new RegExp(`(?<service>\\w+)\\s*:\\s*ObMasterLayout${serviceClass}Service`).exec(fileContent)?.groups
        ?.service;
    if (!service) {
        service = /(?<service>\w+)\s*:\s*ObMasterLayoutService/.exec(fileContent)?.groups?.service;
        service = service ? `${service}.${serviceName}` : undefined;
    }
    return service;
}
