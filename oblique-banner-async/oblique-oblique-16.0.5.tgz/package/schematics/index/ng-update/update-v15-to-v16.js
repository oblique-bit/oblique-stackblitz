/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV15toV16 = void 0;
exports.removeObIconModuleReferences = removeObIconModuleReferences;
exports.removeMasterLayoutConfigLocaleReferences = removeMasterLayoutConfigLocaleReferences;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
const obliquePackage = '@oblique/oblique';
const schemaValidationPackage = '@oblique/oblique/schema-validation';
const schemaValidationImports = [
    'draft07Convert',
    'ObMockSchemaRequiredDirective',
    'ObMockSchemaValidateDirective',
    'ObMockSchemaValidationDirective',
    'ObMockSchemaValidationModule',
    'ObMockSchemaValidationService',
    'ObSchemaRequiredDirective',
    'ObSchemaValidateDirective',
    'ObSchemaValidationDirective',
    'ObSchemaValidationModule',
    'ObSchemaValidationService',
    'ObSchemaValidatorInstance',
];
function removeObIconModuleReferences(content) {
    const obIconModuleReference = String.raw `ObIconModule(?:\.forRoot\([^)]*\))?`;
    return content
        .replace(new RegExp(String.raw `importProvidersFrom\(\s*${obIconModuleReference}\s*\),?\s*`, 'gmu'), '')
        .replace(new RegExp(String.raw `\[\s*${obIconModuleReference}\s*,?\s*`, 'gmu'), '[')
        .replace(new RegExp(String.raw `,\s*${obIconModuleReference}(?=\s*[,}\]])`, 'gmu'), '')
        .replace(new RegExp(String.raw `,\s*${obIconModuleReference}\s*,?`, 'gmu'), ',');
}
function removeMasterLayoutConfigLocaleReferences(content) {
    const configReference = String.raw `[\w$]+(?:\.[\w$]+)*`;
    const localeProperty = String.raw `(?:\.[\w$]+|\[['"\x60][^'"\x60]+['"\x60]\])`;
    const assignmentSuffix = String.raw `(?:[^\S\r\n]+(?:as|satisfies)[^\r\n;]+)?;?`;
    return content
        .replace(new RegExp(String.raw `^\s*${configReference}\.locale\s*=\s*\{[^\n]*\}${assignmentSuffix}[^\S\r\n]*(?:\r?\n)?`, 'gmu'), '')
        .replace(new RegExp(String.raw `^\s*${configReference}\.locale\s*=\s*\{[\s\S]*?^\s*\}${assignmentSuffix}[^\S\r\n]*(?:\r?\n)?`, 'gmu'), '')
        .replace(new RegExp(String.raw `^\s*${configReference}\.locale${localeProperty}+\s*=\s*[^;\n]+;?[^\S\r\n]*(?:\r?\n)?`, 'gmu'), '')
        .replace(/^\s*locale\s*:\s*\{[\s\S]*?^\s*\},?\s*/gmu, '')
        .replace(/^\s*locale\s*:\s*\{[^{}\n]*\},?\s*$/gmu, '')
        .replace(/^\s*locale\s*:\s*[^,\n]+,?\s*$/gmu, '');
}
class UpdateV15toV16 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            (0, utils_1.warnIfStandalone)(),
            this.renameFocusElement(),
            this.removeObIconModule(),
            this.removeMasterLayoutConfigLocales(),
            this.removeLocalesConfigurationLanguages(),
            this.updateObliqueLanguageConfiguration(),
            this.moveSchemaValidationImports(),
            this.warnAboutSchemaValidationOnObliqueModule(),
            this.warnAboutSchemaValidationOnObliqueTestingModule(),
            this.addXhrToHttpClientProvider(),
        ])(tree, context);
    }
    renameFocusElement() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename focusElement() to focusElementById()');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=masterLayout(?:\(\))?\??\.)focusElement/gmu, 'focusElementById');
            };
            return (0, utils_1.applyInTree)(tree, toApply, '*.ts');
        });
    }
    removeObIconModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObIconModule');
            const toApply = (filePath) => {
                if (!(0, utils_1.readFile)(tree, filePath).includes('ObIconModule')) {
                    return;
                }
                (0, utils_1.removeImport)(tree, filePath, 'ObIconModule', '@oblique/oblique');
                tree.overwrite(filePath, removeObIconModuleReferences((0, utils_1.readFile)(tree, filePath)));
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeMasterLayoutConfigLocales() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObMasterLayoutConfig.locale');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (!content.includes('ObMasterLayoutConfig')) {
                    return;
                }
                tree.overwrite(filePath, removeMasterLayoutConfigLocaleReferences(content));
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeLocalesConfigurationLanguages() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove languages from the locales configuration');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (!content.includes('languages')) {
                    return;
                }
                tree.overwrite(filePath, content.replace(/languages\s*:\s*{[^}]+},?/, ''));
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.appModule);
        });
    }
    updateObliqueLanguageConfiguration() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Move hasLanguageInUrl into the language configuration');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (!content.includes('hasLanguageInUrl')) {
                    return;
                }
                tree.overwrite(filePath, content.replace(/hasLanguageInUrl\s*:\s*(?<value>[^,\n}]+)/, 'language: {hasLanguageInUrl: $<value>}'));
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.appModule);
        });
    }
    moveSchemaValidationImports() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Move schema validation imports to the secondary entry point');
            const toApply = (filePath) => {
                const fileContent = tree.readText(filePath);
                const updatedContent = this.rewriteSchemaValidationImports(fileContent);
                if (updatedContent !== fileContent) {
                    tree.overwrite(filePath, updatedContent);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    rewriteSchemaValidationImports(fileContent) {
        const tree = schematics_1.Tree.empty();
        const filePath = '/test.ts';
        tree.create(filePath, fileContent);
        this.moveSchemaValidationImportsInFile(tree, filePath);
        return tree.readText(filePath);
    }
    moveSchemaValidationImportsInFile(tree, filePath) {
        schemaValidationImports.forEach(importName => {
            (0, utils_1.removeImport)(tree, filePath, importName, obliquePackage).forEach(removedSpecifier => (0, utils_1.addImport)(tree, filePath, removedSpecifier, schemaValidationPackage));
        });
    }
    warnAboutSchemaValidationOnObliqueModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            let usesSchemaValidation = false;
            let importsObliqueModule = false;
            (0, utils_1.applyInTree)(tree, (filePath) => {
                const fileContent = tree.readText(filePath);
                usesSchemaValidation ||=
                    /\b(?:obSchemaValidation|obSchemaValidate|ObSchemaValidationModule|ObSchemaValidationService)\b/u.test(fileContent);
                importsObliqueModule ||= /\bObliqueModule\b/u.test(fileContent);
            }, utils_1.filePatterns.tsAndHtml);
            if (usesSchemaValidation && importsObliqueModule) {
                (0, utils_1.warn)(context, 'Schema validation is now a secondary entry point and is no longer exported by ObliqueModule. ' +
                    "If your application relied on ObliqueModule alone, import ObSchemaValidationModule from '@oblique/oblique/schema-validation' manually.");
            }
            return tree;
        });
    }
    warnAboutSchemaValidationOnObliqueTestingModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            let usesSchemaValidation = false;
            let importsObliqueTestingModule = false;
            (0, utils_1.applyInTree)(tree, (filePath) => {
                const fileContent = tree.readText(filePath);
                usesSchemaValidation ||=
                    /\b(?:obSchemaValidation|obSchemaValidate|ObMockSchemaValidationModule|ObMockSchemaValidationService)\b/u.test(fileContent);
                importsObliqueTestingModule ||= /\bObliqueTestingModule\b/u.test(fileContent);
            }, utils_1.filePatterns.tsAndHtml);
            if (usesSchemaValidation && importsObliqueTestingModule) {
                (0, utils_1.warn)(context, 'Schema validation mocks are now part of the secondary entry point. ' +
                    "If your tests relied on ObliqueTestingModule alone, import ObMockSchemaValidationModule from '@oblique/oblique/schema-validation' manually.");
            }
            return tree;
        });
    }
    addXhrToHttpClientProvider() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Add withXhr() to provideHttpClient()');
            const toApply = (filePath) => {
                const providerOptions = /(?:provideHttpClient\()(?<options>[^\r\n]*)/u.exec((0, utils_1.readFile)(tree, filePath))?.groups
                    ?.options;
                if (providerOptions && !providerOptions.includes('withXhr()')) {
                    (0, utils_1.addImport)(tree, filePath, 'withXhr', '@angular/common/http');
                    (0, utils_1.replaceInFile)(tree, filePath, `provideHttpClient(${providerOptions}`, `provideHttpClient(withXhr(), ${providerOptions}`);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, '*.ts');
        });
    }
}
exports.UpdateV15toV16 = UpdateV15toV16;
