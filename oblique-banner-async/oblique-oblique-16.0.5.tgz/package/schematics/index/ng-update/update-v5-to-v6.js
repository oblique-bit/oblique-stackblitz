/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV5toV6 = void 0;
/* eslint-disable prefer-named-capture-group */
const schematics_1 = require("@angular-devkit/schematics");
const ng_update_utils_1 = require("./ng-update-utils");
const utils_1 = require("../utils");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
const dependencies_1 = require("@schematics/angular/utility/dependencies");
class UpdateV5toV6 {
    dependencies = {
        '@angular/core': 11,
        '@angular/router': (angular) => angular,
        '@ngx-translate/core': 13,
        '@ng-bootstrap/ng-bootstrap': [9, 0],
        '@angular/material': (angular) => [angular, 0],
        ajv: [6, 0],
    };
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Analyzing project');
            (0, ng_update_utils_1.minAngularVersion)(tree, context, 6, 11);
            return (0, schematics_1.chain)([
                this.migrateFont(),
                this.migrateAssets(),
                this.addFeatureDetection(),
                this.changeColorPalette(),
                this.renameMockCollapseComponent(),
                this.renameDefaultLanguage(),
                this.adaptDependencies(),
                this.migrateDropdown(),
                this.removeUnsubscribe(),
                this.adaptHtmlToCss(),
                this.adaptCssClassNaming(),
            ])(tree, context);
        };
    }
    migrateFont() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrating font');
            const module = (0, utils_1.readFile)(tree, ng_add_utils_1.appModulePath);
            const match = /(?<full>\s*{\s*provide\s*:\s*OBLIQUE_FONT\s*,\s*useValue\s*:\s*(?:FONTS\.)?['"]?(?<font>[^"'\s}]*)['"]?\s*},?)/.exec(module);
            const full = match?.groups?.full;
            const font = match?.groups?.font;
            if (full && font) {
                tree.overwrite(ng_add_utils_1.appModulePath, module
                    .replace(full, '')
                    .replace(/OBLIQUE_FONT\s*,?\s?/, '')
                    .replace(/FONTS\s*,?\s?/, ''));
                this.addFontFiles(tree, font.toLowerCase());
                this.addFontStyle(tree, font.toLowerCase());
            }
            return tree;
        };
    }
    addFontStyle(tree, font) {
        if (font !== 'none') {
            const styleSheet = `node_modules/@oblique/oblique/styles/css/${font}.css`;
            (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => {
                if (!config.includes(styleSheet)) {
                    config.splice(config.indexOf(ng_add_utils_1.obliqueCssPath) + 1, 0, styleSheet);
                }
                return config;
            });
        }
    }
    addFontFiles(tree, font) {
        if (font === 'roboto') {
            (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => {
                config.splice(1, 0, {
                    glob: '*/**',
                    input: 'node_modules/@oblique/oblique/styles/fonts',
                    output: 'assets/fonts',
                });
                return config;
            });
        }
    }
    migrateAssets() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrating assets');
            this.adaptFavIcon(tree);
            return this.adaptAssets(tree);
        };
    }
    adaptFavIcon(tree) {
        (0, utils_1.getIndexPaths)(tree).forEach((indexPath) => (0, utils_1.overwriteIndexFile)(indexPath, tree, /<link .*?href="(?:\.\/)?assets\/styles\/images\/favicon\.(?:ico|png)".*?>/, '<link href="assets/images/favicon.png" rel="shortcut icon"/>'));
    }
    adaptAssets(tree) {
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => [
            { glob: '**/*', input: 'node_modules/@oblique/oblique/assets', output: 'assets' },
            ...config
                .filter((asset) => asset?.input !== 'node_modules/@oblique/oblique/assets')
                .filter((asset) => asset?.input !== 'node_modules/@oblique/oblique/styles'),
        ]);
    }
    addFeatureDetection() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Oblique: Adding browser compatibility check');
            const indexFileReplacements = [
                { searchValue: /<!--\[if lt.*?endif]-->\s/s, replaceValue: '' },
                { searchValue: /<!--\[if gte.*(<html.*?>).*endif]-->\s/s, replaceValue: '$1' },
                { searchValue: /<body([^>]*)>\n/, replaceValue: `<body$1>\n${(0, ng_add_utils_1.getTemplate)(tree, 'default-index.html')}` },
            ];
            (0, utils_1.getIndexPaths)(tree).forEach((element) => indexFileReplacements.forEach(value => {
                (0, utils_1.overwriteIndexFile)(element, tree, value.searchValue, value.replaceValue);
            }));
            return (0, utils_1.addAngularConfigInList)(tree, ['architect', 'build', 'options', 'scripts'], 'node_modules/@oblique/oblique/ob-features.js');
        };
    }
    changeColorPalette() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Change color palette');
            const apply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\$brand-info-light/g), '$brand-light');
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\$brand-info/g), '$brand-primary');
                (0, utils_1.replaceInFile)(tree, filePath, new RegExp(/\$brand-info-dark/g), '$brand-dark');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        };
    }
    renameMockCollapseComponent() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming MockCollapseComponent');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /MockCollapseComponent/g, 'ObMockCollapseComponent');
                (0, utils_1.replaceInFile)(tree, filePath, /MockCollapseModule/g, 'ObMockCollapseModule');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        };
    }
    renameDefaultLanguage() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Renaming locale.default into locale.defaultLanguage');
            const toApply = (filePath) => {
                const config = /(?<config>\w*):\s*ObMasterLayoutConfig/.exec((0, utils_1.readFile)(tree, filePath))?.groups?.config;
                if (config) {
                    (0, utils_1.replaceInFile)(tree, filePath, new RegExp(`${config}\\.locale\\.default([\\s=])`, 'g'), `${config}.locale.defaultLanguage$1`);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        };
    }
    adaptDependencies() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Adapting dependencies');
            this.adaptTranslationDependencies(tree);
            this.adaptCoreJsDependency(tree);
            this.adaptTestDependencies(tree);
            if (!(0, dependencies_1.getPackageJsonDependency)(tree, '@angular-builders/jest')) {
                (0, dependencies_1.removePackageJsonDependency)(tree, 'jest-preset-angular');
                (0, dependencies_1.removePackageJsonDependency)(tree, 'ts-jest');
            }
            (0, dependencies_1.removePackageJsonDependency)(tree, 'ts-morph');
            (0, dependencies_1.removePackageJsonDependency)(tree, '@ts-morph/common');
        };
    }
    adaptTestDependencies(tree) {
        const usesProtractor = (0, utils_1.checkIfAngularConfigExists)(tree, ['architect', 'e2e', 'builder'], '@angular-devkit/build-angular:protractor');
        const usesJest = (0, utils_1.checkIfAngularConfigExists)(tree, ['architect', 'test', 'builder'], '@angular-builders/jest:run');
        const deps = Object.keys((0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath)?.devDependencies || {});
        deps
            .filter(dep => dep.includes(usesJest ? 'karma' : 'jest'))
            .forEach(dep => (0, dependencies_1.removePackageJsonDependency)(tree, dep));
        if (usesJest && !usesProtractor) {
            deps.filter(dep => dep.includes('jasmine')).forEach(dep => (0, dependencies_1.removePackageJsonDependency)(tree, dep));
        }
    }
    adaptTranslationDependencies(tree) {
        const file = (0, utils_1.readFile)(tree, ng_add_utils_1.appModulePath);
        const factory = /TranslateModule\.forRoot\({.*?useFactory\s*:\s*(?<factory>\w*)/s.exec(file)?.groups?.factory;
        const loader = new RegExp(`export function ${factory}\\(.*new (?<loader>[^(]*)`, 's').exec(file)?.groups?.loader;
        const hasObMultiLoader = /TranslateModule.forRoot\(\s*multiTranslateLoader\(/.test(file);
        if (hasObMultiLoader || loader !== 'TranslateHttpLoader') {
            this.removeTranslateLoader(tree, '@ngx-translate/http-loader', 'TranslateHttpLoader');
        }
        if (hasObMultiLoader || loader !== 'MultiTranslateHttpLoader') {
            this.removeTranslateLoader(tree, 'ngx-translate-multi-http-loader', 'MultiTranslateHttpLoader');
        }
    }
    removeTranslateLoader(tree, dep, className) {
        const file = (0, utils_1.readFile)(tree, ng_add_utils_1.appModulePath);
        (0, dependencies_1.removePackageJsonDependency)(tree, dep);
        tree.overwrite(ng_add_utils_1.appModulePath, file
            .replace(new RegExp(`\\nexport function .*\\(.*new ${className}[^;]*;\\s*}`, 's'), '')
            .replace(new RegExp(`\\nimport\\s*{\\s*${className}\\s*}\\s*from\\s*['"]${dep}['"]\\s*;`), ''));
    }
    adaptCoreJsDependency(tree) {
        const hasCoreJsBeenImported = (0, utils_1.getAngularConfigs)(tree, ['architect', 'build', 'options', 'polyfills'])
            .map(polyfill => (0, ng_add_utils_1.createSrcFile)(tree, polyfill.config))
            .filter(sourceFile => /import 'core-js/.test(sourceFile.getText())).length;
        if (!hasCoreJsBeenImported) {
            (0, dependencies_1.removePackageJsonDependency)(tree, 'core-js');
        }
    }
    migrateDropdown() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate ObDropdownComponent');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /<button(.*?) dropdown-toggle[^>]*>\s*(<[^\s]*)(.*)\s*<\/button>/g, '$2 dropdown-toggle$1$3');
                (0, utils_1.replaceInFile)(tree, filePath, /<button dropdown-toggle>(\w*)<\/button>/g, '<ng-container dropdown-toggle>$1</ng-container>');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.html);
        };
    }
    removeUnsubscribe() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate Unsubscribe class');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('extends ObUnsubscribable')) {
                    tree.overwrite(filePath, content.replace(/extends\s+ObUnsubscribable\s?/, '').replace(/\s*super\(\);/, ''));
                    (0, utils_1.addInterface)(tree, filePath, 'OnDestroy');
                    (0, utils_1.addImport)(tree, filePath, 'OnDestroy', '@angular/core');
                    (0, utils_1.addImport)(tree, filePath, 'Subject', 'rxjs');
                    (0, utils_1.removeImport)(tree, filePath, 'ObUnsubscribable', '@oblique/oblique');
                    (0, utils_1.replaceInFile)(tree, filePath, /\n([\t ]*)constructor\(/, '$1private readonly unsubscribe = new Subject();\n\n$1constructor(');
                    this.addNgOnDestroy(tree, filePath, content.includes('ngOnDestroy'));
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        };
    }
    addNgOnDestroy(tree, filePath, extend) {
        if (extend) {
            (0, utils_1.replaceInFile)(tree, filePath, /ngOnDestroy\(.*{\s*\n(\s*)/, 'ngOnDestroy(): void {\n$1this.unsubscribe.next();\n$1this.unsubscribe.complete();\n$1');
        }
        else {
            (0, utils_1.replaceInFile)(tree, filePath, /\n([\t ]*)constructor\(/, '\n$1ngOnDestroy(): void {\n$1$1this.unsubscribe.next();\n$1$1this.unsubscribe.complete();\n$1}\n\n$1constructor(');
        }
    }
    adaptHtmlToCss() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, "Prefix Oblique's classes in HTML");
            const apply = (filePath) => {
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'alert', ['info', 'success', 'warning', 'error', 'link']);
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'sticky', ['sm', 'lg']);
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'nav-stepper', ['sm', 'lg']);
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'table', ['cicd', 'plain', 'collapse', 'hover', 'scrollable']);
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'no-layout');
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'expanded');
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'close');
                (0, ng_update_utils_1.addClassesPrefix)(tree, filePath, 'main-nav', ['item']);
                (0, ng_update_utils_1.addClassPrefix)(tree, filePath, 'sticky', ['content', 'main', 'header', 'footer', 'title', 'actions', 'layout']);
                (0, ng_update_utils_1.addClassPrefix)(tree, filePath, 'control', ['link', 'item', 'icon', 'label', 'toggle', 'locale']);
                (0, ng_update_utils_1.addClassPrefix)(tree, filePath, 'multiselect', ['toggle', 'label', 'control']);
                (0, ng_update_utils_1.addClassPrefix)(tree, filePath, 'nav', [
                    'tree',
                    'link',
                    'indent',
                    'bordered',
                    'hover',
                    'toggle',
                    'step',
                    'horizontal',
                ]);
                (0, ng_update_utils_1.addClassPrefix)(tree, filePath, 'tab', ['item', 'link']);
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.html);
        };
    }
    adaptCssClassNaming() {
        return (tree, context) => {
            (0, utils_1.infoMigration)(context, "Prefix Oblique's classes in SCSS");
            const apply = (filePath) => {
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'toggle', [
                    'after',
                    'before',
                    'justified',
                    'down',
                    'up',
                    'right',
                    'left',
                ]);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'notification', ['container', 'title']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'alert', ['info', 'success', 'warning', 'error', 'link']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'search-box', ['input']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'text-control', ['clear']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'sticky', [
                    'content',
                    'main',
                    'header',
                    'footer',
                    'title',
                    'actions',
                    'sm',
                    'lg',
                    'layout',
                ]);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'nav-stepper', ['sm', 'lg']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'table', ['cicd', 'plain', 'collapse', 'hover', 'scrollable']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'dropdown', ['content']);
                (0, ng_update_utils_1.addPrefixMatchExactOrSuffix)(tree, filePath, 'main-nav', ['item']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'sub', ['nav', 'nav-item', 'menu', 'menu-back']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'column', ['layout', 'toggle', 'right', 'left', 'main', 'content']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'cover', ['layout', 'viewport', 'header', 'alert']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'control', ['link', 'item', 'icon', 'label', 'toggle', 'locale']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'multiselect', ['toggle', 'label', 'control']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'nav', [
                    'tree',
                    'link',
                    'indent',
                    'bordered',
                    'hover',
                    'toggle',
                    'step',
                    'horizontal',
                ]);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'tab', ['item', 'link']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'search', ['results-list', 'dropdown']);
                (0, ng_update_utils_1.addPrefixMatchSuffix)(tree, filePath, 'header', ['locale', 'controls']);
                (0, ng_update_utils_1.addPrefixMatchExact)(tree, filePath, [
                    'navigation-scrollable(?:-(?:control(?:-(?:left|right))?|content))?',
                    'main-layout',
                    'assess-keys',
                    'accessible',
                    'tabs',
                    'step-link',
                    'spinner-viewport',
                    'pattern-highlight',
                    'custom',
                    'top-control',
                    'highlight',
                    'slide-control',
                ]);
                (0, ng_update_utils_1.renameExactOrSuffix)(tree, filePath, 'application', ['navigation', 'header', 'fixed', 'brand', 'footer', 'scrolling', 'content'], 'ob-master-layout');
                (0, ng_update_utils_1.renameExactOrSuffix)(tree, filePath, 'offcanvas', ['sidebar', 'main', 'in', 'header', 'content', 'backdrop'], 'ob-off-canvas');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.scss);
        };
    }
}
exports.UpdateV5toV6 = UpdateV5toV6;
