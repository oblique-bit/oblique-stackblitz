/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.upgradeToV5 = upgradeToV5;
exports.upgradeToV6 = upgradeToV6;
exports.upgradeToV7 = upgradeToV7;
exports.upgradeToV8 = upgradeToV8;
exports.upgradeToV9 = upgradeToV9;
exports.upgradeToV10 = upgradeToV10;
exports.upgradeToV11 = upgradeToV11;
exports.upgradeToV12 = upgradeToV12;
exports.upgradeToV13 = upgradeToV13;
exports.upgradeToV14 = upgradeToV14;
exports.upgradeToV15 = upgradeToV15;
exports.upgradeToV16 = upgradeToV16;
exports.finalize = finalize;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
const ng_update_utils_1 = require("./ng-update-utils");
const update_v4_to_v5_1 = require("./update-v4-to-v5");
const update_v5_to_v6_1 = require("./update-v5-to-v6");
const update_v6_to_v7_1 = require("./update-v6-to-v7");
const update_v7_to_v8_1 = require("./update-v7-to-v8");
const update_v8_to_v9_1 = require("./update-v8-to-v9");
const update_v9_to_v10_1 = require("./update-v9-to-v10");
const update_v10_to_v11_1 = require("./update-v10-to-v11");
const update_v11_to_v12_1 = require("./update-v11-to-v12");
const update_v12_to_v13_1 = require("./update-v12-to-v13");
const update_v13_to_v14_1 = require("./update-v13-to-v14");
const update_v14_to_v15_1 = require("./update-v14-to-v15");
const update_v15_to_v16_1 = require("./update-v15-to-v16");
function upgradeToV5(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v4_to_v5_1.UpdateV4toV5(), options);
}
function upgradeToV6(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v5_to_v6_1.UpdateV5toV6(), options);
}
function upgradeToV7(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v6_to_v7_1.UpdateV6toV7(), options);
}
function upgradeToV8(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v7_to_v8_1.UpdateV7toV8(), options);
}
function upgradeToV9(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v8_to_v9_1.UpdateV8toV9(), options);
}
function upgradeToV10(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v9_to_v10_1.UpdateV9toV10(), options);
}
function upgradeToV11(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v10_to_v11_1.UpdateV10toV11(), options);
}
function upgradeToV12(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v11_to_v12_1.UpdateV11toV12(), options);
}
function upgradeToV13(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v12_to_v13_1.UpdateV12toV13(), options);
}
function upgradeToV14(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v13_to_v14_1.UpdateV13toV14(), options);
}
function upgradeToV15(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v14_to_v15_1.UpdateV14toV15(), options);
}
function upgradeToV16(options) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => startup(new update_v15_to_v16_1.UpdateV15toV16(), options);
}
function startup(migrations, options) {
    return (tree, context) => {
        (0, utils_1.infoMigration)(context, 'Starting migrations');
        return (0, schematics_1.chain)([migrations.applyMigrations(options), (0, utils_1.installDependencies)(), finalize(migrations.dependencies)])(tree, context);
    };
}
function finalize(deps) {
    return (tree, context) => {
        (0, utils_1.success)(context, 'Oblique has been successfully migrated. Please review the changes.');
        (0, utils_1.infoHighlights)(context, `Let us update other dependencies to conclude.
run %c to update the dependencies to their latest compatible versions and %c to discover other updatable packages.`, 'npm update', 'npm outdated');
        (0, ng_update_utils_1.checkDependencies)(tree, context, deps);
    };
}
