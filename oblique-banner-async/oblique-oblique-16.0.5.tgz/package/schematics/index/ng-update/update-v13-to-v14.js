/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV13toV14 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
class UpdateV13toV14 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            (0, utils_1.warnIfStandalone)(),
            this.renameIcons(),
            this.migrateAccessibilityStatementContactInfo(),
            this.addMissingAccessibilityStatementProperties(),
            this.migrateServiceNavigationContactInfo(),
            this.removeObPaginator(),
            this.removeFocusableFragments(),
            this.migrateColumnLayoutColumnsState(),
            this.removeObIconModuleForRoot(),
            this.migrateScrollToTop(),
            this.removeHttpInterceptorModule(),
        ])(tree, context);
    }
    renameIcons() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename icons');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="family"/g, 'svgIcon="person_group"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FAMILY/g, 'ObEIcon.PERSON_GROUP');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="ald"/g, 'svgIcon="hard-of-hearing"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ALD/g, 'ObEIcon.HARD_OF_HEARING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="unlink"/g, 'svgIcon="link_disconnect"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.UNLINK/g, 'ObEIcon.LINK_DISCONNECT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="external"/g, 'svgIcon="link_external"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.EXTERNAL/g, 'ObEIcon.LINK_EXTERNAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="more"/g, 'svgIcon="more_vertical"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.MORE/g, 'ObEIcon.SHOW_MORE_VERTICAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="alternate-arrow"/g, 'svgIcon="scroll_horizontal"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ALTERNATE_ARROW/g, 'ObEIcon.SCROLL_HORIZONTAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="alternate-arrow"/g, 'svgIcon="scroll_horizontal"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ALTERNATE_ARROW/g, 'ObEIcon.SCROLL_HORIZONTAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="exchange"/g, 'svgIcon="swap_horizontal"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.EXCHANGE/g, 'ObEIcon.SWAP_HORIZONTAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="repeat"/g, 'svgIcon="arrow_clockwise"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.REPEAT/g, 'ObEIcon.ARROW_CLOCKWISE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-up"/g, 'svgIcon="arrow_up"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-up-left"/g, 'svgIcon="arrow_up-left"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-up-right"/g, 'svgIcon="arrow_up-right"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-down"/g, 'svgIcon="arrow_down"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-down-left"/g, 'svgIcon="arrow_down-left"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-down-right"/g, 'svgIcon="arrow_down-right"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-right"/g, 'svgIcon="arrow_right"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow-left"/g, 'svgIcon="arrow_left"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-left"/g, 'svgIcon="chevron_left"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-small-left"/g, 'svgIcon="chevron_left-small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_SMALL_LEFT/g, 'ObEIcon.CHEVRON_LEFT_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-double-left"/g, 'svgIcon="chevron_double-left"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-line-left"/g, 'svgIcon="chevron_left-to-line"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_LINE_LEFT/g, 'ObEIcon.CHEVRON_LEFT_TO_LINE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-right"/g, 'svgIcon="chevron_right"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-small-right"/g, 'svgIcon="chevron_right-small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_SMALL_RIGHT/g, 'ObEIcon.CHEVRON_RIGHT_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-double-right"/g, 'svgIcon="chevron_double-right"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-line-right"/g, 'svgIcon="chevron_right-to-line"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_LINE_RIGHT/g, 'ObEIcon.CHEVRON_RIGHT_TO_LINE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-down"/g, 'svgIcon="chevron_down"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-small-down"/g, 'svgIcon="chevron_down-small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_SMALL_DOWN/g, 'ObEIcon.CHEVRON_DOWN_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-up"/g, 'svgIcon="chevron_up"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron-small-up"/g, 'svgIcon="chevron_up-small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_SMALL_UP/g, 'ObEIcon.CHEVRON_UP_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="cog"/g, 'svgIcon="settings"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.COG/g, 'ObEIcon.SETTINGS');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="filter-descending"/g, 'svgIcon="sort-list_descending"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILTER_DESCENDING/g, 'ObEIcon.SORT_LIST_DESCENDING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="filter-descending"/g, 'svgIcon="sort-list_descending"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILTER_DESCENDING/g, 'ObEIcon.SORT_LIST_DESCENDING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="filter-ascending"/g, 'svgIcon="sort-list_ascending"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILTER_ASCENDING/g, 'ObEIcon.SORT_LIST_ASCENDING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="compress"/g, 'svgIcon="collapse"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.COMPRESS/g, 'ObEIcon.COLLAPSE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="pen"/g, 'svgIcon="pencil"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.PEN/g, 'ObEIcon.PENCIL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="printer"/g, 'svgIcon="print"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.PRINTER/g, 'ObEIcon.PRINT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="trash"/g, 'svgIcon="delete"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.TRASH/g, 'ObEIcon.DELETE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="zoom-in"/g, 'svgIcon="zoom_in"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="zoom-out"/g, 'svgIcon="zoom_out"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="text-area-left"/g, 'svgIcon="textarea_left"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.TEXT_AREA_LEFT/g, 'ObEIcon.TEXTAREA_LEFT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="text-area-right"/g, 'svgIcon="textarea_right"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.TEXT_AREA_RIGHT/g, 'ObEIcon.TEXTAREA_RIGHT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="wand"/g, 'svgIcon="magic-wand"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.WAND/g, 'ObEIcon.MAGIC_WAND');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="eyedropper"/g, 'svgIcon="color-picker"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.EYEDROPPER/g, 'ObEIcon.COLOR_PICKER');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="art"/g, 'svgIcon="palette"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ART/g, 'ObEIcon.PALETTE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="plus-circle"/g, 'svgIcon="plus_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="cards"/g, 'svgIcon="grid"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CARDS/g, 'ObEIcon.GRID');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="list-paragraph"/g, 'svgIcon="list_paragraph"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="lifering"/g, 'svgIcon="support"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.LIFERING/g, 'ObEIcon.SUPPORT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="language"/g, 'svgIcon="translate"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.LANGUAGE/g, 'ObEIcon.TRANSLATE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="envelope"/g, 'svgIcon="mail"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ENVELOPE/g, 'ObEIcon.MAIL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="envelope-open"/g, 'svgIcon="mail_open"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ENVELOPE_OPEN/g, 'ObEIcon.MAIL_OPEN');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="mail-attachment"/g, 'svgIcon="mail_attachment"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="paper-plane"/g, 'svgIcon="send"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.PAPER_PLANE/g, 'ObEIcon.SEND');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="bell"/g, 'svgIcon="notification"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BELL/g, 'ObEIcon.NOTIFICATION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="bell-slash"/g, 'svgIcon="notification_off"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BELL_SLASH/g, 'ObEIcon.NOTIFICATION_OFF');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="map-marker"/g, 'svgIcon="location"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.MAP_MARKER/g, 'ObEIcon.LOCATION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="bullseye"/g, 'svgIcon="target"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BULLSEYE/g, 'ObEIcon.TARGET');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="balance"/g, 'svgIcon="justice-scales"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BALANCE/g, 'ObEIcon.JUSTICE_SCALES');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="balance-slash"/g, 'svgIcon="justice-scales_off"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BALANCE_SLASH/g, 'ObEIcon.JUSTICE_SCALES_OFF');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="scroll"/g, 'svgIcon="manuscript"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.SCROLL/g, 'ObEIcon.MANUSCRIPT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="university"/g, 'svgIcon="antique-building"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.UNIVERSITY/g, 'ObEIcon.ANTIQUE_BUILDING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="industry"/g, 'svgIcon="factory"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.INDUSTRY/g, 'ObEIcon.FACTORY');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="bed"/g, 'svgIcon="accommodation"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BED/g, 'ObEIcon.ACCOMMODATION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="fitness"/g, 'svgIcon="dumbbell"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FITNESS/g, 'ObEIcon.DUMBBELL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="cloud-upload"/g, 'svgIcon="cloud_upload"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="code-branch"/g, 'svgIcon="branch"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CODE_BRANCH/g, 'ObEIcon.BRANCH');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="audio-low"/g, 'svgIcon="volume_low"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.AUDIO_LOW/g, 'ObEIcon.VOLUME_LOW');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="audio-mute"/g, 'svgIcon="volume_muted"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.AUDIO_MUTE/g, 'ObEIcon.VOLUME_MUTED');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="microphone-slash"/g, 'svgIcon="microphone_muted"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.MICROPHONE_SLASH/g, 'ObEIcon.MICROPHONE_MUTED');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="unlock"/g, 'svgIcon="lock_open"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.UNLOCK/g, 'ObEIcon.LOCK_OPEN');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="eye-slash"/g, 'svgIcon="eye_off"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.EYE_SLASH/g, 'ObEIcon.EYE_OFF');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="bolt"/g, 'svgIcon="lightning"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BOLT/g, 'ObEIcon.LIGHTNING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="thumbs-up"/g, 'svgIcon="thumbs_up"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="thumbs-down"/g, 'svgIcon="thumbs_down"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="smile"/g, 'svgIcon="happy"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.SMILE/g, 'ObEIcon.HAPPY');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="frown"/g, 'svgIcon="sad"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FROWN/g, 'ObEIcon.SAD');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="heart-filled"/g, 'svgIcon="heart_filled"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="flag-filled"/g, 'svgIcon="flag_filled"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="star-filled"/g, 'svgIcon="star_filled"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="stop"/g, 'svgIcon="stop-gesture"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.STOP/g, 'ObEIcon.STOP_GESTURE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="info-circle"/g, 'svgIcon="info_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="help"/g, 'svgIcon="question"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.HELP/g, 'ObEIcon.QUESTION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="help-circle"/g, 'svgIcon="question_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.HELP_CIRCLE/g, 'ObEIcon.QUESTION_CIRCLE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="warning"/g, 'svgIcon="exclamation"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.WARNING/g, 'ObEIcon.EXCLAMATION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="warning-triangle"/g, 'svgIcon="exclamation_triangle"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.WARNING_TRIANGLE/g, 'ObEIcon.EXCLAMATION_TRIANGLE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="warning-circle"/g, 'svgIcon="exclamation_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.WARNING_CIRCLE/g, 'ObEIcon.EXCLAMATION_CIRCLE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="warning-box"/g, 'svgIcon="exclamation_diamond"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.WARNING_BOX/g, 'ObEIcon.EXCLAMATION_DIAMOND');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="checkmark-circle"/g, 'svgIcon="checkmark_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="cancel"/g, 'svgIcon="xmark"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CANCEL/g, 'ObEIcon.XMARK');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="cancel-circle"/g, 'svgIcon="xmark_circle"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CANCEL_CIRCLE/g, 'ObEIcon.XMARK_CIRCLE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="ban"/g, 'svgIcon="prohibition"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BAN/g, 'ObEIcon.PROHIBITION');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user"/g, 'svgIcon="person"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER/g, 'ObEIcon.PERSON');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="users"/g, 'svgIcon="person_group"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USERS/g, 'ObEIcon.PERSON_GROUP');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user-checkmark"/g, 'svgIcon="person_checkmark"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER_CHECKMARK/g, 'ObEIcon.PERSON_CHECKMARK');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user-cog"/g, 'svgIcon="person_settings"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER_COG/g, 'ObEIcon.PERSON_SETTINGS');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user-pen"/g, 'svgIcon="person_pencil"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER_PEN/g, 'ObEIcon.PERSON_PENCIL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user-brush"/g, 'svgIcon="person_brush"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER_BRUSH/g, 'ObEIcon.PERSON_BRUSH');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="user-code"/g, 'svgIcon="person_code"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.USER_CODE/g, 'ObEIcon.PERSON_CODE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="doctor"/g, 'svgIcon="person_medic"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.DOCTOR/g, 'ObEIcon.PERSON_MEDIC');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-agender"/g, 'svgIcon="gender_agender"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_AGENDER/g, 'ObEIcon.GENDER_AGENDER');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-bigender"/g, 'svgIcon="gender_bigender"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_BIGENDER/g, 'ObEIcon.GENDER_BIGENDER');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-female"/g, 'svgIcon="gender_female"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_FEMALE/g, 'ObEIcon.GENDER_FEMALE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-male"/g, 'svgIcon="gender_male"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_MALE/g, 'ObEIcon.GENDER_MALE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-gender-expansive"/g, 'svgIcon="gender_transgender"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_GENDER_EXPANSIVE/g, 'ObEIcon.GENDER_TRANSGENDER');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-neutrois"/g, 'svgIcon="gender_neutrois"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_NEUTROIS/g, 'ObEIcon.GENDER_NEUTROIS');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="gender-identity-non-binary"/g, 'svgIcon="gender_non-binary"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GENDER_IDENTITY_NON_BINARY/g, 'ObEIcon.GENDER_NON_BINARY');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="increase"/g, 'svgIcon="growth"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.INCREASE/g, 'ObEIcon.GROWTH');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="decrease"/g, 'svgIcon="decline"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.DECREASE/g, 'ObEIcon.DECLINE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart-bar"/g, 'svgIcon="chart_bar_horizontal"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHART_BAR/g, 'ObEIcon.CHART_BAR_HORIZONTAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart"/g, 'svgIcon="chart_bar_vertical"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHART/g, 'ObEIcon.CHART_BAR_VERTICAL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart-pie"/g, 'svgIcon="chart_pie"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart-line"/g, 'svgIcon="chart_line"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart-decrease"/g, 'svgIcon="chart_line_decline"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHART_DECREASE/g, 'ObEIcon.CHART_LINE_DECLINE');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="increase"/g, 'svgIcon="chart_line_growth"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHART_INCREASE/g, 'ObEIcon.CHART_LINE_GROWTH');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chart-search"/g, 'svgIcon="search_insights"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHART_SEARCH/g, 'ObEIcon.SEARCH_INSIGHTS');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="universal-access"/g, 'svgIcon="accessibility"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.UNIVERSAL_ACCESS/g, 'ObEIcon.ACCESSIBILITY');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="blind"/g, 'svgIcon="visual-impairment"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.BLIND/g, 'ObEIcon.VISUAL_IMPAIRMENT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="deaf"/g, 'svgIcon="hard-of-hearing"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.DEAF/g, 'ObEIcon.HARD_OF_HEARING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="git-hub"/g, 'svgIcon="github"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.GIT_HUB/g, 'ObEIcon.GITHUB');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="linked-in"/g, 'svgIcon="linkedin"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.LINKED_IN/g, 'ObEIcon.LINKEDIN');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="folder-open"/g, 'svgIcon="folder_open"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FOLDER_OPEN/g, 'ObEIcon.FOLDER_OPEN');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="duplicate"/g, 'svgIcon="copy"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.DUPLICATE/g, 'ObEIcon.COPY');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="archive"/g, 'svgIcon="archive-box"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ARCHIVE/g, 'ObEIcon.ARCHIVE_BOX');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-lines"/g, 'svgIcon="file_text"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_LINES/g, 'ObEIcon.FILE_TEXT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-bullet"/g, 'svgIcon="file_list"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_BULLET/g, 'ObEIcon.FILE_LIST');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-checkmark"/g, 'svgIcon="file_checkmark"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-user"/g, 'svgIcon="file_person"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_USER/g, 'ObEIcon.FILE_PERSON');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-plus"/g, 'svgIcon="file_add"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_PLUS/g, 'ObEIcon.FILE_ADD');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-forward"/g, 'svgIcon="file_forward"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-image"/g, 'svgIcon="file_image"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-pdf"/g, 'svgIcon="file_pdf"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-epub"/g, 'svgIcon="file_epub"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-xml"/g, 'svgIcon="file_xml"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-csv"/g, 'svgIcon="file_csv"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-code"/g, 'svgIcon="file_code"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-json"/g, 'svgIcon="file_json"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-ppt"/g, 'svgIcon="file_powerpoint"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_PPT/g, 'ObEIcon.FILE_POWERPOINT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-word"/g, 'svgIcon="file_word"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-excel"/g, 'svgIcon="file_excel"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-zip"/g, 'svgIcon="file_zip"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-audio"/g, 'svgIcon="file_audio"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-video"/g, 'svgIcon="file_video"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-server"/g, 'svgIcon="file_server"');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="file-refresh"/g, 'svgIcon="file_refresh"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.FILE_REFRESH/g, 'ObEIcon.FILE_REFRESH');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="random"/g, 'svgIcon="shuffle"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.RANDOM/g, 'ObEIcon.SHUFFLE');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.tsAndHtml);
        });
    }
    migrateAccessibilityStatementContactInfo() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate accessibility statement contact info');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('provideObliqueConfiguration(')) {
                    const contacts = [];
                    const emails = (/(?<=emails\s*:\s*\[).*?(?=\])/u.exec(content) ?? [])[0];
                    if (emails?.length) {
                        contacts.push(...emails.split(',').map(email => `{email: ${email.trim()}}`));
                    }
                    const phones = (/(?<=phones\s*:\s*\[\s*).*?(?=\])/u.exec(content) ?? [])[0];
                    if (phones?.length) {
                        contacts.push(...phones.split(',').map(phone => `{phone: ${phone.trim()}}`));
                    }
                    (0, utils_1.replaceInFile)(tree, filePath, /(?<=contact\s*:\s*)\s*\{\s*[^}]*\}/gmu, `[${contacts.join(', ')}]`);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    addMissingAccessibilityStatementProperties() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Add missing accessibility statement properties');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('provideObliqueConfiguration(')) {
                    if (!content.includes('conformity')) {
                        (0, utils_1.replaceInFile)(tree, filePath, /(?<=accessibilityStatement\s*:\s*\{)/, `\n\t\t\t\tconformity: '${this.getConformity(content)}',`);
                    }
                    if (!content.includes('createdOn')) {
                        const createdOn = new Date().toISOString().split('T')[0];
                        (0, utils_1.replaceInFile)(tree, filePath, /(?<=accessibilityStatement\s*:\s*\{)/, `\n\t\t\t\tcreatedOn: new Date('${createdOn}'),`);
                    }
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    getConformity(content) {
        if (content.includes('exceptions')) {
            return 'partial';
        }
        return content.includes('createdOn') ? 'full' : 'none';
    }
    migrateServiceNavigationContactInfo() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate service navigation contact info');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('header.serviceNavigation.infoContact')) {
                    tree.overwrite(filePath, content.replace(/(?<prefix>header\.serviceNavigation\.infoContact\s*=\s*{.*)tel(?<suffix>.*})/s, '$<prefix>phone$<suffix>'));
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeObPaginator() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replace ObPaginatorModule with MatPaginatorModule');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('ObPaginatorModule')) {
                    (0, utils_1.removeImport)(tree, filePath, 'ObPaginatorModule', '@oblique/oblique');
                    (0, utils_1.addImport)(tree, filePath, 'MatPaginatorModule', '@angular/material/paginator');
                    (0, utils_1.replaceInFile)(tree, filePath, /ObPaginatorModule/g, 'MatPaginatorModule');
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeFocusableFragments() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Replace focusableFragments property');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                const regexp = /^\s*\w+\.focusableFragment\s*=\s*\[.*?\];/msu;
                if (regexp.test(content)) {
                    (0, utils_1.replaceInFile)(tree, filePath, regexp, '');
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    migrateColumnLayoutColumnsState() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate column layout columns state');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('<ob-column-layout')) {
                    (0, utils_1.replaceInFile)(tree, filePath, /\[left\]="true"/gu, `left="OPENED"`);
                    (0, utils_1.replaceInFile)(tree, filePath, /\[left\]="false"/gu, `left="NONE"`);
                    (0, utils_1.replaceInFile)(tree, filePath, /\[right\]="true"/gu, `right="OPENED"`);
                    (0, utils_1.replaceInFile)(tree, filePath, /\[right\]="false"/gu, `right="NONE"`);
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.html);
        });
    }
    removeObIconModuleForRoot() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObIconModule.forRoot()');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /ObIconModule\.forRoot\(\w*\),?/gu, '');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    migrateScrollToTop() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Migrate scrollTarget.scrollTo({top: 0}) to focusElement("content")');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /scrollTarget\.scrollTo\(\s*\{\s*top\s*:\s*0\s*\}\s*\)/gmu, "focusElement('content')");
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    removeHttpInterceptorModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObHttpApiInterceptorModule');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('ObHttpApiInterceptorModule')) {
                    (0, utils_1.removeImport)(tree, filePath, 'ObHttpApiInterceptorModule', '@oblique/oblique');
                    (0, utils_1.replaceInFile)(tree, filePath, /ObHttpApiInterceptorModule,?/gu, '');
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
}
exports.UpdateV13toV14 = UpdateV13toV14;
