/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV14toV15 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
const utils_2 = require("../utils");
class UpdateV14toV15 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([
            (0, utils_1.warnIfStandalone)(),
            this.removeMaxFavoriteApplications(),
            this.removeMaxLastUsedApplications(),
            this.removeObILocaleDisplay(),
            this.renameIcons(),
            this.removeBrowserAnimationModuleIfUnused(),
            this.fixTestConfig(),
            this.disableZonelessIfAsyncUsed(),
            this.addPrettierrcAngularHtmlParser(),
        ])(tree, context);
    }
    fixTestConfig() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Adapt Jest configuration');
            if ((0, ng_add_utils_1.getDepVersion)(tree, 'jest')) {
                (0, ng_add_utils_1.addDevDependency)(tree, 'jest-environment-jsdom');
                (0, utils_1.replaceInFile)(tree, 'angular.json', /configPath/gu, 'config');
                const tsconfig = (0, utils_1.getJson)(tree, 'tsconfig.spec.json');
                tsconfig.compilerOptions.isolatedModules = true;
                (0, utils_1.writeFile)(tree, 'tsconfig.spec.json', JSON.stringify(tsconfig, null, 2));
            }
            return tree;
        });
    }
    removeBrowserAnimationModuleIfUnused() {
        return (tree) => {
            let useAnimations = false;
            (0, utils_1.applyInTree)(tree, (filePath) => {
                if (/@Component\s*\(\s*\{.*?animations\s*:.*?\}\)/su.test((0, utils_1.readFile)(tree, filePath))) {
                    useAnimations = true;
                }
            }, utils_1.filePatterns.ts);
            return useAnimations ? (0, schematics_1.noop)() : this.removeBrowserAnimationsModule();
        };
    }
    removeBrowserAnimationsModule() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove BrowserAnimationsModule');
            const toApply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('BrowserAnimationsModule')) {
                    (0, utils_1.removeImport)(tree, filePath, 'BrowserAnimationsModule', '@angular/platform-browser/animations');
                    (0, utils_1.replaceInFile)(tree, filePath, /BrowserAnimationsModule,?/gu, '');
                }
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
        });
    }
    renameIcons() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Rename icons');
            const toApply = (filePath) => {
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow_down-left"/g, 'svgIcon="arrow_down_left"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ARROW_DOWN-LEFT/g, 'ObEIcon.ARROW_DOWN_LEFT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow_down-right"/g, 'svgIcon="arrow_down_right"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ARROW_DOWN-RIGHT/g, 'ObEIcon.ARROW_DOWN_RIGHT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow_up-left"/g, 'svgIcon="arrow_up_left"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ARROW_UP-LEFT/g, 'ObEIcon.ARROW_UP_LEFT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="arrow_up-right"/g, 'svgIcon="arrow_up_right"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.ARROW_UP-RIGHT/g, 'ObEIcon.ARROW_UP_RIGHT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_left-small"/g, 'svgIcon="chevron_left_small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_LEFT-SMALL/g, 'ObEIcon.CHEVRON_LEFT_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_double-left"/g, 'svgIcon="chevron_left_double"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_DOUBLE-LEFT/g, 'ObEIcon.CHEVRON_DOUBLE_LEFT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_right-small"/g, 'svgIcon="chevron_right_small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_RIGHT-SMALL/g, 'ObEIcon.CHEVRON_RIGHT_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_double-right"/g, 'svgIcon="chevron_right_double"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_DOUBLE-RIGHT/g, 'ObEIcon.CHEVRON_DOUBLE_RIGHT');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_down-small"/g, 'svgIcon="chevron_down_small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_DOWN-SMALL/g, 'ObEIcon.CHEVRON_DOWN_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="chevron_up-small"/g, 'svgIcon="chevron_up_small"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.CHEVRON_UP-SMALL/g, 'ObEIcon.ACHEVRON_UP_SMALL');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="sort-list_descending"/g, 'svgIcon="sort_list_descending"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.SORT-LIST_DESCENDING/g, 'ObEIcon.SORT_LIST_DESCENDING');
                (0, utils_1.replaceInFile)(tree, filePath, /svgIcon="sort-list_ascending"/g, 'svgIcon="sort_list_ascending"');
                (0, utils_1.replaceInFile)(tree, filePath, /ObEIcon\.SORT-LIST_ASCENDING/g, 'ObEIcon.SORT_LIST_ASCENDING');
            };
            return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.tsAndHtml);
        });
    }
    removeObILocaleDisplay() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove OblLocale.display property');
            const apply = (filePath) => {
                this.removeProperty(tree, filePath, 'locale', 'display');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeMaxFavoriteApplications() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove maxFavoriteApplications property');
            const apply = (filePath) => {
                if (!(0, utils_1.readFile)(tree, filePath).includes('maxFavoriteApplications')) {
                    return;
                }
                this.removeProperty(tree, filePath, 'serviceNavigationConfiguration', 'maxFavoriteApplications');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    removeProperty(tree, fileName, key, property) {
        const content = (0, utils_1.readFile)(tree, fileName);
        const assignmentRegex = (0, utils_2.createPropertyAssignmentRegex)(key, property);
        const objectPropertyRegex = (0, utils_2.createObjectPropertyRegex)(key, property);
        const newContent = content.replace(assignmentRegex, '').replace(objectPropertyRegex, '$<prefix>$<suffix>');
        if (newContent !== content) {
            (0, utils_1.writeFile)(tree, fileName, newContent);
        }
    }
    removeMaxLastUsedApplications() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove maxLastUsedApplications property');
            const apply = (filePath) => {
                this.removeProperty(tree, filePath, 'locale', 'maxLastUsedApplications');
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
    disableZonelessIfAsyncUsed() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            let useAsyncTesting = false;
            (0, utils_1.applyInTree)(tree, (filePath) => {
                const text = tree.readText(filePath);
                const found = text.includes('fakeAsync') || text.includes('waitForAsync');
                if (found) {
                    useAsyncTesting = true;
                }
            }, utils_1.filePatterns.test);
            if (useAsyncTesting) {
                (0, utils_1.infoMigration)(context, 'Disable zoneless for tests');
                (0, utils_1.setOrCreateAngularProjectsConfig)(tree, ['architect', 'test', 'options', 'zoneless'], false);
            }
            return tree;
        });
    }
    addPrettierrcAngularHtmlParser() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Add Angular html parser to .prettierrc if the file exists');
            const prettierrc = (0, utils_1.getJson)(tree, '.prettierrc');
            if (prettierrc) {
                const angularParser = {
                    files: '*.html',
                    options: {
                        parser: 'angular',
                    },
                };
                prettierrc.overrides.push(angularParser);
                (0, utils_1.writeFile)(tree, '.prettierrc', JSON.stringify(prettierrc, null, 2));
            }
            return tree;
        });
    }
}
exports.UpdateV14toV15 = UpdateV14toV15;
