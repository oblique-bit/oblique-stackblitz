/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateV11toV12 = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const utils_1 = require("../utils");
class UpdateV11toV12 {
    dependencies = {};
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    applyMigrations(options) {
        return (tree, context) => (0, schematics_1.chain)([(0, utils_1.checkForStandalone)(), (0, utils_1.checkForSSR)(), this.removeObLanguageService()])(tree, context);
    }
    removeObLanguageService() {
        return (0, utils_1.createSafeRule)((tree, context) => {
            (0, utils_1.infoMigration)(context, 'Remove ObLanguageService');
            const apply = (filePath) => {
                const content = (0, utils_1.readFile)(tree, filePath);
                if (content.includes('ObLanguageService')) {
                    (0, utils_1.removeInjectionInClass)(tree, filePath, 'ObLanguageService', '@oblique/oblique');
                    (0, utils_1.removeServiceMethodCall)(tree, filePath, 'setLocaleOnAdapter');
                }
            };
            return (0, utils_1.applyInTree)(tree, apply, utils_1.filePatterns.ts);
        });
    }
}
exports.UpdateV11toV12 = UpdateV11toV12;
