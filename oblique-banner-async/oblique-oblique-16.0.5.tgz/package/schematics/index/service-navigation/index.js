/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceNavigation = serviceNavigation;
exports.removeHeaderWidgetCode = removeHeaderWidgetCode;
exports.removeEmptyLifecycleHook = removeEmptyLifecycleHook;
exports.removeCode = removeCode;
exports.addProvidersToRootModule = addProvidersToRootModule;
exports.setupImportArray = setupImportArray;
exports.moduleImportAlreadyExists = moduleImportAlreadyExists;
exports.providerAlreadyExists = providerAlreadyExists;
exports.importProviderModules = importProviderModules;
const schematics_1 = require("@angular-devkit/schematics");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const utils_1 = require("../utils");
const ng_add_utils_1 = require("../ng-add/ng-add-utils");
function serviceNavigation() {
    return (tree, context) => (0, schematics_1.chain)([
        addServiceNavigationConfiguration(),
        ...removeHeaderWidgetCode(),
        addProvidersToRootModule([
            {
                providerName: 'OB_PAMS_CONFIGURATION',
                provide: '	{provide: OB_PAMS_CONFIGURATION, useValue: {environment: ObEPamsEnvironment.PROD}}\n',
                additionalImports: ['ObEPamsEnvironment'],
            },
        ]),
        removeEmptyLifecycleHook('ngOnInit'),
        removeEmptyLifecycleHook('ngAfterViewInit'),
    ])(tree, context);
}
function addServiceNavigationConfiguration() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.getRootFilesPaths)(tree)
            .map(project => ({ ...project, templateContent: (0, utils_1.readFile)(tree, project.appComponentTemplatePath) }))
            .map(project => ({ ...project, parameters: extractHeaderWidgetParameters(project.templateContent) }))
            .forEach(({ appModulePath, appComponentPath, parameters }) => {
            parameters.forEach(({ name, value }) => mapParameter(tree, name, value, appModulePath, appComponentPath, context));
        });
        return tree;
    });
}
function extractHeaderWidgetParameters(fileContent) {
    return (/<header-widget(?<parameters>.*?)(?:><\/header-widget|\/)>/s.exec(fileContent)?.groups?.parameters ?? '')
        .replace(/\s+/gs, ' ')
        .trim()
        .split(/(?<=["']) /)
        .map(attribute => attribute.split('='))
        .map(([name, value]) => ({ name: formatKey(name), value: formatValue(value) }));
}
function formatKey(key) {
    return key.replace(/[()[\]]/g, '').replace(/-[a-z]/g, match => match[1].toUpperCase());
}
function formatValue(value) {
    return (value ?? '').replace(/^["']|["']$/g, '');
}
function mapParameter(tree, name, value, appModulePath, appComponentPath, context) {
    switch (name) {
        case 'environment':
            return mapEnvironment(tree, value, appModulePath);
        case 'languageList':
            return addMasterLayoutConfig(tree, 'locale.locales', `['${value.split(',').join("','")}']`, appModulePath);
        case 'defaultLanguage':
            return addMasterLayoutConfig(tree, 'locale.defaultLanguage', `'${value}'`, appModulePath);
        case 'contact':
            return addMasterLayoutConfig(tree, 'header.serviceNavigation.infoContact', value, appModulePath);
        case 'appId':
            return addMasterLayoutConfig(tree, 'header.serviceNavigation.pamsAppId', value, appModulePath);
        case 'showInfo':
            return addWidgetVisibility(tree, 'displayInfo', value, appModulePath);
        case 'showLanguages':
            return addWidgetVisibility(tree, 'displayLanguages', value, appModulePath);
        case 'showNotifications':
            return addWidgetVisibility(tree, 'displayMessage', value, appModulePath);
        case 'showEportalServices':
            return addWidgetVisibility(tree, 'displayApplications', value, appModulePath);
        case 'loginStatus':
            return mapLoginStatus(tree, value, appComponentPath);
        case 'languageChange':
            return mapLanguageChange(tree, value, appComponentPath);
        case 'links':
        case 'profileLinks':
        case 'customButtons':
            (0, utils_1.warn)(context, `"The ${name}" Header Widget parameter couldn't be automatically migrated, you need to process it manually.`);
            return undefined;
        case 'openInNewTab':
        case 'cms':
        case 'showSettings':
            (0, utils_1.warn)(context, `The "${name}" Header Widget parameter doesn't exist with the Service Navigation, it will be removed.`);
            return undefined;
        default:
            (0, utils_1.infoText)(context, `The "${name}" Header Widget parameter is unknown and will be ignored`);
            return undefined;
    }
}
function addMasterLayoutConfig(tree, property, value, appModulePath) {
    (0, utils_1.addInjectionInClass)(tree, appModulePath, 'ObMasterLayoutConfig', '@oblique/oblique');
    (0, utils_1.appendPrivateVoidFunctionToClass)(tree, appModulePath, 'configureServiceNavigation');
    (0, utils_1.addConstructor)(tree, appModulePath);
    (0, utils_1.appendCodeToFunction)(tree, appModulePath, 'constructor', `this.configureServiceNavigation();`);
    (0, utils_1.appendCodeToFunction)(tree, appModulePath, 'configureServiceNavigation', `this.masterLayoutConfig.${property} = ${value};`);
}
function mapEnvironment(tree, value, appModulePath) {
    const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, appModulePath);
    const changes = [
        ...(0, ast_utils_1.addSymbolToNgModuleMetadata)(sourceFile, appModulePath, 'providers', `{provide: OB_PAMS_CONFIGURATION, useValue: {environment: ObEEnvironment.${value}}}`),
        ...(0, ast_utils_1.addImportToModule)(sourceFile, appModulePath, 'OB_PAMS_CONFIGURATION', '@oblique/oblique'),
        ...(0, ast_utils_1.addImportToModule)(sourceFile, appModulePath, 'ObEEnvironment', '@oblique/oblique'),
    ];
    (0, ng_add_utils_1.applyChanges)(tree, appModulePath, changes);
}
function addWidgetVisibility(tree, property, value, appModulePath) {
    return addMasterLayoutConfig(tree, `header.serviceNavigation.${property}`, typeof value === 'boolean' ? value : value === 'true', appModulePath);
}
function mapLoginStatus(tree, value, appComponentPath) {
    (0, utils_1.addInjectionInClass)(tree, appComponentPath, 'ObMasterLayoutService', '@oblique/oblique');
    (0, utils_1.addConstructor)(tree, appComponentPath);
    (0, utils_1.appendCodeToFunction)(tree, appComponentPath, 'constructor', `this.masterLayoutService.header.loginState$.subscribe($event => this.${value})`);
}
function mapLanguageChange(tree, value, appComponentPath) {
    (0, utils_1.addInjectionInClass)(tree, appComponentPath, 'TranslateService', '@ngx-translate/core');
    (0, utils_1.addConstructor)(tree, appComponentPath);
    (0, utils_1.appendCodeToFunction)(tree, appComponentPath, 'constructor', `this.translateService.onLangChange.subscribe(({lang}) => this.${value.replace('$event', 'lang')})`);
}
function removeHeaderWidgetCode() {
    return [
        removeCode(/^\s*<ng-template #obHeaderMobileControl>\s*<header-widget-mobile.*?<\/ng-template>\s*$/gms, '<header-widget-mobile> tags'),
        removeCode(/(?:^\s*<ng-template #obHeaderControl>\s*)?^\s*<header-widget.*(?:<\/header-widget>|\/>)\s*$(?:\s*<\/ng-template>\s*$)?/gms, '<header-widget> tags'),
        removeCode(/\s*(?:const|let)?.*headerWidgetScriptElement.*\s?.*\s?;\s*$/gm, 'headerWidgetScriptElement declaration'),
        removeCode(/\s*headerWidgetScriptElement\.setAttribute\(.*\s?.*\s*\)?;\s*$/gm, 'headerWidgetScriptElement.setAttribute code'),
        removeCode(/\s*document.body.append\(headerWidgetScriptElement\)(?:.*\s?.*\s*)?;\s*$/gm, 'document.body.append of headerWidgetScriptElement'),
        removeCode(/\s*<script.*widget\.eportal<.admin\.ch\/header-widget\.js.*<\/script>\s*/g, 'script tags with script header-widget.js'),
        removeCode(/\s*(?:const|let)?\s?widgetMobile\s*=\s*document\.getElementById\(.widget-mobile.\);\s*$/gm, 'widgetMobile variable by Id widget-mobile'),
        removeCode(/\s*(?:const|let)?.*obliqueHeader\s=\sdocument\.querySelector\(.\.ob-header-controls.\);\s*obliqueHeader\.prepend\(widgetMobile\);\s*$/gm, 'variable obliqueHeader that prepend widgetMobile'),
    ];
}
function removeEmptyLifecycleHook(methodName) {
    const interfaceName = methodName.slice(2, methodName.length);
    return (0, utils_1.createSafeRule)((tree, context) => {
        const methodRegexp = new RegExp(`\\s*(?:public)?\\s*${methodName}\\(\\)(?::\\s*void)?\\s*{\\s*}$`, 'gm');
        const interfaceRegexp = new RegExp(`\\s*${interfaceName},?\\s*`, 'g');
        const toApply = (filePath) => {
            const hasEmptyLifecycleHook = methodRegexp.test((0, utils_1.readFile)(tree, filePath));
            if (hasEmptyLifecycleHook) {
                (0, utils_1.infoMigration)(context, `Remove empty ${methodName} in ${filePath}`);
                (0, utils_1.replaceInFile)(tree, filePath, methodRegexp, '');
                (0, utils_1.replaceInFile)(tree, filePath, interfaceRegexp, '');
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=implements\s*.*),(?={)/, ' ');
                (0, utils_1.replaceInFile)(tree, filePath, /(?<=import\s*.*),(?=})/g, '');
            }
        };
        return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.ts);
    });
}
function removeCode(regex, caseDescription) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        const toApply = (filePath) => {
            if ((0, utils_1.readFile)(tree, filePath).match(regex)) {
                (0, utils_1.infoMigration)(context, `Remove ${caseDescription} in ${filePath}`);
                (0, utils_1.replaceInFile)(tree, filePath, regex, '');
            }
        };
        return (0, utils_1.applyInTree)(tree, toApply, utils_1.filePatterns.tsAndHtml);
    });
}
function addProvidersToRootModule(providers) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        const mainTsPathPerProject = (0, utils_1.getFilePathPerProject)(tree, ['architect', 'build', 'options', 'main']);
        (0, utils_1.getRootModulePathPerProject)(tree, mainTsPathPerProject).forEach(({ path: appModulePath }) => {
            const providerChanges = [];
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, appModulePath);
            const providerImports = [];
            providers.forEach((provider) => {
                if (!providerAlreadyExists(provider.providerName, (0, utils_1.readFile)(tree, appModulePath))) {
                    providerChanges.push(...(0, ast_utils_1.addSymbolToNgModuleMetadata)(sourceFile, appModulePath, 'providers', provider.provide));
                    providerImports.push(...setupImportArray(provider.providerName, tree, appModulePath, provider.additionalImports));
                    (0, utils_1.infoMigration)(context, `Oblique's ServiceNavigation: Adding provider  ${provider.providerName} in ${appModulePath}`);
                }
            });
            const importChanges = importProviderModules(providerImports, sourceFile, appModulePath, context);
            const changes = [...providerChanges, ...importChanges];
            (0, ng_add_utils_1.applyChanges)(tree, appModulePath, changes);
        });
        return tree;
    });
}
function setupImportArray(providerName, tree, appModulePath, additionalImports) {
    const providerImports = [];
    if (additionalImports && additionalImports.length > 0) {
        providerImports.push(...additionalImports);
    }
    providerImports.push(providerName);
    return providerImports.filter(importToAdd => !moduleImportAlreadyExists(importToAdd, (0, utils_1.readFile)(tree, appModulePath)));
}
function moduleImportAlreadyExists(importName, fileContent) {
    const hasImportRegex = new RegExp(`import\\s*{[^}]*${importName}[^}]*}\\s*from\\s*['"]${utils_1.ObliquePackage}['"];`, 'gm');
    return hasImportRegex.test(fileContent);
}
function providerAlreadyExists(providerName, fileContent) {
    const hasProviderRegex = new RegExp(`(?<=providers\\s*:\\s*\\[[^\\]]*)\\b${providerName}\\b(?=[^\\]]*])`, 'gm');
    return hasProviderRegex.test(fileContent);
}
function importProviderModules(importModuleNames, sourceFile, appModulePath, context) {
    return importModuleNames.map(providerModule => {
        (0, utils_1.infoMigration)(context, `Oblique's ServiceNavigation: Adding import ${providerModule} in ${appModulePath}`);
        return (0, ast_utils_1.insertImport)(sourceFile, appModulePath, providerModule, utils_1.ObliquePackage);
    });
}
