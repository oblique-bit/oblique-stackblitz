/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSuccessful = exports.filePatterns = exports.ObliquePackage = exports.packageJsonConfigPath = void 0;
exports.error = error;
exports.infoText = infoText;
exports.infoMigration = infoMigration;
exports.success = success;
exports.warn = warn;
exports.createSafeRule = createSafeRule;
exports.checkForStandalone = checkForStandalone;
exports.warnIfStandalone = warnIfStandalone;
exports.checkForSSR = checkForSSR;
exports.infoHighlights = infoHighlights;
exports.readFile = readFile;
exports.addFile = addFile;
exports.writeFile = writeFile;
exports.deleteFile = deleteFile;
exports.replaceInFile = replaceInFile;
exports.getJson = getJson;
exports.getAngularConfigs = getAngularConfigs;
exports.getAngularProjectsWithConfigs = getAngularProjectsWithConfigs;
exports.checkIfAngularConfigExists = checkIfAngularConfigExists;
exports.overwriteIndexFile = overwriteIndexFile;
exports.setRootAngularConfig = setRootAngularConfig;
exports.setAngularConfig = setAngularConfig;
exports.setAngularProjectsConfig = setAngularProjectsConfig;
exports.setOrCreateAngularProjectsConfig = setOrCreateAngularProjectsConfig;
exports.addAngularConfigInList = addAngularConfigInList;
exports.includeAngularConfigInList = includeAngularConfigInList;
exports.removeAngularProjectsConfig = removeAngularProjectsConfig;
exports.installDependencies = installDependencies;
exports.applyInTree = applyInTree;
exports.addInterface = addInterface;
exports.addImport = addImport;
exports.removeImport = removeImport;
exports.getIndexPaths = getIndexPaths;
exports.addTsCompilerOption = addTsCompilerOption;
exports.getPackageJsonPath = getPackageJsonPath;
exports.getFilePathPerProject = getFilePathPerProject;
exports.getRootModulePathPerProject = getRootModulePathPerProject;
exports.getRootFilesPaths = getRootFilesPaths;
exports.getProjectList = getProjectList;
exports.removeHtmlTagAttribute = removeHtmlTagAttribute;
exports.addInjectionInClass = addInjectionInClass;
exports.appendPrivateVoidFunctionToClass = appendPrivateVoidFunctionToClass;
exports.appendCodeToFunction = appendCodeToFunction;
exports.addConstructor = addConstructor;
exports.createPropertyAssignmentRegex = createPropertyAssignmentRegex;
exports.createObjectPropertyRegex = createObjectPropertyRegex;
exports.removeInjectionInClass = removeInjectionInClass;
exports.removeServiceMethodCall = removeServiceMethodCall;
const tasks_1 = require("@angular-devkit/schematics/tasks");
const colors = __importStar(require("ansi-colors"));
const ng_add_utils_1 = require("./ng-add/ng-add-utils");
const glob_1 = require("glob");
exports.packageJsonConfigPath = '/package.json';
exports.ObliquePackage = '@oblique/oblique';
exports.filePatterns = {
    ts: '*.ts',
    test: '*.spec.ts',
    html: '*.html',
    scss: '*.scss',
    scssAndCss: '*.{css,scss}',
    tsAndHtml: '*.{ts,html}',
    appModule: '{app{-,.}module,main}.ts',
};
const angularJsonConfigPath = './angular.json/';
exports.isSuccessful = true;
function error(msg) {
    throw new Error(`${colors.symbols.cross} Migration failed: ${msg}\n`);
}
function infoText(context, msg) {
    context.logger.info(colors.cyanBright(`\n${colors.symbols.info} ${msg}\n`));
}
function infoMigration(context, msg) {
    context.logger.info(`${colors.symbols.pointer} ${msg}`);
}
function success(context, msg) {
    context.logger.info(colors.greenBright(`\n${colors.symbols.check} ${msg}\n`));
}
function warn(context, msg) {
    context.logger.info(colors.yellowBright(`\n${colors.symbols.warning} ${msg}\n`));
}
function createSafeRule(callback) {
    return (tree, context) => {
        try {
            return callback(tree, context);
        }
        catch (thrownError) {
            exports.isSuccessful = false;
            const { message, file, line } = getErrorInfo(thrownError);
            warn(context, `The previous task failed and the change needs to be done manually.\nPlease inform the Oblique team (oblique@bit.admin.ch) of the following error:\n\t${message}${file ? `\n\tfile: "${file}"` : ''}${line ? `\n\tline: "${line}"` : ''}`);
            return tree;
        }
    };
}
function getErrorInfo(thrownError) {
    if (thrownError instanceof Error) {
        const { file, line } = /@oblique[/\\]oblique[/\\]schematics[/\\].*[/\\](?<file>\w*\.js):(?<line>\d*)/.exec(thrownError.stack || '')
            ?.groups || {};
        return {
            message: thrownError.message,
            file,
            line,
        };
    }
    if (typeof thrownError === 'string') {
        return { message: thrownError, file: '', line: '' };
    }
    return { message: 'Unknown error', file: '', line: '' };
}
function checkForStandalone() {
    return (tree, context) => {
        infoMigration(context, 'Check if application is standalone ');
        const apply = (filePath) => {
            const standalone = isStandalone(tree, filePath);
            if (standalone) {
                error('Standalone application detected. Oblique schematics are not compatible with standalone applications. Either convert the application to non-standalone or perform the changes manually. Check the documentation for guidance.');
            }
        };
        return applyInTree(tree, apply, exports.filePatterns.ts);
    };
}
function warnIfStandalone() {
    return (tree, context) => {
        let standaloneDetected = false;
        applyInTree(tree, (filePath) => {
            const standalone = isStandalone(tree, filePath);
            if (standalone) {
                standaloneDetected = true;
            }
        }, exports.filePatterns.ts);
        if (standaloneDetected) {
            warn(context, 'Standalone application detected, the migration has only been partially applied and the application is currently broken. Please check manually the changes applied by the schematic.');
        }
    };
}
function checkForSSR() {
    return (tree, context) => {
        infoMigration(context, 'Check if application uses SSR');
        if (getAngularConfigs(tree, ['architect', 'build', 'options', 'ssr', 'entry']).length) {
            error('SSR application detected. Oblique is not yet compatible with SSR applications. SSR needs to be deactivated.');
        }
    };
}
function infoHighlights(context, msg, ...highlights) {
    const message = highlights.reduce((text, highlight) => text.replace('%c', colors.bold(highlight)), msg);
    context.logger.info(`${message}\n`);
}
function readFile(tree, fileName) {
    const src = tree.read(fileName);
    return src ? src.toString() : '';
}
function addFile(tree, fileName, content) {
    if (!tree.exists(fileName) && content) {
        tree.create(fileName, content);
    }
}
function writeFile(tree, fileName, content) {
    if (content) {
        if (tree.exists(fileName) && content) {
            tree.overwrite(fileName, content);
        }
        else {
            tree.create(fileName, content);
        }
    }
}
function deleteFile(tree, fileName) {
    if (tree.exists(fileName)) {
        tree.delete(fileName);
    }
    return tree;
}
function replaceInFile(tree, path, pattern, replacement) {
    tree.overwrite(path, readFile(tree, path).replace(pattern, replacement));
}
function getJson(tree, path) {
    const json = readFile(tree, path);
    return json ? JSON.parse(json.toString()) : undefined;
}
function getAngularConfigs(tree, path) {
    return getAngularProjectsWithConfigs(tree, path).filter(project => project.config);
}
function getAngularProjectsWithConfigs(tree, path) {
    const json = getJson(tree, angularJsonConfigPath);
    return Object.keys(getJsonProperty(json, 'projects')).reduce((config, project) => [
        ...config,
        {
            project,
            config: getJsonProperty(json, ['projects', project, ...path].join(';')),
        },
    ], []);
}
function checkIfAngularConfigExists(tree, path, config) {
    return getAngularConfigs(tree, path).reduce((exists, conf) => exists || conf.config === config, false);
}
function overwriteIndexFile(indexPath, tree, searchValue, replaceValue = (0, ng_add_utils_1.getTemplate)(tree, 'default-index.html')) {
    if (!indexPath || !tree.exists(indexPath)) {
        indexPath = './index.html';
    }
    if (tree.exists(indexPath)) {
        tree.overwrite(indexPath, readFile(tree, indexPath).replace(searchValue, replaceValue));
    }
}
function setRootAngularConfig(tree, path, value) {
    const json = getJson(tree, angularJsonConfigPath);
    setOption(json, path, value);
    tree.overwrite(angularJsonConfigPath, JSON.stringify(json, null, 2));
    return tree;
}
function setAngularConfig(tree, path, value) {
    return alterAngularConfig(tree, path, value.project, value.config);
}
function setAngularProjectsConfig(tree, path, config) {
    getAngularConfigs(tree, path).forEach(project => {
        setAngularConfig(tree, path, {
            project: project.project,
            config: config instanceof Function ? config(project.config) : config,
        });
    });
    return tree;
}
function setOrCreateAngularProjectsConfig(tree, path, config) {
    getAngularProjectsWithConfigs(tree, path).forEach(project => {
        setAngularConfig(tree, path, {
            project: project.project,
            config: config instanceof Function ? config(project.config) : config,
        });
    });
    return tree;
}
function addAngularConfigInList(tree, path, value) {
    getAngularConfigs(tree, path).forEach(project => {
        setAngularConfig(tree, path, {
            project: project.project,
            config: [...(project.config || []).filter((current) => current !== value), value],
        });
    });
    return tree;
}
function includeAngularConfigInList(tree, path, value) {
    getProjectList(tree).forEach(project => {
        setAngularConfig(tree, path, {
            project,
            config: [value],
        });
    });
    return tree;
}
function removeAngularProjectsConfig(tree, path) {
    getAngularConfigs(tree, path).forEach(project => {
        removeAngularConfig(tree, path, project.project);
    });
    return tree;
}
function installDependencies() {
    return createSafeRule((tree, context) => {
        context.addTask(new tasks_1.NodePackageInstallTask());
        context.logger.debug('Dependencies installed');
        return tree;
    });
}
function applyInTree(tree, toApply, pattern = '*') {
    getAngularConfigs(tree, ['sourceRoot'])
        .map(project => project.config)
        .reduce((files, root) => [...files, ...(0, glob_1.globSync)(`${root}/**/${pattern}`, {})], [])
        .forEach((file) => toApply(file));
    return tree;
}
function addInterface(tree, fileName, name) {
    const content = readFile(tree, fileName);
    if (!new RegExp(`export class\\s*\\w*\\s*implements.*${name}`, 'm').test(content)) {
        tree.overwrite(fileName, content
            .replace(/(?<classDef>export class\s*\w*(?:\s*extends \w*)?)(?:\s*implements\s*)?(?<implements>\w*(?:,\s*\w*)*)\s*{/, `$<classDef> implements $<implements>, ${name} {`)
            .replace('implements ,', 'implements'));
    }
}
function addImport(tree, fileName, name, pkg) {
    const content = readFile(tree, fileName);
    const updatedContent = updateImportSpecifiers(content, pkg, specifiers => ({
        affectedSpecifiers: [],
        specifiers: addImportSpecifier(specifiers, name),
    })).content;
    if (updatedContent !== content) {
        tree.overwrite(fileName, updatedContent);
    }
}
function removeImport(tree, fileName, name, pkg) {
    const content = readFile(tree, fileName);
    const { affectedSpecifiers, content: updatedContent } = updateImportSpecifiers(content, pkg, specifiers => removeImportSpecifier(specifiers, name));
    if (updatedContent !== content) {
        tree.overwrite(fileName, updatedContent);
    }
    return affectedSpecifiers;
}
function getIndexPaths(tree) {
    const index = getDefaultAngularConfig(tree, ['architect', 'build', 'options', 'index']);
    const result = index
        ? [index]
        : getAngularConfigs(tree, ['architect', 'build', 'options', 'index']).map(project => project.config);
    return result.length > 0 ? result : ['src/index.html'];
}
function getDefaultAngularConfig(tree, path) {
    const json = getJson(tree, angularJsonConfigPath);
    const defaultProjectName = getJsonProperty(json, 'defaultProject');
    return defaultProjectName ? getJsonProperty(json, ['projects', defaultProjectName, ...path].join(';')) : null;
}
function addTsCompilerOption(content, option) {
    if (new RegExp(`"${option}"\\s*:\\s*true`).test(content)) {
        return content;
    }
    if (new RegExp(`"${option}"\\s*:\\s*false`).test(content)) {
        return content.replace(new RegExp(`(?<="${option}"\\s*:\\s*)false`), 'true');
    }
    if (content.includes('compilerOptions')) {
        return content.replace(/(?<=compilerOptions"\s*:\s*{)(?<whitespace>\s*)/, `$<whitespace>"${option}": true,$<whitespace>`);
    }
    return content.replace(/(?<={)(?<whitespace>\s*)/, `$<whitespace>"compilerOptions": {$<whitespace>  "${option}": true}$<whitespace>},$<whitespace>`);
}
function getPackageJsonPath(tree, project) {
    const sourceRoot = getAngularConfigs(tree, ['sourceRoot']).find(config => config.project === project)?.config;
    const depth = sourceRoot?.match(/\//g) || [];
    return depth.reduce(path => `../${path}`, '../package.json');
}
function getFilePathPerProject(tree, property) {
    return getAngularConfigs(tree, property)
        .map(config => ({ project: config.project, path: config.config }))
        .filter(config => !!config.path && tree.exists(config.path));
}
function getRootModulePathPerProject(tree, mainTsPaths) {
    return mainTsPaths
        .map(file => ({ ...file, directory: extractDirectoryFromPath(file.path) }))
        .map(file => ({ ...file, content: readFile(tree, file.path) }))
        .map(file => ({ ...file, rootModule: extractBootstrappedModule(file.content) }))
        .filter(file => !!file.rootModule)
        .map(file => ({ ...file, rootModulePath: extractRootModulePath(file.rootModule, file.content) }))
        .filter(file => !!file.rootModulePath)
        .map(file => ({ ...file, rootModulePath: addFileExtension(file.rootModulePath) }))
        .map(file => ({ ...file, rootModulePath: addRelativePath(file.rootModulePath, file.directory) }))
        .filter(file => tree.exists(file.rootModulePath))
        .map(file => ({ project: file.project, path: file.rootModulePath }));
}
function getRootFilesPaths(tree) {
    const mainTsPathPerProject = getFilePathPerProject(tree, ['architect', 'build', 'options', 'main']);
    return getRootModulePathPerProject(tree, mainTsPathPerProject)
        .map(project => ({ ...project, content: readFile(tree, project.path) }))
        .map(project => ({ ...project, componentName: extractBootstrappedComponent(project.content) }))
        .map(project => ({ ...project, componentPath: extractComponentPath(project.componentName, project.content) }))
        .map(project => ({ ...project, componentPath: mergePaths(project.path, project.componentPath) }))
        .map(project => ({ ...project, content: readFile(tree, project.componentPath) }))
        .map(project => ({ ...project, templatePath: extractTemplatePath(project.content) }))
        .map(project => ({
        projectName: project.project,
        appModulePath: project.path,
        appComponentPath: project.componentPath,
        appComponentTemplatePath: mergePaths(project.componentPath, project.templatePath),
    }));
}
function getProjectList(tree) {
    const json = getJson(tree, angularJsonConfigPath);
    return Object.keys(getJsonProperty(json, 'projects'));
}
function removeHtmlTagAttribute(tree, fileName, tagName, attributeName) {
    tree.overwrite(fileName, readFile(tree, fileName).replace(new RegExp(`(?<=<${tagName}.+)\\s*\\[?${attributeName}\\]?(?:=["']{1,2}.*?["']{1,2})?`, 'gs'), ''));
}
function addInjectionInClass(tree, filePath, token, pkg) {
    if (!new RegExp(`inject\\(\\s*${token}\\s*\\)`).test(readFile(tree, filePath))) {
        let name = token.replace('Ob', '');
        name = name[0].toLowerCase() + name.substring(1);
        addImport(tree, filePath, token, pkg);
        addImport(tree, filePath, 'inject', '@angular/core');
        replaceInFile(tree, filePath, /(?<indent>[^\S\r\n]+)(?<!(?:new|get|set|=)\s*)(?=\w+\()/, `$<indent>private readonly ${name} = inject(${token});\n\n$<indent>`);
    }
}
function appendPrivateVoidFunctionToClass(tree, filePath, code) {
    const fileContent = readFile(tree, filePath);
    if (!fileContent.includes(code)) {
        const indent = /class.*?{(?<indent>\s*)/.exec(fileContent)?.groups?.indent ?? '\n';
        tree.overwrite(filePath, fileContent.replace(/(?=}\s*$)/, `${indent}private ${code}(): void {${indent}}\n`));
    }
}
function appendCodeToFunction(tree, filePath, functionName, code) {
    const fileContent = readFile(tree, filePath);
    if (!fileContent.includes(code)) {
        tree.overwrite(filePath, fileContent.replace(new RegExp(`(?<=${functionName}\\s*\\(.*?\\)(?:\\s*:\\s*\\w+)?\\s*\\{.*?)(?=}(?![;)]))`, 's'), `\t${code}\n\t`));
    }
}
function addConstructor(tree, filePath) {
    const fileContent = readFile(tree, filePath);
    if (!fileContent.includes('constructor')) {
        tree.overwrite(filePath, fileContent.replace(/(?<indent>\s+)(?<!(?:new|get|set|=)\s*)(?=[\s\w]+\()/, `$<indent>constructor() {}$<indent>`));
    }
}
function createPropertyAssignmentRegex(key, property) {
    return new RegExp(String.raw `^[^\n]*(?:\[[\x60'"])?${key}(?:[\x60'"]\])?(?:\[[\x60'"]|\.)${property}(?:[\x60'"]\])?\s*=\s*[^;\n]+;?;`, 'gmu');
}
function createObjectPropertyRegex(key, property) {
    return new RegExp(String.raw `^(?<prefix>[^\n]*${key}\s*=\s*\{[^\n]*?)(?:(?:\s*,\s*${property}\s*:\s*[^,}]+)|(?:\s*${property}\s*:\s*[^,}]+\s*,?))(?<suffix>[^\n]*)`, 'mu');
}
function removeInjectionInClass(tree, filePath, token, pkg) {
    removeInjectionFromInject(tree, filePath, token);
    removeInjectionFromConstructor(tree, filePath, token);
    removeImport(tree, filePath, token, pkg);
}
function removeInjectionFromConstructor(tree, filePath, token) {
    replaceInFile(tree, filePath, new RegExp(`(?<=constructor.*?)[\\w\\s]+\\s*:\\s*${token},?`, 's'), '');
    removeEmptyConstructor(tree, filePath);
}
function removeEmptyConstructor(tree, filePath) {
    replaceInFile(tree, filePath, /constructor\s*\(\s*\)\s*\{\s*}/, '');
}
function removeInjectionFromInject(tree, filePath, token) {
    replaceInFile(tree, filePath, new RegExp(`[\\w\\s]*(?::\\s*${token})?\\s*=\\s*inject\\(\\s*${token}\\s*\\)\\s*;\n?`), '');
}
function removeServiceMethodCall(tree, filePath, methodToken) {
    replaceInFile(tree, filePath, new RegExp(`\\w*\\.(?:${methodToken})\\s*\\(\\w+\\)\\s*;\\s*`, 'g'), '');
}
function extractDirectoryFromPath(filePath) {
    return /(?<directory>.*)\//.exec(filePath)?.groups?.directory ?? '';
}
function extractBootstrappedModule(fileContent) {
    return /bootstrapModule\(\s*(?<rootModule>\w*)\s*\)/.exec(fileContent)?.groups?.rootModule ?? '';
}
function extractRootModulePath(moduleName, fileContent) {
    return (RegExp(`import\\s*{\\s*${moduleName}\\s*}\\s*from\\s*["'](?<rootModulePath>.*)["']`).exec(fileContent)?.groups
        ?.rootModulePath ?? '');
}
function addFileExtension(filePath) {
    return /.ts$/m.test(filePath) ? filePath : `${filePath}.ts`;
}
function addRelativePath(filePath, directory) {
    return /^\./m.test(filePath) ? filePath.replace('.', directory) : filePath;
}
function updateImportSpecifiers(content, pkg, updateSpecifiers) {
    const importRegex = createNamedImportRegex(pkg);
    const existingSpecifiers = [];
    let hasMatchingImport = false;
    let insertedPlaceholder = false;
    const updatedContent = content.replace(importRegex, (match, ...args) => {
        const groups = args.at(-1);
        hasMatchingImport = true;
        existingSpecifiers.push(...parseNamedImportSpecifiers(groups.specifiers, groups.importType ?? ''));
        if (insertedPlaceholder) {
            return '';
        }
        insertedPlaceholder = true;
        return '__OBLIQUE_IMPORT_PLACEHOLDER__';
    });
    const { affectedSpecifiers, specifiers } = updateSpecifiers(existingSpecifiers);
    const normalizedExistingSpecifiers = deduplicateImportSpecifiers(existingSpecifiers);
    const normalizedNextSpecifiers = deduplicateImportSpecifiers(specifiers);
    if (!hasMatchingImport && !specifiers.length && !affectedSpecifiers.length) {
        return { affectedSpecifiers, content };
    }
    if (!affectedSpecifiers.length &&
        normalizedExistingSpecifiers.length === normalizedNextSpecifiers.length &&
        normalizedExistingSpecifiers.every((specifier, index) => specifier === normalizedNextSpecifiers[index])) {
        return { affectedSpecifiers, content };
    }
    const importDeclaration = normalizedNextSpecifiers.length
        ? createImportDeclaration(normalizedNextSpecifiers, pkg)
        : '';
    let contentWithUpdatedImport = updatedContent;
    if (insertedPlaceholder) {
        contentWithUpdatedImport = updatedContent.replace('__OBLIQUE_IMPORT_PLACEHOLDER__', importDeclaration);
    }
    else if (importDeclaration) {
        contentWithUpdatedImport = insertImportDeclaration(updatedContent, importDeclaration);
    }
    return {
        affectedSpecifiers,
        content: normalizeImportWhitespace(contentWithUpdatedImport),
    };
}
function parseNamedImportSpecifiers(specifiers, importType) {
    const parsedSpecifiers = specifiers
        .split(',')
        .map(specifier => specifier.trim())
        .filter(Boolean);
    if (importType) {
        return parsedSpecifiers.map(specifier => (specifier.startsWith('type ') ? specifier : `type ${specifier}`));
    }
    return parsedSpecifiers;
}
function addImportSpecifier(specifiers, name) {
    const normalizedName = normalizeImportSpecifier(name);
    const matchingSpecifier = specifiers.find(specifier => isSameImportBinding(specifier, normalizedName));
    if (specifiers.some(specifier => normalizeImportSpecifier(specifier) === normalizedName)) {
        return specifiers;
    }
    if (matchingSpecifier) {
        return !isTypeOnlyImportSpecifier(normalizedName) && isTypeOnlyImportSpecifier(matchingSpecifier)
            ? specifiers.map(specifier => isSameImportBinding(specifier, normalizedName) ? removeTypeFromImportSpecifier(normalizedName) : specifier)
            : specifiers;
    }
    return !hasImportAlias(normalizedName) &&
        specifiers.some(specifier => getImportedSpecifierName(specifier) === getImportedSpecifierName(normalizedName))
        ? specifiers
        : [...specifiers, normalizedName];
}
function getImportedSpecifierName(specifier) {
    return removeTypeFromImportSpecifier(specifier)
        .split(/\s+as\s+/u)[0]
        .trim();
}
function getLocalSpecifierName(specifier) {
    return (removeTypeFromImportSpecifier(specifier)
        .split(/\s+as\s+/u)[1]
        ?.trim() ?? getImportedSpecifierName(specifier));
}
function removeImportSpecifier(specifiers, name) {
    const normalizedName = normalizeImportSpecifier(name);
    const affectedSpecifiers = specifiers.filter(specifier => normalizeImportSpecifier(specifier) === normalizedName ||
        isSameImportBinding(specifier, normalizedName) ||
        (!hasImportAlias(normalizedName) &&
            getImportedSpecifierName(specifier) === getImportedSpecifierName(normalizedName)));
    return {
        affectedSpecifiers: affectedSpecifiers.map(normalizeImportSpecifier),
        specifiers: specifiers.filter(specifier => !affectedSpecifiers.includes(normalizeImportSpecifier(specifier))),
    };
}
function deduplicateImportSpecifiers(specifiers) {
    return [...new Set(specifiers.map(normalizeImportSpecifier))];
}
function createImportDeclaration(specifiers, pkg) {
    return `import {${specifiers.join(', ')}} from '${pkg}';`;
}
function insertImportDeclaration(content, importDeclaration) {
    const declaration = `${importDeclaration}\n`;
    const allImports = [...content.matchAll(/import[\s\S]*?from\s*['"][^'"]+['"]\s*;?/g)];
    if (allImports.length) {
        const lastImport = allImports.at(-1);
        const insertionIndex = (lastImport?.index ?? 0) + (lastImport?.[0].length ?? 0);
        return `${content.slice(0, insertionIndex)}\n${declaration}${content.slice(insertionIndex)}`;
    }
    return `${declaration}${content}`;
}
function createNamedImportRegex(pkg) {
    return new RegExp(`import(?<importType>\\s+type)?\\s*{(?<specifiers>[^}]*)}\\s*from\\s*['"]${escapeRegExp(pkg)}['"]\\s*;?`, 'g');
}
function normalizeImportSpecifier(specifier) {
    return specifier.replace(/\s+/g, ' ').trim();
}
function isSameImportBinding(firstSpecifier, secondSpecifier) {
    return (getImportedSpecifierName(firstSpecifier) === getImportedSpecifierName(secondSpecifier) &&
        getLocalSpecifierName(firstSpecifier) === getLocalSpecifierName(secondSpecifier));
}
function hasImportAlias(specifier) {
    return getImportedSpecifierName(specifier) !== getLocalSpecifierName(specifier);
}
function isTypeOnlyImportSpecifier(specifier) {
    return normalizeImportSpecifier(specifier).startsWith('type ');
}
function removeTypeFromImportSpecifier(specifier) {
    return normalizeImportSpecifier(specifier).replace(/^type\s+/u, '');
}
function normalizeImportWhitespace(content) {
    return content.replace(/^\n+/u, '').replace(/\n{3,}/g, '\n\n');
}
function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function getJsonProperty(json, propertyPath) {
    return propertyPath.split(';').reduce((obj, property) => (obj ? obj[property] : undefined), json);
}
function removeAngularConfig(tree, path, project) {
    return alterAngularConfig(tree, path, project);
}
function alterAngularConfig(tree, path, project, value) {
    const json = getJson(tree, angularJsonConfigPath);
    setOption(json, ['projects', project, ...path], value);
    tree.overwrite(angularJsonConfigPath, JSON.stringify(json, null, 2));
    return tree;
}
function setOption(json, path, value) {
    const option = path.shift();
    if (option) {
        if (path.length) {
            if (!json[option]) {
                json[option] = {};
            }
            setOption(json[option], path, value);
        }
        else if (value !== undefined && value !== null) {
            json[option] = value;
        }
        else {
            delete json[option];
        }
    }
}
function mergePaths(basePath, filePath) {
    let depth = 0;
    while (filePath.startsWith('../')) {
        filePath.replace('../', '');
        depth++;
    }
    return [...basePath.split('/').slice(0, -(depth + 1)), ...filePath.replace('./', '').split('/')].join('/');
}
function extractBootstrappedComponent(fileContent) {
    return /bootstrap\s*:\s*\[\s*(?<appComponent>\w*)\s*]/s.exec(fileContent)?.groups?.appComponent ?? '';
}
function extractComponentPath(componentName, fileContent) {
    const filePath = new RegExp(`import\\s+{\\s*${componentName}\\s*}\\s*from\\s*['"](?<path>.*?)['"]`, 's').exec(fileContent)?.groups
        ?.path ?? '';
    return addFileExtension(filePath);
}
function extractTemplatePath(fileContent) {
    return /templateUrl\s*:\s*['"](?<templatePath>.*?)['"]/s.exec(fileContent)?.groups?.templatePath ?? '';
}
function isStandalone(tree, filePath) {
    return /standalone\s*:\s*true/.test(readFile(tree, filePath));
}
