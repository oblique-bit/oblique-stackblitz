/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addOblique = addOblique;
const schematics_1 = require("@angular-devkit/schematics");
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const ng_add_utils_1 = require("./ng-add-utils");
const utils_1 = require("../utils");
const obliqueFeatures_1 = require("./rules/obliqueFeatures");
const toolchain_1 = require("./rules/toolchain");
const oblique_1 = require("./rules/oblique");
function addOblique(options) {
    return (tree, context) => (0, schematics_1.chain)([
        (0, utils_1.checkForStandalone)(),
        (0, ng_add_utils_1.checkForMultiProject)(),
        (0, utils_1.checkForSSR)(),
        preconditions(),
        (0, oblique_1.oblique)(),
        (0, obliqueFeatures_1.obliqueFeatures)(options),
        (0, toolchain_1.toolchain)(options),
        (0, utils_1.installDependencies)(),
        finalize(options),
    ])(tree, context);
}
function preconditions() {
    return (tree, context) => {
        (0, utils_1.infoText)(context, 'Executing migrations of package "@oblique/oblique"');
        (0, ng_add_utils_1.checkPrecondition)(tree, '@angular/core');
        (0, ng_add_utils_1.checkPrecondition)(tree, '@angular/router');
        checkRequiredDependencies(tree, context);
        installMissingDependencies(tree, context, ['@popperjs/core', 'angular-oauth2-oidc']);
        return tree;
    };
}
function checkRequiredDependencies(tree, context) {
    (0, utils_1.infoText)(context, 'Oblique: check required dependencies');
    const errors = [
        {
            name: '@angular/material',
            type: dependencies_1.NodeDependencyType.Default,
        },
        {
            name: '@angular/cdk',
            type: dependencies_1.NodeDependencyType.Default,
        },
        {
            name: '@oblique/toolchain',
            type: dependencies_1.NodeDependencyType.Dev,
        },
    ]
        .map(dep => {
        if (!(0, ng_add_utils_1.hasDependency)(tree, dep)) {
            return `\tDependency "${dep.name}" of type "${dep.type}" is required. Please install it and execute the schematics again.`;
        }
        return null;
    })
        .filter(errorMessage => errorMessage);
    if (errors.length > 0) {
        (0, utils_1.error)(['\n', ...errors].join('\n'));
    }
}
function installMissingDependencies(tree, context, dependencies) {
    dependencies
        .filter(dependency => (0, ng_add_utils_1.getPreconditionVersion)(tree, dependency))
        .forEach(dependency => {
        (0, utils_1.infoMigration)(context, `Installing missing peer dependency "${dependency}"`);
        (0, ng_add_utils_1.addDependency)(tree, dependency);
    });
}
function finalize(options) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (utils_1.isSuccessful) {
            (0, utils_1.success)(context, 'Oblique has been successfully integrated. Please review the changes.');
        }
        else {
            (0, utils_1.warn)(context, 'Oblique has only been partially integrated. Please check for warnings in the console and review the changes.');
        }
        if (options.husky) {
            (0, utils_1.infoText)(context, 'Please run "npm prepare" to finalize Husky installation.');
        }
        return tree;
    });
}
