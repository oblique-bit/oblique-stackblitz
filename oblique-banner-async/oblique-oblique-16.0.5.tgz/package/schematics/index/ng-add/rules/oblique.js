/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.oblique = oblique;
const schematics_1 = require("@angular-devkit/schematics");
const ng_add_utils_1 = require("../ng-add-utils");
const utils_1 = require("../../utils");
function oblique() {
    return (tree, context) => (0, schematics_1.chain)([
        addAdditionalModules(),
        addFeatureDetection(),
        addMainCSS(),
        addLocalAssets(),
        addObliqueAssets(),
        addFontFiles(),
        raiseBuildBudget(),
    ])(tree, context);
}
function addAdditionalModules() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique: Add ObButtonModule');
        (0, ng_add_utils_1.importModuleInRoot)(tree, 'ObButtonModule', utils_1.ObliquePackage);
        addComment(tree);
        return tree;
    });
}
function addFeatureDetection() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique: Adding browser compatibility check');
        (0, utils_1.getIndexPaths)(tree).forEach((indexPath) => (0, utils_1.overwriteIndexFile)(indexPath, tree, /<body>(?<lineBreak>\r?\n)/, `<body>$<lineBreak>${(0, ng_add_utils_1.getTemplate)(tree, 'default-index.html')}`));
        return (0, utils_1.includeAngularConfigInList)(tree, ['architect', 'build', 'options', 'scripts'], 'node_modules/@oblique/oblique/ob-features.js');
    });
}
function addMainCSS() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique: Adding main CSS');
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'styles'], (config) => {
            const index = config.indexOf(ng_add_utils_1.obliqueCssPath.replace('css/oblique-core.css', 'scss/oblique-core.scss'));
            if (index > -1) {
                config[index] = config[index].replace('scss/oblique-core.scss', 'css/oblique-core.css');
            }
            if (!config.includes(ng_add_utils_1.obliqueCssPath)) {
                config.unshift(ng_add_utils_1.obliqueCssPath);
            }
            return config;
        });
    });
}
function addLocalAssets() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique: Adding local assets');
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => [
            'src/assets',
            ...config,
        ]);
    });
}
function addObliqueAssets() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique: Adding assets');
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => [
            {
                glob: '**/*',
                input: 'node_modules/@oblique/oblique/assets',
                output: 'assets',
            },
            ...config,
        ]);
    });
}
function addFontFiles() {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => {
            config.splice(1, 0, {
                glob: '*/**',
                input: 'node_modules/@oblique/oblique/styles/fonts',
                output: 'assets/fonts',
            });
            return config;
        });
        return tree;
    });
}
function addComment(tree) {
    const appModuleContent = (0, utils_1.readFile)(tree, ng_add_utils_1.appModulePath);
    tree.overwrite(ng_add_utils_1.appModulePath, appModuleContent.replace(/ObButtonModule,\n/, 'ObButtonModule, // add other Oblique modules as needed\n'));
}
function raiseBuildBudget() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Raise build budget in angular.json');
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'configurations', 'production', 'budgets'], [
            {
                type: 'initial',
                maximumWarning: '1.7mb',
                maximumError: '2mb',
            },
            {
                type: 'anyComponentStyle',
                maximumWarning: '3kb',
                maximumError: '4kb',
            },
        ]);
    });
}
