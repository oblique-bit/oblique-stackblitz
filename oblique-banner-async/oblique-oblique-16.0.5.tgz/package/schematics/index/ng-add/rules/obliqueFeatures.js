/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obliqueFeatures = obliqueFeatures;
const schematics_1 = require("@angular-devkit/schematics");
const change_1 = require("@schematics/angular/utility/change");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const ng_add_utils_1 = require("../ng-add-utils");
const utils_1 = require("../../utils");
function obliqueFeatures(options) {
    return (tree, context) => {
        return (0, schematics_1.chain)([
            addObliqueProviders(),
            addAjv(options.ajv),
            addUnknownRoute(options.unknownRoute),
            enableAnchorScrolling(),
            addInterceptors(options.httpInterceptors),
            addBanner(options.banner, options.environments),
            addDefaultHomeComponent(options.prefix),
            addExternalLink(options.externalLink),
            setObliqueConfiguration(options.title, options.applicationOperator, options.contact, options.hasLanguageInUrl),
        ])(tree, context);
    };
}
function addObliqueProviders() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique feature: Adding Oblique configuration');
        const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
        const changes = (0, ast_utils_1.addProviderToModule)(sourceFile, ng_add_utils_1.appModulePath, 'provideObliqueConfiguration()', '@oblique/oblique')
            .filter((change) => change instanceof change_1.InsertChange)
            .map((change) => (0, ng_add_utils_1.adaptInsertChange)(tree, change, 'provideObliqueConfiguration()', 'provideObliqueConfiguration'));
        return (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
    });
}
function addAjv(ajv) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (ajv) {
            (0, utils_1.infoMigration)(context, 'Oblique feature: Adding schema validation');
            (0, ng_add_utils_1.addDevDependency)(tree, 'ajv');
            (0, ng_add_utils_1.addDevDependency)(tree, 'ajv-formats');
        }
        (0, utils_1.setOrCreateAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'allowedCommonJsDependencies'], ['ajv', 'ajv-formats']);
        return tree;
    });
}
function addUnknownRoute(unknownRoute) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        const routingModule = tree.exists(ng_add_utils_1.routingModulePath) ? ng_add_utils_1.routingModulePath : ng_add_utils_1.appModulePath;
        if (unknownRoute && tree.exists(routingModule)) {
            (0, utils_1.infoMigration)(context, 'Oblique feature: Adding unknown route');
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, routingModule);
            const changes = (0, ast_utils_1.addImportToModule)(sourceFile, routingModule, 'ObUnknownRouteModule', utils_1.ObliquePackage);
            const fileName = routingModule.split('/').pop();
            if (fileName) {
                changes.push((0, ast_utils_1.addRouteDeclarationToModule)(sourceFile, fileName, "{path: '**', redirectTo: 'unknown-route'}"));
            }
            tree = (0, ng_add_utils_1.applyChanges)(tree, routingModule, changes);
        }
        return tree;
    });
}
function enableAnchorScrolling() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique feature: enabling anchor scrolling');
        const content = (0, utils_1.readFile)(tree, ng_add_utils_1.routingModulePath);
        const newContent = content.replace('RouterModule.forRoot(routes)', 'RouterModule.forRoot(routes, { anchorScrolling: "enabled" })');
        (0, utils_1.writeFile)(tree, ng_add_utils_1.routingModulePath, newContent);
        return tree;
    });
}
function addInterceptors(httpInterceptors) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (httpInterceptors) {
            (0, utils_1.infoMigration)(context, 'Oblique feature: Adding http interceptor');
            const obliqueInterceptorModuleName = 'ObHttpApiInterceptor';
            const obliqueInterceptorProvider = '{provide: HTTP_INTERCEPTORS, useClass: ObHttpApiInterceptor, multi: true}';
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
            const changes = (0, ast_utils_1.addProviderToModule)(sourceFile, ng_add_utils_1.appModulePath, obliqueInterceptorProvider, utils_1.ObliquePackage)
                .concat((0, ast_utils_1.addProviderToModule)(sourceFile, ng_add_utils_1.appModulePath, 'provideHttpClient(withXhr(), withInterceptorsFromDi())', '@angular/common/http'))
                .filter((change) => change instanceof change_1.InsertChange)
                .map((change) => (0, ng_add_utils_1.adaptInsertChange)(tree, change, obliqueInterceptorProvider, obliqueInterceptorModuleName))
                .map((change) => (0, ng_add_utils_1.adaptInsertChange)(tree, change, 'provideHttpClient(withXhr(), withInterceptorsFromDi())', 'provideHttpClient, HTTP_INTERCEPTORS, withInterceptorsFromDi, withXhr'));
            tree = (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
        }
        else {
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
            const changes = (0, ast_utils_1.addProviderToModule)(sourceFile, ng_add_utils_1.appModulePath, 'provideHttpClient(withXhr())', '@angular/common/http')
                .filter((change) => change instanceof change_1.InsertChange)
                .map((change) => (0, ng_add_utils_1.adaptInsertChange)(tree, change, 'provideHttpClient(withXhr())', 'provideHttpClient, withXhr'));
            tree = (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
        }
        return tree;
    });
}
function addBanner(banner, environments) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (banner && environments) {
            (0, utils_1.infoMigration)(context, 'Oblique feature: Adding environment banner');
            const provider = '{provide: OB_BANNER, useValue: environment.banner}';
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
            const changes = (0, ast_utils_1.addProviderToModule)(sourceFile, ng_add_utils_1.appModulePath, provider, utils_1.ObliquePackage)
                .concat((0, ast_utils_1.insertImport)(sourceFile, ng_add_utils_1.appModulePath, 'environment', '../environments/environment'))
                .filter((change) => change instanceof change_1.InsertChange)
                .map((change) => (0, ng_add_utils_1.adaptInsertChange)(tree, change, provider.replace(/\..*$/, ''), 'OB_BANNER'));
            (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
        }
        return tree;
    });
}
function addDefaultHomeComponent(prefix) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique feature: Adding default home component');
        addDefaultComponent(tree, prefix);
        addDefaultComponentToAppModule(tree);
        addDefaultComponentRouteToAppRoutingModule(tree);
        return tree;
    });
}
function addDefaultComponent(tree, prefix) {
    (0, utils_1.addFile)(tree, 'src/app/home/home.html', (0, ng_add_utils_1.getTemplate)(tree, `home.html`));
    (0, utils_1.addFile)(tree, 'src/app/home/home.scss', (0, ng_add_utils_1.getTemplate)(tree, `home.scss.config`));
    (0, utils_1.addFile)(tree, 'src/app/home/home.ts', (0, ng_add_utils_1.getTemplate)(tree, 'home.ts.config').replace('_APP_PREFIX_PLACEHOLDER_', prefix));
}
function addDefaultComponentToAppModule(tree) {
    if (tree.exists(ng_add_utils_1.appModulePath)) {
        const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
        const changes = (0, ast_utils_1.addDeclarationToModule)(sourceFile, ng_add_utils_1.appModulePath, 'Home', './home/home');
        changes.push(...(0, ast_utils_1.addImportToModule)(sourceFile, ng_add_utils_1.appModulePath, 'MatButtonModule', '@angular/material/button'));
        changes.push(...(0, ast_utils_1.addImportToModule)(sourceFile, ng_add_utils_1.appModulePath, 'MatCardModule', '@angular/material/card'));
        changes.push(...(0, ast_utils_1.addImportToModule)(sourceFile, ng_add_utils_1.appModulePath, 'MatIconModule', '@angular/material/icon'));
        (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
    }
}
function addDefaultComponentRouteToAppRoutingModule(tree) {
    const routingModule = tree.exists(ng_add_utils_1.routingModulePath) ? ng_add_utils_1.routingModulePath : ng_add_utils_1.appModulePath;
    if (tree.exists(routingModule)) {
        const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, routingModule);
        const changes = [];
        const fileName = routingModule.split('/').pop();
        if (fileName) {
            changes.push((0, ast_utils_1.insertImport)(sourceFile, routingModule, 'Home', './home/home'));
            changes.push((0, ast_utils_1.addRouteDeclarationToModule)(sourceFile, fileName, "{path: '', redirectTo: 'home', pathMatch: 'full'},{path: 'home', component: Home}"));
        }
        (0, ng_add_utils_1.applyChanges)(tree, routingModule, changes);
    }
}
function addExternalLink(externalLink) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (externalLink) {
            (0, utils_1.infoMigration)(context, 'Oblique feature: Adding external link module');
            const sourceFile = (0, ng_add_utils_1.createSrcFile)(tree, ng_add_utils_1.appModulePath);
            const changes = (0, ast_utils_1.addImportToModule)(sourceFile, ng_add_utils_1.appModulePath, 'ObExternalLinkModule', utils_1.ObliquePackage);
            return (0, ng_add_utils_1.applyChanges)(tree, ng_add_utils_1.appModulePath, changes);
        }
        return tree;
    });
}
function parseContact(contacts) {
    return {
        emails: contacts
            ?.trim()
            .split(/\s*,\s*/)
            .filter((element) => element.includes('@')) ?? [],
        phones: contacts
            ?.trim()
            .split(/\s*,\s*/)
            .filter((element) => !element.includes('@')) ?? [],
    };
}
function validateContact(emails, phones) {
    if (isEmpty(emails) && isEmpty(phones)) {
        throw new Error('You must provide at least one contact method: email or phone.');
    }
}
function isEmpty(array) {
    return !array || array.length === 0;
}
function setObliqueConfiguration(applicationTitle, applicationOperator, contact, hasLanguageInUrl) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Oblique feature: Adding accessibility statement configuration');
        const { emails, phones } = parseContact(contact);
        validateContact(emails, phones);
        const content = (0, utils_1.readFile)(tree, ng_add_utils_1.appModulePath);
        const accessibilityConfig = buildAccessibilityConfig(applicationTitle, applicationOperator, emails, phones);
        const hasLanguageInUrlConfig = buildHasLanguageInUrlConfig(hasLanguageInUrl);
        const newContent = content.replace(/(?<=provideObliqueConfiguration\()(?=\))/, `{${accessibilityConfig}, ${hasLanguageInUrlConfig}}`);
        (0, utils_1.writeFile)(tree, ng_add_utils_1.appModulePath, newContent);
        return tree;
    });
}
function buildAccessibilityConfig(title, applicationOperator, emails = [], phones = []) {
    const contactFields = [
        ...emails.map(email => `{email: '${email}'}`),
        ...phones.map(phone => `{phone: '${phone}'}`),
    ].join(', ');
    const createdOn = new Date().toISOString().split('T')[0];
    return `accessibilityStatement: {
			applicationName: '${title}',
			conformity: 'none',
			createdOn: new Date('${createdOn}'),
			applicationOperator: '${applicationOperator}',
			contact: [${contactFields}]
		}`;
}
function buildHasLanguageInUrlConfig(hasLanguageInUrl) {
    return `language: {hasLanguageInUrl: ${hasLanguageInUrl}}`;
}
