/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toolchain = toolchain;
const schematics_1 = require("@angular-devkit/schematics");
const ng_add_utils_1 = require("../ng-add-utils");
const utils_1 = require("../../utils");
function toolchain(options) {
    return (tree, context) => (0, schematics_1.chain)([
        setBuilder(),
        moveStyles(),
        removeFavicon(),
        removeUnusedScripts(),
        addPrefix(options.prefix),
        updateExistingPrefixes(options.prefix),
        updateEditorConfig(options.eslint),
        addPrettier(options.eslint),
        addHusky(options.husky),
        addEnvironmentFiles(options.environments, options.banner),
        excludeEnvironmentFiles(),
        excludeEnvironmentFilesFromTests(),
        setEnvironments(options.environments),
    ])(tree, context);
}
function setBuilder() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Toolchain: Setting angular builder');
        (0, utils_1.getAngularConfigs)(tree, []).forEach(project => {
            const { build } = project.config.architect;
            const { serve } = project.config.architect;
            const buildOptions = build.options;
            const buildConfigurations = build.configurations;
            const buildConfigurationsProduction = buildConfigurations.production;
            const buildConfigurationsDevelopment = buildConfigurations.development;
            (0, utils_1.setAngularConfig)(tree, ['architect', 'build'], {
                project: project.project,
                config: {
                    ...build,
                    builder: '@angular-devkit/build-angular:browser',
                    options: {
                        ...buildOptions,
                        main: buildOptions.browser,
                        outputPath: 'dist',
                        index: 'src/index.html',
                    },
                    configurations: {
                        ...buildConfigurations.config,
                        development: {
                            ...buildConfigurationsDevelopment.config,
                            buildOptimizer: false,
                            vendorChunk: true,
                        },
                        production: {
                            ...buildConfigurationsProduction,
                        },
                    },
                },
            });
            (0, utils_1.setAngularConfig)(tree, ['architect', 'serve'], {
                project: project.project,
                config: {
                    ...serve,
                    builder: '@angular-devkit/build-angular:dev-server',
                },
            });
        });
        (0, utils_1.removeAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'browser']);
        (0, ng_add_utils_1.removeDevDependencies)(tree, '@angular/build');
        (0, ng_add_utils_1.addDevDependency)(tree, '@angular-devkit/build-angular');
        return tree;
    });
}
function moveStyles() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (!tree.exists('src/styles/styles.scss')) {
            (0, utils_1.infoMigration)(context, 'Toolchain: Moving style sheets into "styles" directory');
            const comment = '// this file should contain only imports. Rules should be grouped by features and placed into the corresponding file';
            (0, utils_1.addFile)(tree, 'src/styles/styles.scss', comment);
            (0, utils_1.deleteFile)(tree, 'src/styles.scss');
            const content = (0, utils_1.readFile)(tree, 'angular.json') || '';
            tree.overwrite('angular.json', content.replace(/"src\/styles\.scss"/g, '"src/styles/styles.scss"'));
        }
        return tree;
    });
}
function removeFavicon() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, "Toolchain: Removing Angular's favicon");
        (0, utils_1.deleteFile)(tree, 'public/favicon.ico');
        return (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'options', 'assets'], (config) => (config || []).filter(item => typeof item === 'string' || JSON.stringify(item) !== '{"glob":"**/*","input":"public"}'));
    });
}
function removeUnusedScripts() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Toolchain: Removing unused script');
        return (0, ng_add_utils_1.removeScript)(tree, 'ng');
    });
}
function addPrefix(prefix) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, "Toolchain: Setting application's prefix");
        tree = (0, utils_1.setRootAngularConfig)(tree, ['schematics'], {
            '@schematics/angular:component': {
                prefix,
                style: 'scss',
            },
            '@schematics/angular:directive': {
                prefix,
            },
        });
        return (0, utils_1.setAngularProjectsConfig)(tree, ['prefix'], prefix);
    });
}
function updateExistingPrefixes(prefix) {
    return (0, utils_1.createSafeRule)((tree) => {
        (0, utils_1.replaceInFile)(tree, 'src/index.html', /<app-root><\/app-root>/g, `<${prefix}-root></${prefix}-root>`);
        (0, utils_1.replaceInFile)(tree, `src/app/${ng_add_utils_1.angularAppFilesNames.appComponent}`, /app-root/g, `${prefix}-root`);
        return tree;
    });
}
function updateEditorConfig(eslint) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (eslint) {
            (0, utils_1.infoMigration)(context, 'Toolchain: update ".editorconfig"');
            (0, utils_1.writeFile)(tree, '.editorconfig', (0, ng_add_utils_1.getTemplate)(tree, 'default-editorconfig.config'));
        }
        return tree;
    });
}
function addPrettier(eslint) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (eslint) {
            (0, utils_1.infoMigration)(context, 'Toolchain: Adding "prettier"');
            ['prettier', 'eslint-config-prettier', 'eslint-plugin-prettier'].forEach(dependency => (0, ng_add_utils_1.addDevDependency)(tree, dependency));
            (0, ng_add_utils_1.addScript)(tree, 'format', 'npm run lint -- --fix');
            (0, utils_1.writeFile)(tree, '.prettierrc', (0, ng_add_utils_1.getTemplate)(tree, 'default-prettierrc.config'));
            (0, ng_add_utils_1.removeRootProperty)(tree, 'prettier');
        }
        return tree;
    });
}
function addHusky(husky) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (husky) {
            (0, utils_1.infoMigration)(context, 'Toolchain: Adding git hooks for code auto-formatting');
            (0, ng_add_utils_1.addDevDependency)(tree, 'husky');
            (0, ng_add_utils_1.addScript)(tree, 'prepare', 'husky');
            tree.create('.husky/pre-commit', 'npm run format');
        }
        return tree;
    });
}
function addEnvironmentFiles(environments, hasBanner) {
    return (0, utils_1.createSafeRule)((tree, context) => {
        if (environments) {
            (0, utils_1.infoMigration)(context, 'Toolchain: Adding environment files');
            environments
                .split(' ')
                .map(environment => ({
                fileName: environment === 'local' ? 'environment.ts' : `environment.${environment}.ts`,
                content: getEnvironmentFileContent(environment, hasBanner),
            }))
                .forEach(environment => addEnvironmentFile(tree, environment.fileName, environment.content));
        }
        return tree;
    });
}
function excludeEnvironmentFiles() {
    return (tree, context) => {
        (0, utils_1.infoMigration)(context, 'Toolchain: Exclude environment files for tsConfig');
        // can't use JSON.parse as the file contains comments
        const tsConfigPath = 'tsconfig.app.json';
        const tsConfig = (0, utils_1.readFile)(tree, tsConfigPath).replace(/(?<indent>^\s*)(?<key>"exclude"\s*:\s*\[\s*)/mu, '$<indent>$<key>"src/environments/environment.*.ts",\n$<indent>$<indent>');
        (0, utils_1.writeFile)(tree, tsConfigPath, tsConfig);
        return tree;
    };
}
function excludeEnvironmentFilesFromTests() {
    return (0, utils_1.createSafeRule)((tree, context) => {
        (0, utils_1.infoMigration)(context, 'Toolchain: Exclude environment files from unit tests');
        (0, utils_1.setOrCreateAngularProjectsConfig)(tree, ['architect', 'test', 'options', 'exclude'], (existing) => [
            ...(existing ?? []).filter(current => current !== 'src/environments/**'),
            'src/environments/**',
        ]);
        return tree;
    });
}
function getEnvironmentFileContent(environment, hasBanner) {
    return `export const environment = ${hasBanner && environment !== 'prod' ? `{banner: {text: '${environment.toUpperCase()}'}}` : '{}'};`;
}
function addEnvironmentFile(tree, fileName, fileContent) {
    (0, utils_1.getAngularConfigs)(tree, ['sourceRoot'])
        .map(config => config.config)
        .forEach(sourceRoot => (0, utils_1.writeFile)(tree, `${sourceRoot}/environments/${fileName}`, fileContent));
}
function setEnvironments(environments) {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return (tree, context) => (0, utils_1.setAngularProjectsConfig)(tree, ['architect', 'build', 'configurations'], (config) => {
        environments.split(' ').forEach(environment => {
            config[environment] = { ...config.production };
            if (config[environment].fileReplacements) {
                config[environment].fileReplacements[0].with = config[environment].fileReplacements[0].with.replace('prod', environment);
            }
            else {
                config[environment].fileReplacements = [
                    {
                        replace: 'projects/sandbox/src/environments/environment.ts',
                        with: `projects/sandbox/src/environments/environment.${environment}.ts`,
                    },
                ];
            }
            if (environment === 'dev') {
                config.dev.optimization = false;
                config.dev.sourceMap = true;
            }
        });
        return config;
    });
}
