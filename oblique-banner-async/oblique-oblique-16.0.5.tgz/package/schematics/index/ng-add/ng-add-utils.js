/**
* @file Oblique, The front-end framework for your Swiss branded UI.
* @copyright 2020 - 2026 Federal Office of Information Technology, Systems and Telecommunication FOITT {@link https://www.bit.admin.ch}
* @version 16.0.5 (released on 2026-11-23, supported at least until 2027-09-30)
* @author Oblique team, FOITT, BS-BSC-EN4 <oblique@bit.admin.ch>
* @license MIT {@link https://github.com/oblique-bit/oblique/blob/master/LICENSE}
* @see https://oblique.bit.admin.ch
*/

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.obliqueCssPath = exports.pathToTemplates = exports.routingModulePath = exports.appModulePath = exports.angularAppFilesNames = void 0;
exports.getPreconditionVersion = getPreconditionVersion;
exports.checkPrecondition = checkPrecondition;
exports.checkForMultiProject = checkForMultiProject;
exports.addDevDependency = addDevDependency;
exports.addDependency = addDependency;
exports.hasDependency = hasDependency;
exports.importModuleInRoot = importModuleInRoot;
exports.applyChanges = applyChanges;
exports.getTemplate = getTemplate;
exports.getAngularVersion = getAngularVersion;
exports.getDepVersion = getDepVersion;
exports.removeDevDependencies = removeDevDependencies;
exports.removeScript = removeScript;
exports.removeRootProperty = removeRootProperty;
exports.addRootProperty = addRootProperty;
exports.addScript = addScript;
exports.createSrcFile = createSrcFile;
exports.adaptInsertChange = adaptInsertChange;
const schematics_1 = require("@angular/cdk/schematics");
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const change_1 = require("@schematics/angular/utility/change");
const utils_1 = require("../utils");
const typescript_1 = require("typescript");
exports.angularAppFilesNames = {
    appModule: 'app-module.ts',
    appRoutingModule: 'app-routing-module.ts',
    appComponent: 'app.ts',
};
exports.appModulePath = `src/app/${exports.angularAppFilesNames.appModule}`;
exports.routingModulePath = `src/app/${exports.angularAppFilesNames.appRoutingModule}`;
exports.pathToTemplates = './node_modules/@oblique/oblique/schematics/index/ng-add/templates';
exports.obliqueCssPath = 'node_modules/@oblique/oblique/styles/css/oblique-core.css';
const versions = {
    '@angular/cdk': version => `^${version}.0.0`,
    '@angular/core': version => `^${version}.0.0`,
    '@angular/material': version => `^${version}.0.0`,
    '@angular/router': version => `^${version}.0.0`,
    '@angular-devkit/build-angular': version => `^${version}.0.0`,
    '@angular-eslint/eslint-plugin': '^22.0.0',
    '@angular-eslint/eslint-plugin-template': '^22.0.0',
    '@angular-eslint/template-parser': '^22.0.0',
    '@angular-eslint/utils': '^22.0.0',
    '@ngx-translate/core': '^18.0.0',
    '@popperjs/core': '^2.0.0',
    '@typescript-eslint/eslint-plugin': '^8.58.2',
    '@typescript-eslint/parser': '^8.58.2',
    ajv: '^8.0.0',
    'ajv-formats': '^3.0.0',
    'angular-eslint': '^22.0.0',
    'angular-oauth2-oidc': '^22.0.0',
    eslint: '^9.0.0',
    'eslint-config-prettier': '^9.0.0',
    'eslint-plugin-prettier': '^5.0.0',
    husky: '^9.0.0',
    prettier: '^3.0.0',
};
function getPreconditionVersion(tree, pkg) {
    const current = extractVersion(getDepVersion(tree, pkg) || '');
    const target = extractVersion(getDepVersion(tree, '@angular/core') || '') || {};
    return current?.major !== target.major || current.minor !== target.minor ? `${target.major}.${target.minor}` : '';
}
function checkPrecondition(tree, pkg) {
    const current = extractVersion(getDepVersion(tree, pkg) || '');
    const target = extractVersion(getTargetDepVersion(tree, pkg) || '') || {};
    if (!current || current.major < target.major || current.minor < target.minor || current.patch < target.patch) {
        (0, utils_1.error)(`Unmet peer dependency. Oblique requires a peer of ${pkg}@${target.major}.${target.minor}.${target.patch} but none is installed.
You must install peer dependencies yourself."`);
    }
}
function checkForMultiProject() {
    return (tree, context) => {
        (0, utils_1.infoMigration)(context, 'Check if project is a multi-project angular application ');
        const multiProject = !tree.exists(`./src/app/${exports.angularAppFilesNames.appModule}`);
        if (multiProject) {
            (0, utils_1.error)('Multi-project application detected. Oblique schematics are not compatible with multi-project applications. Either convert the application to non multi-project or perform the changes manually. Check the documentation for guidance.');
        }
    };
}
function addDevDependency(tree, name) {
    (0, dependencies_1.addPackageJsonDependency)(tree, createDep(tree, dependencies_1.NodeDependencyType.Dev, name));
}
function addDependency(tree, name) {
    (0, dependencies_1.addPackageJsonDependency)(tree, createDep(tree, dependencies_1.NodeDependencyType.Default, name));
}
function hasDependency(tree, dependency) {
    const dep = (0, dependencies_1.getPackageJsonDependency)(tree, dependency.name);
    return dep?.type === dependency.type;
}
function importModuleInRoot(tree, moduleName, src) {
    if (!(0, schematics_1.hasNgModuleImport)(tree, exports.appModulePath, moduleName)) {
        (0, schematics_1.addModuleImportToModule)(tree, exports.appModulePath, moduleName, src);
    }
}
function applyChanges(tree, filePath, changes) {
    const records = tree.beginUpdate(filePath);
    changes
        .filter(change => change instanceof change_1.InsertChange)
        .forEach((change) => {
        records.insertLeft(change.pos, change.toAdd);
    });
    tree.commitUpdate(records);
    return tree;
}
function getTemplate(tree, file) {
    return (0, utils_1.readFile)(tree, `${exports.pathToTemplates}/${file}`);
}
function getAngularVersion(tree) {
    return parseInt(/@angular\/core":\s*"[~,^]?(?<version>\d+)\.\d+\.\d+"/.exec((0, utils_1.readFile)(tree, utils_1.packageJsonConfigPath))?.groups
        ?.version || '0', 10);
}
function getDepVersion(tree, dep) {
    const pattern = new RegExp(`"${dep}":\\s*"[~,^]?(?<version>\\d+\\.\\d+\\.\\d+)"`);
    return (0, utils_1.readFile)(tree, utils_1.packageJsonConfigPath).match(pattern)?.groups?.version;
}
function removeDevDependencies(tree, dependency) {
    const json = (0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath);
    Object.keys(json.devDependencies)
        .filter((dep) => dep.includes(dependency))
        .forEach((dep) => (0, dependencies_1.removePackageJsonDependency)(tree, dep));
    return tree;
}
function removeScript(tree, script) {
    const packageJson = (0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath);
    delete packageJson.scripts[script];
    tree.overwrite(utils_1.packageJsonConfigPath, JSON.stringify(packageJson, null, 2));
    return tree;
}
function removeRootProperty(tree, property) {
    const packageJson = (0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath);
    delete packageJson[property];
    tree.overwrite(utils_1.packageJsonConfigPath, JSON.stringify(packageJson, null, 2));
    return tree;
}
function addRootProperty(tree, name, content) {
    const packageJson = (0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath);
    packageJson[name] = content;
    tree.overwrite(utils_1.packageJsonConfigPath, JSON.stringify(packageJson, null, 2));
    return tree;
}
function addScript(tree, name, content) {
    const packageJson = (0, utils_1.getJson)(tree, utils_1.packageJsonConfigPath);
    packageJson.scripts[name] = content;
    tree.overwrite(utils_1.packageJsonConfigPath, JSON.stringify(packageJson, null, 2));
    return tree;
}
function createSrcFile(tree, source) {
    return (0, typescript_1.createSourceFile)(source, (0, utils_1.readFile)(tree, source), typescript_1.ScriptTarget.Latest, true);
}
function adaptInsertChange(tree, change, search, replace) {
    const pos = (0, utils_1.readFile)(tree, exports.appModulePath).indexOf('@NgModule');
    if (change.pos < pos) {
        change.toAdd = change.toAdd.replace(search, replace);
        change.description = change.description.replace(search, replace);
    }
    return change;
}
function extractVersion(version) {
    const hit = /(?<major>\d+)\.(?<minor>\d+)\.(?<patch>\d+)/.exec(version);
    return hit?.groups
        ? {
            major: parseInt(hit.groups.major, 10),
            minor: parseInt(hit.groups.minor, 10),
            patch: parseInt(hit.groups.patch, 10),
        }
        : undefined;
}
function getTargetDepVersion(tree, name) {
    const version = versions[name];
    if (!version) {
        (0, utils_1.error)(`Unknown dependency: ${name}`);
    }
    return version instanceof Function ? version(getAngularVersion(tree)) : version;
}
function createDep(tree, type, name) {
    const version = getTargetDepVersion(tree, name);
    return { type, version, name };
}
